// ==WindhawkMod==
// @id              taskbar-clock-customization
// @name            Taskbar Clock Customization
// @description     Custom date/time format, news feed, weather, performance metrics (upload/download speed, CPU, RAM, GPU, battery), media player info, custom fonts and colors, and more
// @version         1.8.1
// @author          m417z
// @github          https://github.com/m417z
// @twitter         https://twitter.com/m417z
// @homepage        https://m417z.com/
// @include         explorer.exe
// @architecture    x86-64
// @compilerOptions -ldxgi -lole32 -loleaut32 -lpdh -lpowrprof -lruntimeobject -lshlwapi -lversion -lwininet
// ==/WindhawkMod==

// Source code is published under The GNU General Public License v3.0.
//
// For bug reports and feature requests, please open an issue here:
// https://github.com/ramensoftware/windhawk-mods/issues
//
// For pull requests, development takes place here:
// https://github.com/m417z/my-windhawk-mods

// ==WindhawkModReadme==
/*
# Taskbar Clock Customization

Custom date/time format, news feed, weather, performance metrics
(upload/download speed, CPU, GPU, RAM, battery), media player info, custom fonts
and colors, and more.

Only Windows 10 64-bit and Windows 11 are supported.

![News screenshot](https://i.imgur.com/p03o9l7.png) \
_News (default mod settings)_

![Weather screenshot](https://i.imgur.com/Re7mQd6.png) \
_Weather_

![System performance metrics screenshot](https://i.imgur.com/QhyYv0D.png) \
_System performance metrics_

## Available patterns

The top line, bottom line, middle line (Windows 10 only), and tooltip extra line
can be configured with text that contains patterns. The following patterns can
be used:

* `%time%` - the time as configured by the time format in settings.
  * `%time<n>%` - additional time formats, specified by separating multiple
    formats with `;` in the time format setting. `<n>` is the additional time
    format number, starting with 2.
  * `%time_tz<n>%` - the time with a custom time zone. `<n>` is the time zone
    number in the list of time zones configured in the mod settings (not Windows
    settings).
* `%date%` - the date as configured by the date format in settings.
  * `%date<n>%` - additional date formats, specified by separating multiple
    formats with `;` in the date format setting. `<n>` is the additional date
    format number, starting with 2. Each date format can have its own locale;
    refer to the date locale setting for details.
  * `%date_tz<n>%` - the date with a custom time zone. `<n>` is the time zone
    number in the list of time zones configured in the mod settings (not Windows
    settings).
* `%weekday%` - the week day as configured in settings.
  * `%weekday_tz<n>%` - the week day with a custom time zone. `<n>` is the time
    zone number in the list of time zones configured in the mod settings (not
    Windows settings).
* `%weekday_num%` - the week day number according to the [first day of the
  week](https://superuser.com/q/61002) system configuration. For example, if the
  first day of the week is Sunday, then the week day number is 1 for Sunday, 2
  for Monday, ..., 7 for Saturday.
* `%weeknum%` - the week number, calculated as follows: The week containing 1
  January is defined as week 1 of the year. Subsequent weeks start on the first
  day of the week according to the system configuration.
* `%weeknum_iso%` - the [ISO week
  number](https://en.wikipedia.org/wiki/ISO_week_date).
* `%dayofyear%` - the day of the year, where January 1st is day 1.
* `%timezone%` - the time zone in ISO 8601 format.
* System performance metrics:
  * `%upload_speed%` - system-wide upload transfer rate.
  * `%download_speed%` - system-wide download transfer rate.
  * `%total_speed%` - combined upload and download transfer rate.
  * `%disk_read%` - disk read speed.
  * `%disk_write%` - disk write speed.
  * `%disk_total%` - combined disk read and write speed.
  * `%cpu%` - CPU usage.
  * `%ram%` - RAM usage.
  * `%ram_used%` - used RAM amount in GB.
  * `%ram_total%` - total RAM amount in GB.
  * `%ram_committed%` - committed RAM usage (% of memory committed by apps,
    backed by RAM or the page file).
  * `%ram_committed_used%` - used committed RAM amount in GB.
  * `%ram_committed_total%` - total committed RAM amount in GB.
  * `%gpu%` - GPU usage.
  * `%vram%` - VRAM usage as a percentage of total dedicated VRAM.
  * `%vram_used%` - used dedicated VRAM amount in GB.
  * `%vram_total%` - total dedicated VRAM amount in GB.
  * `%vram_shared%` - shared VRAM usage as a percentage of total shared VRAM
    (system RAM used as extra GPU memory).
  * `%vram_shared_used%` - used shared VRAM amount in GB.
  * `%vram_shared_total%` - total shared VRAM pool size in GB.
  * `%cpu_temp%` - CPU temperature in °C (average of all ACPI thermal zones).
  * `%cpu_temp_f%` - CPU temperature in °F (average of all ACPI thermal zones).
  * `%gpu_temp%` - GPU temperature in °C.
  * `%gpu_temp_f%` - GPU temperature in °F.
  * `%battery%` - battery level percentage.
  * `%battery_time%` - battery time remaining (charging time left / discharging
    time left, in h:mm format). If the value is always zero, you might need to
    enable battery time reporting in the BIOS.
  * `%power%` - battery power in watts (negative when discharging, positive when
    charging). If the value is always zero, you might need to enable battery
    time reporting in the BIOS.
* Media player info (requires a
  [GSMTC-compatible](https://github.com/ModernFlyouts-Community/ModernFlyouts/blob/main/docs/GSMTC-Support-And-Popular-Apps.md)
  media player):
  * `%media_title%` - currently playing media title.
  * `%media_artist%` - currently playing media artist.
  * `%media_album%` - currently playing media album.
  * `%media_status%` - media playback status icon (⏯, ⏸, ⏹).
  * `%media_info%` - combined media info, truncated with an ellipsis. Defaults
    to "Artist - Title" while media is playing. The formats for when media is
    playing and when it isn't can be customized in the media player settings.
    It's recommended to use this field on the taskbar and the other fields in
    the tooltip.
* `%weather%` - weather information, powered by [wttr.in](https://wttr.in/),
  using the location and format configured in settings.
* `%web<n>%` - the web content as configured in settings, truncated with an
  ellipsis, where `<n>` is the web content item number.
* `%web<n>_full%` - the full web content as configured in settings, where `<n>`
  is the web content item number.
* `%newline%` or `%n%` - a newline.

## Text styles

For Windows 11 version 22H2 and newer, the mod allows changing the clock text
styles, such as the font color and size.

![Screenshot](https://i.imgur.com/3JiXwjT.png)
*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- ShowSeconds: true
  $name: Show seconds
- TimeFormat: >-
    hh':'mm':'ss tt
  $name: Time format
  $description: >-
    The format for the %time% pattern. Leave empty for the default format. For
    the syntax, refer to the following page:

    https://docs.microsoft.com/en-us/windows/win32/api/datetimeapi/nf-datetimeapi-gettimeformatex#remarks
- DateFormat: >-
    ddd',' MMM dd yyyy
  $name: Date format
  $description: >-
    The format for the %date% pattern. Leave empty for the default format. For
    the syntax, refer to the following page:

    https://docs.microsoft.com/en-us/windows/win32/intl/day--month--year--and-era-format-pictures
- DateLocale: ""
  $name: Date locale
  $description: >-
    The locale used for formatting the date and the week day. Leave empty for
    the default locale. Use ";" to set a locale per date format, e.g.
    "en-US;fr-FR" for an English %date% and a French %date2%. Empty entries use
    the default locale. For the list of locale names, listed as "Language tag",
    refer to the following page:

    https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-lcid/a9eac961-e77d-41a6-90a5-ce1a8b0cdb9c
- WeekdayFormat: dddd
  $name: Week day format
  $description: The format for the %weekday% pattern.
  $options:
  - dddd: Full day of the week
  - ddd: Abbreviated day of the week
  - custom: Custom, specified below
- WeekdayFormatCustom: Sun, Mon, Tue, Wed, Thu, Fri, Sat
  $name: Custom week day format
  $description: >-
    A comma-separated list of custom week days, Sunday through Saturday. Used if
    the week day format is set to custom.
- TopLine: '%date% | %time%'
  $name: Top line
  $description: >-
    Text to be shown on the first line. Set to "-" for the default value. Refer
    to the mod details for the list of patterns that can be used.
- BottomLine: '%web1%'
  $name: Bottom line
  $description: >-
    Only shown if the taskbar is large enough. Set to "-" for the default value.
- MiddleLine: '%weekday%'
  $name: Middle line (Windows 10 only)
  $description: >-
    Only shown if the taskbar is large enough. Set to "-" for the default value.
- TooltipLine: '%web1_full%'
  $name: Tooltip extra line
- TooltipLineMode: append
  $name: Tooltip line mode
  $options:
  - append: Append to default tooltip
  - replace: Replace default tooltip
- Width: 180
  $name: Clock width (Windows 10 only)
- Height: 60
  $name: Clock height (Windows 10 only)
- MaxWidth: 0
  $name: Clock max width (Windows 11 only)
  $description: Set to zero for no limit.
- TextSpacing: 0
  $name: Line spacing
  $description: >-
    Set to zero for the default system value. A negative value can be used for
    negative spacing.
- DataCollection:
  - NetworkMetricsFormat: mbs
    $name: Network metrics format
    $description: >-
      The format to use for displaying the upload/download transfer rate.
    $options:
    - mbs: MB/s
    - mbsNumberOnly: MB/s, number only
    - mbsDynamic: MB/s or KB/s (dynamic)
    - mbits: MBit/s
    - mbitsNumberOnly: MBit/s, number only
    - mbitsDynamic: MBit/s or KBit/s (dynamic)
  - NetworkMetricsFixedDecimals: -1
    $name: Network metrics fixed decimal places
    $description: >-
      Always use this number of decimal places for the upload/download transfer
      rate (-1 means auto/same width).
  - DiskMetricsFormat: sameAsNetwork
    $name: Disk metrics format
    $description: >-
      The format to use for displaying the disk read/write speed.
    $options:
    - sameAsNetwork: Same as network metrics format
    - mbs: MB/s
    - mbsNumberOnly: MB/s, number only
    - mbsDynamic: MB/s or KB/s (dynamic)
    - mbits: MBit/s
    - mbitsNumberOnly: MBit/s, number only
    - mbitsDynamic: MBit/s or KBit/s (dynamic)
  - DiskMetricsFixedDecimals: -1
    $name: Disk metrics fixed decimal places
    $description: >-
      Always use this number of decimal places for the disk read/write speed
      (-1 means auto/same width). Ignored when the disk metrics format is set to
      "Same as network metrics format".
  - PercentageFormat: spacePaddingAndSymbol
    $name: Percentage format
    $description: >-
      The format to use for displaying percentage values (CPU, RAM, GPU,
      battery).
    $options:
    - spacePaddingAndSymbol: Pad with spaces, add percent sign
    - spacePadding: Pad with spaces, number only
    - singleSpacePadding: >-
        Pad with a single space, number only (for monospaced fonts)
    - zeroPadding: Pad with zeros, number only
    - noPadding: No padding, number only
  - UpdateInterval: 1
    $name: Update interval
    $description: >-
      The update interval, in seconds, of the system performance metrics.
  - NetworkAdapterName: ""
    $name: Network adapter name
    $description: >-
      The network adapter to use for upload/download metrics. Leave empty to
      sum all adapters. Partial match is supported. To list adapters, run:

      typeperf -qx "Network Interface"
  - GpuAdapterName: ""
    $name: GPU adapter name
    $description: >-
      The GPU adapter to use for GPU usage, VRAM, and temperature metrics. Leave
      empty to auto-detect (uses the adapter with the most dedicated VRAM).
      Partial match is supported. To list adapters, run:

      wmic path win32_videocontroller get Name
  $name: System performance metrics
- MediaPlayer:
  - IgnoredPlayers: [""]
    $name: Ignored media players
    $description: >-
      List of media player names to ignore (case-insensitive, partial match).
      Examples: "Spotify", "VLC". Leave empty to disable.
  - MaxLength: 28
    $name: Maximum info length
    $description: >-
      The maximum number of characters for %media_info%. Longer text is
      truncated with an ellipsis. Set to 0 for no limit.
  - MediaInfoFormat: "%media_artist% - %media_title%"
    $name: Format when media is playing
    $description: >-
      The format of %media_info% while media is playing. Can contain any
      patterns, such as %media_artist%, %media_title%, %media_album%, and
      %media_status%.
  - NoMediaText: No media
    $name: Format when media is not playing
    $description: >-
      The text shown for %media_info% when no media is playing. Can contain any
      patterns, such as %date% or %time%.
  - RemoveBrackets: false
    $name: Remove brackets from info
    $description: >-
      Remove text in brackets from media info. E.g., "Song (feat. Artist)"
      becomes "Song".
  $name: Media player info
- WebContentWeatherLocation: ""
  $name: Weather location
  $description: >-
    Get weather information for a specific location. Leave empty to use the
    current location. For details, refer to the documentation of wttr.in.
- WebContentWeatherFormat: "%c \U0001F321\uFE0F%t \U0001F32C\uFE0F%w"
  $name: Weather format
  $description: >-
    The weather information format. For details, refer to the documentation of
    wttr.in.
- WebContentWeatherUnits: autoDetect
  $name: Weather units
  $description: >-
    The weather units. For details, refer to the documentation of wttr.in.
  $options:
  - autoDetect: Auto (default)
  - uscs: USCS (used by default in the US)
  - metric: Metric (SI) (used by default everywhere except the US)
  - metricMsWind: Metric (SI), but show wind speed in m/s
- WebContentsItems:
  - - Url: https://rss.nytimes.com/services/xml/rss/nyt/World.xml
      $name: Web content URL
    - BlockStart: '<item>'
      $name: Web content block start
      $description: The string in the webpage to start from.
    - Start: '<title>'
      $name: Web content start
      $description: The string just before the content.
    - End: '</title>'
      $name: Web content end
      $description: The string just after the content.
    - ContentMode: xmlHtml
      $name: Content mode
      $description: >-
        The plain text mode leaves the content unchanged. Tags or entities such
        as "&amp;" can be stripped/decoded with the respective modes. The XML
        mode requires the content to be well-formed XML. The XML+HTML mode can
        be useful for RSS feeds.
      $options:
      - "": Plain text
      - html: HTML
      - xml: XML
      - xmlHtml: XML+HTML
    - SearchReplace:
      - - Search: ""
        - Replace: ""
      $name: Content search/replace
      $description: >-
        Regular expression-based search and replace operations applied to the
        extracted content.
    - MaxLength: 28
      $name: Web content maximum length
      $description: Longer text is truncated with an ellipsis.
  $name: Web content items
  $description: >-
    Used to fetch the data displayed in place of the %web<n>% and %web<n>_full%
    patterns, where <n> is the web content item number.
- WebContentsUpdateInterval: 10
  $name: Web content update interval
  $description: >-
    The update interval, in minutes, of the weather and the web content items.
- TimeZones: ["Eastern Standard Time"]
  $name: Time zones
  $description: >-
    The list of time zones for patterns such as %time_tz1%. For a full list of
    supported time zones, run the following PowerShell command:

    Get-TimeZone -ListAvailable
- TimeStyle:
  - Hidden: false
  - TextColor: ""
    $name: Text color
    $description: >-
      Can be a color name (Red, Black, ...) or an RGB/ARGB color code (like
      #00FF00, #CC00FF00, ...).
  - TextAlignment: ""
    $name: Text alignment
    $options:
    - "": Default
    - Right: Right
    - Center: Center
    - Left: Left
    - Justify: Justified
  - FontSize: 0
    $name: Font size
    $description: Set to zero for the default size.
  - FontFamily: ""
    $name: Font family
    $description: >-
      For a list of fonts that are shipped with Windows 11, refer to the
      following page:

      https://learn.microsoft.com/en-us/typography/fonts/windows_11_font_list
  - FontWeight: ""
    $name: Font weight
    $options:
    - "": Default
    - Thin: Thin
    - ExtraLight: Extra light
    - Light: Light
    - SemiLight: Semi light
    - Normal: Normal
    - Medium: Medium
    - SemiBold: Semi bold
    - Bold: Bold
    - ExtraBold: Extra bold
    - Black: Black
    - ExtraBlack: Extra black
  - FontStyle: ""
    $name: Font style
    $options:
    - "": Default
    - Normal: Normal
    - Oblique: Oblique
    - Italic: Italic
  - FontStretch: ""
    $name: Font stretch
    $description: Only supported by some fonts.
    $options:
    - "": Default
    - Undefined: Undefined
    - UltraCondensed: Ultra condensed
    - ExtraCondensed: Extra condensed
    - Condensed: Condensed
    - SemiCondensed: Semi condensed
    - Normal: Normal
    - SemiExpanded: Semi expanded
    - Expanded: Expanded
    - ExtraExpanded: Extra expanded
    - UltraExpanded: Ultra expanded
  - CharacterSpacing: 0
    $name: Character spacing
    $description: Can be a positive or a negative number.
  - LineHeight: 0
    $name: Line height
    $description: >-
      The line height in pixels, useful when the line contains multiple lines of
      text (using the %newline% pattern). Set to zero for the default value.
  $name: Top line style (Windows 11 version 22H2 and newer)
- DateStyle:
  - Hidden: false
  - TextColor: ""
    $name: Text color
    $description: >-
      Can be a color name (Red, Black, ...) or an RGB/ARGB color code (like
      #00FF00, #CC00FF00, ...).
  - TextAlignment: ""
    $name: Text alignment
    $options:
    - "": Default
    - Right: Right
    - Center: Center
    - Left: Left
    - Justify: Justified
  - FontSize: 0
    $name: Font size
    $description: Set to zero for the default size.
  - FontFamily: ""
    $name: Font family
    $description: >-
      For a list of fonts that are shipped with Windows 11, refer to the
      following page:

      https://learn.microsoft.com/en-us/typography/fonts/windows_11_font_list
  - FontWeight: ""
    $name: Font weight
    $options:
    - "": Default
    - Thin: Thin
    - ExtraLight: Extra light
    - Light: Light
    - SemiLight: Semi light
    - Normal: Normal
    - Medium: Medium
    - SemiBold: Semi bold
    - Bold: Bold
    - ExtraBold: Extra bold
    - Black: Black
    - ExtraBlack: Extra black
  - FontStyle: ""
    $name: Font style
    $options:
    - "": Default
    - Normal: Normal
    - Oblique: Oblique
    - Italic: Italic
  - FontStretch: ""
    $name: Font stretch
    $description: Only supported by some fonts.
    $options:
    - "": Default
    - Undefined: Undefined
    - UltraCondensed: Ultra condensed
    - ExtraCondensed: Extra condensed
    - Condensed: Condensed
    - SemiCondensed: Semi condensed
    - Normal: Normal
    - SemiExpanded: Semi expanded
    - Expanded: Expanded
    - ExtraExpanded: Extra expanded
    - UltraExpanded: Ultra expanded
  - CharacterSpacing: 0
    $name: Character spacing
    $description: Can be a positive or a negative number.
  - LineHeight: 0
    $name: Line height
    $description: >-
      The line height in pixels, useful when the line contains multiple lines of
      text (using the %newline% pattern). Set to zero for the default value.
  $name: Bottom line style (Windows 11 version 22H2 and newer)
- oldTaskbarOnWin11: false
  $name: Customize the old taskbar on Windows 11
  $description: >-
    Enable this option to customize the old taskbar on Windows 11 (if using
    ExplorerPatcher or a similar tool).
*/
// ==/WindhawkModSettings==

#include <windhawk_utils.h>

using WindhawkUtils::StringSetting;

#include <algorithm>
#include <atomic>
#include <functional>
#include <mutex>
#include <optional>
#include <regex>
#include <string>
#include <string_view>
#include <unordered_set>
#include <vector>

using namespace std::string_view_literals;

#include <initguid.h>  // Must come before mshtml.h

#include <comutil.h>
#include <dxgi.h>
#include <mshtmdid.h>
#include <mshtml.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <powrprof.h>
#include <psapi.h>
#include <shlwapi.h>
#include <wininet.h>

#undef GetCurrentTime

#include <winrt/Windows.Data.Xml.Dom.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.UI.Xaml.Controls.h>
#include <winrt/Windows.UI.Xaml.Interop.h>
#include <winrt/Windows.UI.Xaml.Markup.h>
#include <winrt/Windows.UI.Xaml.Media.h>
#include <winrt/base.h>

using namespace winrt::Windows::UI::Xaml;

// For Windhawk 1.4 and earlier compatibility.
#ifndef URL_ESCAPE_ASCII_URI_COMPONENT
#define URL_ESCAPE_ASCII_URI_COMPONENT 0x00080000
#endif

enum class TooltipLineMode {
    append,
    replace,
};

enum class NetworkMetricsFormat {
    mbs,
    mbsNumberOnly,
    mbsDynamic,
    mbits,
    mbitsNumberOnly,
    mbitsDynamic,
};

enum class PercentageFormat {
    spacePaddingAndSymbol,
    spacePadding,
    singleSpacePadding,
    zeroPadding,
    noPadding,
};

struct DataCollectionSettings {
    NetworkMetricsFormat networkMetricsFormat;
    int networkMetricsFixedDecimals;
    NetworkMetricsFormat diskMetricsFormat;
    int diskMetricsFixedDecimals;
    PercentageFormat percentageFormat;
    int updateInterval;
    StringSetting networkAdapterName;
    StringSetting gpuAdapterName;
};

struct MediaPlayerSettings {
    std::vector<StringSetting> ignoredPlayers;
    int maxLength;
    StringSetting mediaInfoFormat;
    StringSetting noMediaText;
    bool removeBrackets;
};

enum class WebContentWeatherUnits {
    autoDetect,
    uscs,
    metric,
    metricMsWind,
};

enum class ContentMode {
    plainText,
    html,
    xml,
    xmlHtml,
};

struct WebContentsSettings {
    StringSetting url;
    StringSetting blockStart;
    StringSetting start;
    StringSetting end;
    ContentMode contentMode;
    std::vector<std::pair<std::wregex, std::wstring>> searchReplace;
    int maxLength;
};

struct TextStyleSettings {
    bool hidden;
    StringSetting textColor;
    StringSetting textAlignment;
    int fontSize;
    StringSetting fontFamily;
    StringSetting fontWeight;
    StringSetting fontStyle;
    StringSetting fontStretch;
    int characterSpacing;
    int lineHeight;
};

struct ClockElementStyleSettings {
    int maxWidth;
    int textSpacing;
    TextStyleSettings timeStyle;
    TextStyleSettings dateStyle;
};

struct {
    bool showSeconds;
    StringSetting timeFormat;
    StringSetting dateFormat;
    std::vector<std::wstring> dateLocales;
    StringSetting weekdayFormat;
    std::vector<std::wstring> weekdayFormatCustom;
    StringSetting topLine;
    StringSetting bottomLine;
    StringSetting middleLine;
    StringSetting tooltipLine;
    TooltipLineMode tooltipLineMode;
    int width;
    int height;
    int textSpacing;
    DataCollectionSettings dataCollection;
    MediaPlayerSettings mediaPlayer;
    StringSetting webContentWeatherLocation;
    StringSetting webContentWeatherFormat;
    WebContentWeatherUnits webContentWeatherUnits;
    std::vector<WebContentsSettings> webContentsItems;
    int webContentsUpdateInterval;
    std::vector<StringSetting> timeZones;
    bool oldTaskbarOnWin11;

    // Kept for compatibility with old settings:
    StringSetting webContentsUrl;
    StringSetting webContentsBlockStart;
    StringSetting webContentsStart;
    StringSetting webContentsEnd;
    int webContentsMaxLength;
} g_settings;

#define FORMATTED_BUFFER_SIZE 256
#define INTEGER_BUFFER_SIZE sizeof("-2147483648")

enum class WinVersion {
    Unsupported,
    Win10,
    Win11,
    Win11_22H2,
    Win11_24H2,
};

WinVersion g_winVersion;

std::atomic<bool> g_systemTrayModuleHooked;
std::atomic<bool> g_initialized;
std::atomic<bool> g_explorerPatcherInitialized;

bool g_formattingInitialized;

DWORD g_formatIndex;
SYSTEMTIME g_formatTime;

// Guards g_settings and the formatting state derived from it: the format
// time/index, the cached formatted strings, the data collection session and
// the web content/media initialization flags. Settings are replaced wholesale
// by LoadSettings, which frees the previous string buffers, so a hook must
// hold this lock for as long as it uses anything from g_settings.
std::mutex g_formatLineMutex;

template <size_t N>
struct FormattedString {
    DWORD formatIndex;
    WCHAR buffer[N];
};

FormattedString<FORMATTED_BUFFER_SIZE> g_timeFormatted;
std::vector<std::wstring> g_timeFormattedExtra;
std::vector<FormattedString<FORMATTED_BUFFER_SIZE>> g_timeFormattedTz;
FormattedString<FORMATTED_BUFFER_SIZE> g_dateFormatted;
std::vector<std::wstring> g_dateFormattedExtra;
std::vector<FormattedString<FORMATTED_BUFFER_SIZE>> g_dateFormattedTz;
FormattedString<FORMATTED_BUFFER_SIZE> g_weekdayFormatted;
std::vector<FormattedString<FORMATTED_BUFFER_SIZE>> g_weekdayFormattedTz;
FormattedString<INTEGER_BUFFER_SIZE> g_weekdayNumFormatted;
FormattedString<INTEGER_BUFFER_SIZE> g_weeknumFormatted;
FormattedString<INTEGER_BUFFER_SIZE> g_weeknumIsoFormatted;
FormattedString<INTEGER_BUFFER_SIZE> g_dayOfYearFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_timezoneFormatted;

FormattedString<FORMATTED_BUFFER_SIZE> g_uploadSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_downloadSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_totalSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_diskReadSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_diskWriteSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_diskTotalSpeedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_cpuFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramUsedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramTotalFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramCommittedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramCommittedUsedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_ramCommittedTotalFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_gpuFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramUsedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramTotalFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramSharedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramSharedUsedFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_vramSharedTotalFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_cpuTempFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_cpuTempFFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_gpuTempFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_gpuTempFFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_batteryFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_batteryTimeFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_powerFormatted;

FormattedString<FORMATTED_BUFFER_SIZE> g_mediaTitleFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_mediaArtistFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_mediaAlbumFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_mediaStatusFormatted;
FormattedString<FORMATTED_BUFFER_SIZE> g_mediaInfoFormatted;

[[clang::no_destroy]] winrt::Windows::Media::Control::
    GlobalSystemMediaTransportControlsSessionManager g_mediaSessionManager{
        nullptr};
[[clang::no_destroy]] winrt::Windows::Media::Control::
    GlobalSystemMediaTransportControlsSession g_mediaCurrentSession{nullptr};
// Guards the media session objects, their event tokens and the formatted
// media strings. The session events fire on arbitrary thread pool threads, so
// this covers the subscribe/unsubscribe paths as well as the refresh. When
// both are taken, g_formatLineMutex comes first.
std::mutex g_mediaMutex;
std::atomic<bool> g_mediaDataDirty{true};
winrt::event_token g_mediaSessionsChangedToken;
winrt::event_token g_mediaPropertiesChangedToken;
winrt::event_token g_mediaPlaybackChangedToken;

// Lowercased copy of g_settings.mediaPlayer.ignoredPlayers, so that picking a
// session doesn't have to reach into g_settings from a thread pool thread.
std::vector<std::wstring> g_mediaIgnoredPlayers;

bool g_mediaActive = false;

// Whether a media pattern is shown. Media changes arrive as events, so the
// clock refreshes every second to show them without a delay.
bool g_mediaPatternUsed = false;

// Set while %media_info% expands its format string, to keep a stray
// %media_info% tag inside that format from recursing into itself.
bool g_inMediaInfoFormat = false;

std::vector<std::optional<DYNAMIC_TIME_ZONE_INFORMATION>> g_timeZoneInformation;

std::atomic<HANDLE> g_webContentUpdateThread;
HANDLE g_webContentUpdateRefreshEvent;
HANDLE g_webContentUpdateStopEvent;
std::mutex g_webContentMutex;
std::atomic<bool> g_webContentLoaded;

std::vector<std::optional<std::wstring>> g_webContentStrings;
std::vector<std::optional<std::wstring>> g_webContentStringsFull;
std::optional<std::wstring> g_webContentWeather;

// Kept for compatibility with old settings:
WCHAR g_webContent[FORMATTED_BUFFER_SIZE];
WCHAR g_webContentFull[FORMATTED_BUFFER_SIZE];

struct ClockElementStyleData {
    winrt::weak_ref<FrameworkElement> dateTimeIconContentElement;
    DWORD styleIndex;
    std::optional<int64_t> dateVisibilityPropertyChangedToken;
    std::optional<int64_t> timeVisibilityPropertyChangedToken;
};

// Guards the clock element style settings, their enabled flag and index, and
// g_clockElementStyleData. The style settings are kept out of g_settings so
// that the XAML thread applying them never waits for g_formatLineMutex, which
// formatting holds across slow work. When both are taken, g_formatLineMutex
// comes first.
std::mutex g_clockElementStyleMutex;
bool g_clockElementStyleEnabled;
DWORD g_clockElementStyleIndex;
ClockElementStyleSettings g_clockElementStyleSettings;
std::vector<ClockElementStyleData> g_clockElementStyleData;

using GetDpiForWindow_t = UINT(WINAPI*)(HWND hwnd);
GetDpiForWindow_t pGetDpiForWindow;

using SystemTimeToTzSpecificLocalTimeEx_t =
    BOOL(WINAPI*)(const DYNAMIC_TIME_ZONE_INFORMATION* lpTimeZoneInformation,
                  const SYSTEMTIME* lpUniversalTime,
                  LPSYSTEMTIME lpLocalTime);
SystemTimeToTzSpecificLocalTimeEx_t pSystemTimeToTzSpecificLocalTimeEx;

using EnumDynamicTimeZoneInformation_t =
    DWORD(WINAPI*)(const DWORD dwIndex,
                   PDYNAMIC_TIME_ZONE_INFORMATION lpTimeZoneInformation);
EnumDynamicTimeZoneInformation_t pEnumDynamicTimeZoneInformation;

using GetLocalTime_t = decltype(&GetLocalTime);
GetLocalTime_t GetLocalTime_Original;

using GetTimeFormatEx_t = decltype(&GetTimeFormatEx);
GetTimeFormatEx_t GetTimeFormatEx_Original;

using GetDateFormatEx_t = decltype(&GetDateFormatEx);
GetDateFormatEx_t GetDateFormatEx_Original;

using GetDateFormatW_t = decltype(&GetDateFormatW);
GetDateFormatW_t GetDateFormatW_Original;

using SendMessageW_t = decltype(&SendMessageW);
SendMessageW_t SendMessageW_Original;

// The WinINet defaults are minutes long, which would hold up whoever waits for
// the requesting thread to finish.
constexpr DWORD kUrlRequestTimeoutMs = 30 * 1000;

std::mutex g_urlRequestMutex;
HINTERNET g_urlRequestOpenHandle = nullptr;
HINTERNET g_urlRequestUrlHandle = nullptr;
bool g_urlRequestsCanceled = false;

// Requires g_urlRequestMutex to be held.
void CloseUrlRequestHandles() {
    if (g_urlRequestUrlHandle) {
        InternetCloseHandle(g_urlRequestUrlHandle);
        g_urlRequestUrlHandle = nullptr;
    }

    if (g_urlRequestOpenHandle) {
        InternetCloseHandle(g_urlRequestOpenHandle);
        g_urlRequestOpenHandle = nullptr;
    }
}

// Closes the handles of the request in flight, if any, which makes the blocking
// WinINet call using them return at once. Further requests fail until
// ResumeUrlRequests is called.
void CancelUrlRequests() {
    std::lock_guard<std::mutex> guard(g_urlRequestMutex);
    g_urlRequestsCanceled = true;
    CloseUrlRequestHandles();
}

void ResumeUrlRequests() {
    std::lock_guard<std::mutex> guard(g_urlRequestMutex);
    g_urlRequestsCanceled = false;
}

// Scope of a single request. At most one request runs at a time, so its handles
// live in globals where CancelUrlRequests can reach them.
struct UrlRequestScope {
    UrlRequestScope() = default;
    UrlRequestScope(const UrlRequestScope&) = delete;
    UrlRequestScope& operator=(const UrlRequestScope&) = delete;

    ~UrlRequestScope() {
        std::lock_guard<std::mutex> guard(g_urlRequestMutex);
        CloseUrlRequestHandles();
    }

    bool PublishOpenHandle(HINTERNET handle) {
        return Publish(&g_urlRequestOpenHandle, handle);
    }

    bool PublishUrlHandle(HINTERNET handle) {
        return Publish(&g_urlRequestUrlHandle, handle);
    }

   private:
    // Hands the handle over to the globals. Returns false if requests are
    // canceled, in which case the handle is closed and must not be used.
    static bool Publish(HINTERNET* slot, HINTERNET handle) {
        std::lock_guard<std::mutex> guard(g_urlRequestMutex);
        if (g_urlRequestsCanceled) {
            InternetCloseHandle(handle);
            return false;
        }

        *slot = handle;
        return true;
    }
};

std::optional<std::wstring> GetUrlContent(PCWSTR lpUrl,
                                          bool failIfNot200 = true) {
    UrlRequestScope requestScope;

    HINTERNET hOpenHandle = InternetOpen(
        L"WindhawkMod", INTERNET_OPEN_TYPE_PRECONFIG, nullptr, nullptr, 0);
    if (!hOpenHandle) {
        return std::nullopt;
    }

    if (!requestScope.PublishOpenHandle(hOpenHandle)) {
        return std::nullopt;
    }

    DWORD timeout = kUrlRequestTimeoutMs;
    InternetSetOption(hOpenHandle, INTERNET_OPTION_CONNECT_TIMEOUT, &timeout,
                      sizeof(timeout));
    InternetSetOption(hOpenHandle, INTERNET_OPTION_SEND_TIMEOUT, &timeout,
                      sizeof(timeout));
    InternetSetOption(hOpenHandle, INTERNET_OPTION_RECEIVE_TIMEOUT, &timeout,
                      sizeof(timeout));

    HINTERNET hUrlHandle =
        InternetOpenUrl(hOpenHandle, lpUrl, nullptr, 0,
                        INTERNET_FLAG_NO_AUTH | INTERNET_FLAG_NO_CACHE_WRITE |
                            INTERNET_FLAG_NO_COOKIES | INTERNET_FLAG_NO_UI |
                            INTERNET_FLAG_PRAGMA_NOCACHE | INTERNET_FLAG_RELOAD,
                        0);
    if (!hUrlHandle) {
        return std::nullopt;
    }

    if (!requestScope.PublishUrlHandle(hUrlHandle)) {
        return std::nullopt;
    }

    if (failIfNot200) {
        DWORD dwStatusCode = 0;
        DWORD dwStatusCodeSize = sizeof(dwStatusCode);
        if (!HttpQueryInfo(hUrlHandle,
                           HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
                           &dwStatusCode, &dwStatusCodeSize, nullptr) ||
            dwStatusCode != 200) {
            return std::nullopt;
        }
    }

    LPBYTE pUrlContent = (LPBYTE)HeapAlloc(GetProcessHeap(), 0, 0x400);
    if (!pUrlContent) {
        return std::nullopt;
    }

    DWORD dwNumberOfBytesRead;
    if (!InternetReadFile(hUrlHandle, pUrlContent, 0x400,
                          &dwNumberOfBytesRead)) {
        HeapFree(GetProcessHeap(), 0, pUrlContent);
        return std::nullopt;
    }

    DWORD dwLength = dwNumberOfBytesRead;

    while (dwNumberOfBytesRead) {
        LPBYTE pNewUrlContent = (LPBYTE)HeapReAlloc(
            GetProcessHeap(), 0, pUrlContent, dwLength + 0x400);
        if (!pNewUrlContent) {
            HeapFree(GetProcessHeap(), 0, pUrlContent);
            return std::nullopt;
        }

        pUrlContent = pNewUrlContent;
        if (!InternetReadFile(hUrlHandle, pUrlContent + dwLength, 0x400,
                              &dwNumberOfBytesRead)) {
            HeapFree(GetProcessHeap(), 0, pUrlContent);
            return std::nullopt;
        }

        dwLength += dwNumberOfBytesRead;
    }

    // Assume UTF-8.
    int charsNeeded = MultiByteToWideChar(CP_UTF8, 0, (PCSTR)pUrlContent,
                                          dwLength, nullptr, 0);
    std::wstring unicodeContent(charsNeeded, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, (PCSTR)pUrlContent, dwLength,
                        unicodeContent.data(), unicodeContent.size());

    HeapFree(GetProcessHeap(), 0, pUrlContent);

    return unicodeContent;
}

// https://stackoverflow.com/a/29752943
std::wstring ReplaceAll(std::wstring_view source,
                        std::wstring_view from,
                        std::wstring_view to) {
    std::wstring newString;

    size_t lastPos = 0;
    size_t findPos;

    while ((findPos = source.find(from, lastPos)) != source.npos) {
        newString.append(source, lastPos, findPos - lastPos);
        newString += to;
        lastPos = findPos + from.length();
    }

    // Care for the rest after last occurrence.
    newString += source.substr(lastPos);

    return newString;
}

// https://stackoverflow.com/a/54364173
std::wstring_view TrimStringView(std::wstring_view s) {
    s.remove_prefix(std::min(s.find_first_not_of(L" \t\r\v\n"), s.size()));
    s.remove_suffix(
        std::min(s.size() - s.find_last_not_of(L" \t\r\v\n") - 1, s.size()));
    return s;
}

// https://stackoverflow.com/a/46931770
std::vector<std::wstring_view> SplitStringView(std::wstring_view s,
                                               std::wstring_view delimiter) {
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    std::wstring_view token;
    std::vector<std::wstring_view> res;

    while ((pos_end = s.find(delimiter, pos_start)) !=
           std::wstring_view::npos) {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}

int StringCopyTruncated(PWSTR dest,
                        size_t destSize,
                        PCWSTR src,
                        bool* truncated) {
    if (destSize == 0) {
        *truncated = *src;
        return 0;
    }

    size_t i;
    for (i = 0; i < destSize - 1 && *src; i++) {
        *dest++ = *src++;
    }

    *dest = L'\0';
    *truncated = *src;
    return i;
}

int StringCopyTruncatedWithEllipsis(PWSTR dest, size_t destSize, PCWSTR src) {
    if (destSize == 0) {
        return 0;
    }

    bool truncated = false;
    size_t i = StringCopyTruncated(dest, destSize, src, &truncated);
    if (truncated && destSize >= 4) {
        dest[destSize - 4] = L'.';
        dest[destSize - 3] = L'.';
        dest[destSize - 2] = L'.';
        dest[destSize - 1] = L'\0';
    }
    return i;
}

std::wstring ExtractWebContent(std::wstring_view webContent,
                               PCWSTR webContentsBlockStart,
                               PCWSTR webContentsStart,
                               PCWSTR webContentsEnd) {
    auto block = webContent.find(webContentsBlockStart);
    if (block == webContent.npos) {
        return std::wstring();
    }

    auto start = webContent.find(webContentsStart, block);
    if (start == webContent.npos) {
        return std::wstring();
    }

    start += wcslen(webContentsStart);

    auto end = *webContentsEnd ? webContent.find(webContentsEnd, start)
                               : webContent.length();
    if (end == webContent.npos) {
        return std::wstring();
    }

    return std::wstring(webContent.substr(start, end - start));
}

// An MSHTML client site whose DLCONTROL ambient property disables scripts,
// ActiveX, Java, UI and all downloads.
class HtmlNoDownloadClientSite
    : public winrt::
          implements<HtmlNoDownloadClientSite, IOleClientSite, IDispatch> {
   public:
    // IOleClientSite
    HRESULT STDMETHODCALLTYPE SaveObject() override { return E_NOTIMPL; }

    HRESULT STDMETHODCALLTYPE GetMoniker(DWORD dwAssign,
                                         DWORD dwWhichMoniker,
                                         IMoniker** ppmk) override {
        *ppmk = nullptr;
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE
    GetContainer(IOleContainer** ppContainer) override {
        *ppContainer = nullptr;
        return E_NOINTERFACE;
    }

    HRESULT STDMETHODCALLTYPE ShowObject() override { return S_OK; }

    HRESULT STDMETHODCALLTYPE OnShowWindow(BOOL fShow) override { return S_OK; }

    HRESULT STDMETHODCALLTYPE RequestNewObjectLayout() override {
        return E_NOTIMPL;
    }

    // IDispatch
    HRESULT STDMETHODCALLTYPE GetTypeInfoCount(UINT* pctinfo) override {
        *pctinfo = 0;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetTypeInfo(UINT iTInfo,
                                          LCID lcid,
                                          ITypeInfo** ppTInfo) override {
        *ppTInfo = nullptr;
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE GetIDsOfNames(REFIID riid,
                                            LPOLESTR* rgszNames,
                                            UINT cNames,
                                            LCID lcid,
                                            DISPID* rgDispId) override {
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE Invoke(DISPID dispIdMember,
                                     REFIID riid,
                                     LCID lcid,
                                     WORD wFlags,
                                     DISPPARAMS* pDispParams,
                                     VARIANT* pVarResult,
                                     EXCEPINFO* pExcepInfo,
                                     UINT* puArgErr) override {
        if (dispIdMember != DISPID_AMBIENT_DLCONTROL || !pVarResult) {
            return DISP_E_MEMBERNOTFOUND;
        }

        // Omitting DLCTL_DLIMAGES, DLCTL_VIDEOS and DLCTL_BGSOUNDS disables
        // those downloads.
        V_VT(pVarResult) = VT_I4;
        V_I4(pVarResult) = DLCTL_NO_SCRIPTS | DLCTL_NO_JAVA |
                           DLCTL_NO_RUNACTIVEXCTLS | DLCTL_NO_DLACTIVEXCTLS |
                           DLCTL_NO_FRAMEDOWNLOAD | DLCTL_NO_BEHAVIORS |
                           DLCTL_NO_CLIENTPULL | DLCTL_SILENT |
                           DLCTL_FORCEOFFLINE;
        return S_OK;
    }
};

std::wstring ExtractTextFromHtml(std::wstring html) {
    winrt::com_ptr<IHTMLDocument2> doc;
    winrt::check_hresult(CoCreateInstance(CLSID_HTMLDocument, nullptr,
                                          CLSCTX_INPROC_SERVER,
                                          IID_IHTMLDocument2, doc.put_void()));
    if (!doc) {
        throw std::runtime_error("HTML document creation failed");
    }

    // The content is untrusted.
    auto oleObject = doc.as<IOleObject>();
    auto clientSite = winrt::make_self<HtmlNoDownloadClientSite>();
    winrt::check_hresult(oleObject->SetClientSite(clientSite.get()));

    // The site's code lives in the mod, so don't leave MSHTML holding it once
    // the document goes away, including on the error paths below.
    struct ClientSiteDetacher {
        IOleObject* oleObject;
        ~ClientSiteDetacher() { oleObject->SetClientSite(nullptr); }
    } clientSiteDetacher{oleObject.get()};

    // Prepare HTML content for processing.
    _bstr_t htmlBstr(
        SysAllocStringLen(html.data(), static_cast<UINT>(html.length())),
        /*fCopy=*/false);

    SAFEARRAY* psa = SafeArrayCreateVector(VT_VARIANT, 0, 1);
    if (!psa) {
        throw std::runtime_error("Failed to create SafeArray");
    }

    VARIANT* pva;
    HRESULT hr = SafeArrayAccessData(psa, reinterpret_cast<void**>(&pva));
    if (SUCCEEDED(hr)) {
        pva->vt = VT_BSTR;
        pva->bstrVal = htmlBstr.Detach();
        hr = SafeArrayUnaccessData(psa);
    }

    if (SUCCEEDED(hr)) {
        hr = doc->write(psa);
    }

    SafeArrayDestroy(psa);

    winrt::check_hresult(hr);

    // Extract plain text from the HTML document.
    winrt::com_ptr<IHTMLElement> body;
    winrt::check_hresult(doc->get_body(body.put()));
    if (!body) {
        return std::wstring();
    }

    _bstr_t text;
    winrt::check_hresult(body->get_innerText(text.GetAddress()));
    return std::wstring(text, text.length());
}

std::wstring ExtractTextFromXml(std::wstring xml) {
    xml = L"<root>" + xml + L"</root>";
    winrt::Windows::Data::Xml::Dom::XmlDocument xmlDoc;
    xmlDoc.LoadXml(winrt::hstring(xml));
    return std::wstring(xmlDoc.InnerText());
}

bool IsStrInDateTimePatternSettings(PCWSTR str) {
    if (wcsstr(g_settings.topLine, str) || wcsstr(g_settings.bottomLine, str) ||
        wcsstr(g_settings.middleLine, str) ||
        wcsstr(g_settings.tooltipLine, str)) {
        return true;
    }

    // The media info format strings are expanded as part of %media_info%, so
    // tags they contain (e.g. %cpu%) need their data collected too. Only search
    // them when %media_info% itself appears in a configured line.
    if (wcsstr(g_settings.topLine, L"%media_info%") ||
        wcsstr(g_settings.bottomLine, L"%media_info%") ||
        wcsstr(g_settings.middleLine, L"%media_info%") ||
        wcsstr(g_settings.tooltipLine, L"%media_info%")) {
        if (wcsstr(g_settings.mediaPlayer.mediaInfoFormat.get(), str) ||
            wcsstr(g_settings.mediaPlayer.noMediaText.get(), str)) {
            return true;
        }
    }

    return false;
}

std::wstring EscapeUrlComponent(PCWSTR input,
                                DWORD flags = URL_ESCAPE_ASCII_URI_COMPONENT |
                                              URL_ESCAPE_AS_UTF8) {
    WCHAR outStack[256];
    DWORD needed = ARRAYSIZE(outStack);
    HRESULT hr = UrlEscape(input, outStack, &needed, flags);
    if (SUCCEEDED(hr)) {
        return outStack;
    }

    if (hr != E_POINTER || needed < 1) {
        Wh_Log(L"UrlEscape error %08X", hr);
        return std::wstring();
    }

    std::wstring out(needed - 1, L'\0');
    hr = UrlEscape(input, &out[0], &needed, flags);
    if (FAILED(hr)) {
        Wh_Log(L"UrlEscape error %08X", hr);
        return std::wstring();
    }

    return out;
}

bool UpdateWeatherWebContent() {
    std::wstring format = g_settings.webContentWeatherFormat.get();
    if (format.empty()) {
        format = L"%c \U0001F321\uFE0F%t \U0001F32C\uFE0F%w";
    }

    // Spaces are added after the weather emoji by the server. Add a marker
    // character after it to be able to remove the spaces. See:
    // https://github.com/chubin/wttr.in/issues/345
    format = ReplaceAll(format, L"%c", L"%c\uE000");

    std::wstring weatherUrl = L"https://wttr.in/";
    weatherUrl += EscapeUrlComponent(g_settings.webContentWeatherLocation);
    weatherUrl += L'?';
    switch (g_settings.webContentWeatherUnits) {
        case WebContentWeatherUnits::autoDetect:
            break;
        case WebContentWeatherUnits::uscs:
            weatherUrl += L"u&";
            break;
        case WebContentWeatherUnits::metric:
            weatherUrl += L"m&";
            break;
        case WebContentWeatherUnits::metricMsWind:
            weatherUrl += L"M&";
            break;
    }
    weatherUrl += L"format=";
    weatherUrl += EscapeUrlComponent(format.c_str());

    Wh_Log(L"Fetching weather from URL: %s", weatherUrl.c_str());

    std::optional<std::wstring> urlContent = GetUrlContent(weatherUrl.c_str());
    if (!urlContent) {
        return false;
    }

    // Ignore non-weather responses.
    if (urlContent->empty() ||
        *urlContent == L"This query is already being processed") {
        return false;
    }

    // Remove spaces after the %c emoji.
    std::wstring weatherContent;

    size_t lastPos = 0;
    size_t findPos;

    while ((findPos = urlContent->find(L'\uE000', lastPos)) !=
           urlContent->npos) {
        size_t lastPosCount = findPos - lastPos;
        while (lastPosCount > 0 &&
               urlContent->at(lastPos + lastPosCount - 1) == L' ') {
            lastPosCount--;
        }

        weatherContent.append(*urlContent, lastPos, lastPosCount);
        lastPos = findPos + 1;
    }

    // Care for the rest after last occurrence.
    weatherContent += urlContent->substr(lastPos);

    std::lock_guard<std::mutex> guard(g_webContentMutex);
    g_webContentWeather = weatherContent;

    return true;
}

void UpdateWebContent() {
    int failed = 0;

    std::wstring lastUrl;
    std::optional<std::wstring> urlContent;

    // Kept for compatibility with old settings:
    if (g_settings.webContentsUrl && g_settings.webContentsBlockStart &&
        g_settings.webContentsStart && g_settings.webContentsEnd) {
        lastUrl = g_settings.webContentsUrl;
        urlContent =
            GetUrlContent(g_settings.webContentsUrl, /*failIfNot200=*/false);

        std::wstring extracted;
        if (urlContent) {
            extracted = ExtractWebContent(
                *urlContent, g_settings.webContentsBlockStart,
                g_settings.webContentsStart, g_settings.webContentsEnd);

            std::lock_guard<std::mutex> guard(g_webContentMutex);

            int maxLen = ARRAYSIZE(g_webContent) - 1;
            if (g_settings.webContentsMaxLength > 0 &&
                g_settings.webContentsMaxLength < maxLen) {
                maxLen = g_settings.webContentsMaxLength;
            }

            StringCopyTruncatedWithEllipsis(g_webContent, maxLen + 1,
                                            extracted.c_str());

            StringCopyTruncatedWithEllipsis(g_webContentFull,
                                            ARRAYSIZE(g_webContentFull),
                                            extracted.c_str());
        } else {
            failed++;
        }
    }

    for (size_t i = 0; i < g_settings.webContentsItems.size(); i++) {
        WCHAR patternSubstring[32];
        swprintf_s(patternSubstring, L"%%web%i%%", i + 1);

        WCHAR patternSubstringFull[32];
        swprintf_s(patternSubstringFull, L"%%web%i_full%%", i + 1);

        if (!IsStrInDateTimePatternSettings(patternSubstring) &&
            !IsStrInDateTimePatternSettings(patternSubstringFull)) {
            continue;
        }

        const auto& item = g_settings.webContentsItems[i];

        if (item.url.get() != lastUrl) {
            lastUrl = item.url;
            urlContent = GetUrlContent(item.url, /*failIfNot200=*/false);
        }

        if (!urlContent) {
            failed++;
            continue;
        }

        std::wstring extracted = ExtractWebContent(*urlContent, item.blockStart,
                                                   item.start, item.end);

        try {
            switch (item.contentMode) {
                case ContentMode::plainText:
                    break;

                case ContentMode::html:
                    extracted = ExtractTextFromHtml(extracted);
                    break;

                case ContentMode::xml:
                    extracted = ExtractTextFromXml(extracted);
                    break;

                case ContentMode::xmlHtml:
                    extracted =
                        ExtractTextFromHtml(ExtractTextFromXml(extracted));
                    break;
            }
        } catch (const winrt::hresult_error& ex) {
            WCHAR buffer[256];
            _snwprintf_s(buffer, _TRUNCATE, L"Content error %08X: %s",
                         ex.code().value, ex.message().c_str());
            extracted = buffer;
        } catch (const std::exception& ex) {
            WCHAR buffer[256];
            _snwprintf_s(buffer, _TRUNCATE, L"Content error: %S", ex.what());
            extracted = buffer;
        }

        for (const auto& [s, r] : item.searchReplace) {
            try {
                extracted = std::regex_replace(extracted, s, r);
            } catch (const std::regex_error& ex) {
                Wh_Log(L"Search/replace error %08X: %S",
                       static_cast<DWORD>(ex.code()), ex.what());
            }
        }

        std::lock_guard<std::mutex> guard(g_webContentMutex);

        if (item.maxLength <= 0 ||
            extracted.length() <= (size_t)item.maxLength) {
            g_webContentStrings[i] = extracted;
        } else {
            std::wstring truncated(extracted.begin(),
                                   extracted.begin() + item.maxLength);
            if (truncated.length() >= 3) {
                truncated[truncated.length() - 1] = L'.';
                truncated[truncated.length() - 2] = L'.';
                truncated[truncated.length() - 3] = L'.';
            }

            g_webContentStrings[i] = std::move(truncated);
        }

        g_webContentStringsFull[i] = std::move(extracted);
    }

    if (IsStrInDateTimePatternSettings(L"%weather%") &&
        !UpdateWeatherWebContent()) {
        failed++;
    }

    if (failed == 0) {
        g_webContentLoaded = true;
    }
}

DWORD WINAPI WebContentUpdateThread(LPVOID lpThreadParameter) {
    constexpr DWORD kSecondsForQuickRetry = 30;

    HANDLE handles[] = {
        g_webContentUpdateStopEvent,
        g_webContentUpdateRefreshEvent,
    };

    while (true) {
        UpdateWebContent();

        DWORD seconds = std::max(g_settings.webContentsUpdateInterval, 1) * 60;
        if (!g_webContentLoaded && seconds > kSecondsForQuickRetry) {
            seconds = kSecondsForQuickRetry;
        }

        DWORD dwWaitResult = WaitForMultipleObjects(ARRAYSIZE(handles), handles,
                                                    FALSE, seconds * 1000);

        if (dwWaitResult == WAIT_FAILED) {
            Wh_Log(L"WAIT_FAILED");
            break;
        }

        if (dwWaitResult == WAIT_OBJECT_0) {
            break;
        }
    }

    return 0;
}

void WebContentUpdateThreadInit() {
    std::lock_guard<std::mutex> guard(g_webContentMutex);

    g_webContentStrings.resize(g_settings.webContentsItems.size());
    g_webContentStringsFull.resize(g_settings.webContentsItems.size());

    // A fuzzy check to see if any of the lines contain the web content pattern.
    // If not, no need to fire up the thread.
    if (IsStrInDateTimePatternSettings(L"%web") ||
        IsStrInDateTimePatternSettings(L"%weather%")) {
        g_webContentUpdateRefreshEvent =
            CreateEvent(nullptr, FALSE, FALSE, nullptr);
        g_webContentUpdateStopEvent =
            CreateEvent(nullptr, TRUE, FALSE, nullptr);
        g_webContentUpdateThread = CreateThread(
            nullptr, 0, WebContentUpdateThread, nullptr, 0, nullptr);
    }
}

void WebContentUpdateThreadUninit() {
    HANDLE thread;
    HANDLE stopEvent;
    HANDLE refreshEvent;

    {
        std::lock_guard<std::mutex> guard(g_webContentMutex);
        thread = g_webContentUpdateThread;
        stopEvent = g_webContentUpdateStopEvent;
        refreshEvent = g_webContentUpdateRefreshEvent;
        g_webContentUpdateThread = nullptr;
        g_webContentUpdateStopEvent = nullptr;
        g_webContentUpdateRefreshEvent = nullptr;
    }

    if (thread) {
        SetEvent(stopEvent);
        CancelUrlRequests();
        WaitForSingleObject(thread, INFINITE);
        CloseHandle(thread);
        CloseHandle(refreshEvent);
        CloseHandle(stopEvent);
        ResumeUrlRequests();
    }

    std::lock_guard<std::mutex> guard(g_webContentMutex);

    g_webContentLoaded = false;

    *g_webContent = L'\0';
    *g_webContentFull = L'\0';

    g_webContentStrings.clear();
    g_webContentStringsFull.clear();
    g_webContentWeather.reset();
}

std::optional<DYNAMIC_TIME_ZONE_INFORMATION> GetTimeZoneInformation(
    PCWSTR timeZone) {
    if (!pEnumDynamicTimeZoneInformation) {
        return std::nullopt;
    }

    DWORD i = 0;
    DWORD dwResult;
    do {
        DYNAMIC_TIME_ZONE_INFORMATION dynamicTimezone;
        dwResult = pEnumDynamicTimeZoneInformation(i++, &dynamicTimezone);
        if (dwResult == ERROR_SUCCESS &&
            _wcsicmp(dynamicTimezone.TimeZoneKeyName, timeZone) == 0) {
            return dynamicTimezone;
        }
    } while (dwResult != ERROR_NO_MORE_ITEMS);

    return std::nullopt;
}

DWORD GetStartDayOfWeek(const SYSTEMTIME* time) {
    // https://stackoverflow.com/a/39344961
    DWORD startDayOfWeek;
    GetLocaleInfoEx(
        LOCALE_NAME_USER_DEFAULT, LOCALE_IFIRSTDAYOFWEEK | LOCALE_RETURN_NUMBER,
        (PWSTR)&startDayOfWeek, sizeof(startDayOfWeek) / sizeof(WCHAR));

    // Start from Sunday instead of Monday.
    startDayOfWeek = (startDayOfWeek + 1) % 7;

    return startDayOfWeek;
}

int CalculateWeeknum(const SYSTEMTIME* time, DWORD startDayOfWeek) {
    SYSTEMTIME secondWeek{
        .wYear = time->wYear,
        .wMonth = 1,
        .wDay = 1,
    };

    // Calculate wDayOfWeek.
    FILETIME fileTime;
    SystemTimeToFileTime(&secondWeek, &fileTime);
    FileTimeToSystemTime(&fileTime, &secondWeek);

    do {
        secondWeek.wDay++;
        secondWeek.wDayOfWeek = (secondWeek.wDayOfWeek + 1) % 7;
    } while (secondWeek.wDayOfWeek != startDayOfWeek);

    FILETIME targetFileTime;
    SystemTimeToFileTime(time, &targetFileTime);
    ULARGE_INTEGER targetFileTimeInt{
        .LowPart = targetFileTime.dwLowDateTime,
        .HighPart = targetFileTime.dwHighDateTime,
    };

    FILETIME secondWeekFileTime;
    SystemTimeToFileTime(&secondWeek, &secondWeekFileTime);
    ULARGE_INTEGER secondWeekFileTimeInt{
        .LowPart = secondWeekFileTime.dwLowDateTime,
        .HighPart = secondWeekFileTime.dwHighDateTime,
    };

    int weeknum = 1;
    if (targetFileTimeInt.QuadPart >= secondWeekFileTimeInt.QuadPart) {
        ULONGLONG diff =
            targetFileTimeInt.QuadPart - secondWeekFileTimeInt.QuadPart;
        ULONGLONG weekIn100Ns = 10000000ULL * 60 * 60 * 24 * 7;
        weeknum += 1 + diff / weekIn100Ns;
    }

    return weeknum;
}

// Adopted from VMime:
// https://github.com/kisli/vmime/blob/fc69321d5304c73be685c890f3b30528aadcfeaf/src/vmime/utility/datetimeUtils.cpp#L239
int CalculateWeeknumIso(const SYSTEMTIME* time) {
    const int year = time->wYear;
    const int month = time->wMonth;
    const int day = time->wDay;
    const bool iso = true;

    // Algorithm from http://personal.ecu.edu/mccartyr/ISOwdALG.txt

    const bool leapYear =
        ((year % 4) == 0 && (year % 100) != 0) || (year % 400) == 0;
    const bool leapYear_1 =
        (((year - 1) % 4) == 0 && ((year - 1) % 100) != 0) ||
        ((year - 1) % 400) == 0;

    // 4. Find the DayOfYearNumber for Y M D
    static const int DAY_OF_YEAR_NUMBER_MAP[12] = {
        0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};

    int DayOfYearNumber = day + DAY_OF_YEAR_NUMBER_MAP[month - 1];

    if (leapYear && month > 2) {
        DayOfYearNumber += 1;
    }

    // 5. Find the Jan1Weekday for Y (Monday=1, Sunday=7)
    const int YY = (year - 1) % 100;
    const int C = (year - 1) - YY;
    const int G = YY + YY / 4;
    const int Jan1Weekday = 1 + (((((C / 100) % 4) * 5) + G) % 7);

    // 6. Find the Weekday for Y M D
    const int H = DayOfYearNumber + (Jan1Weekday - 1);
    const int Weekday = 1 + ((H - 1) % 7);

    // 7. Find if Y M D falls in YearNumber Y-1, WeekNumber 52 or 53
    int YearNumber = 0, WeekNumber = 0;

    if (DayOfYearNumber <= (8 - Jan1Weekday) && Jan1Weekday > 4) {
        YearNumber = year - 1;

        if (Jan1Weekday == 5 || (Jan1Weekday == 6 && leapYear_1)) {
            WeekNumber = 53;
        } else {
            WeekNumber = 52;
        }

    } else {
        YearNumber = year;
    }

    // 8. Find if Y M D falls in YearNumber Y+1, WeekNumber 1
    if (YearNumber == year) {
        const int I = (leapYear ? 366 : 365);

        if ((I - DayOfYearNumber) < (4 - Weekday)) {
            YearNumber = year + 1;
            WeekNumber = 1;
        }
    }

    // 9. Find if Y M D falls in YearNumber Y, WeekNumber 1 through 53
    if (YearNumber == year) {
        const int J = DayOfYearNumber + (7 - Weekday) + (Jan1Weekday - 1);

        WeekNumber = J / 7;

        if (Jan1Weekday > 4) {
            WeekNumber -= 1;
        }
    }

    if (!iso && (WeekNumber == 1 && month == 12)) {
        WeekNumber = 53;
    }

    return WeekNumber;
}

// Adopted from VMime:
// https://github.com/kisli/vmime/blob/fc69321d5304c73be685c890f3b30528aadcfeaf/src/vmime/utility/datetimeUtils.cpp#L239
int CalculateDayOfYearNumber(const SYSTEMTIME* time) {
    const int year = time->wYear;
    const int month = time->wMonth;
    const int day = time->wDay;

    const bool leapYear =
        ((year % 4) == 0 && (year % 100) != 0) || (year % 400) == 0;

    static const int DAY_OF_YEAR_NUMBER_MAP[12] = {
        0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};

    int DayOfYearNumber = day + DAY_OF_YEAR_NUMBER_MAP[month - 1];

    if (leapYear && month > 2) {
        DayOfYearNumber += 1;
    }

    return DayOfYearNumber;
}

// Adopted from:
// https://github.com/microsoft/cpp_client_telemetry/blob/25bc0806f21ecb2587154494f073bfa581cd5089/lib/pal/desktop/WindowsEnvironmentInfo.hpp#L39
void GetTimeZone(WCHAR* buffer, size_t bufferSize) {
    long bias;

    TIME_ZONE_INFORMATION timeZone = {};
    if (GetTimeZoneInformation(&timeZone) == TIME_ZONE_ID_DAYLIGHT) {
        bias = timeZone.Bias + timeZone.DaylightBias;
    } else {
        // TODO: [MG] - ref.
        // https://docs.microsoft.com/en-us/windows/win32/api/timezoneapi/nf-timezoneapi-gettimezoneinformation
        // Need to handle the case when API return TIME_ZONE_ID_UNKNOWN.
        // Otherwise we may be reporting invalid timeZone.Bias
        bias = timeZone.Bias + timeZone.StandardBias;
    }

    auto hours = (long long)abs(bias) / 60;
    auto minutes = (long long)abs(bias) % 60;

    // UTC = local time + bias; bias sign should be interved.
    _snwprintf_s(buffer, bufferSize, _TRUNCATE, L"%c%02d:%02d",
                 bias <= 0 ? L'+' : L'-', static_cast<int>(hours),
                 static_cast<int>(minutes));
}

std::vector<std::wstring> SplitTimeFormatString(std::wstring_view s) {
    size_t posStart = 0;
    std::wstring token;
    std::vector<std::wstring> result;

    while (true) {
        size_t posEnd = s.size();
        bool inQuote = false;
        for (size_t i = posStart; i < s.size(); i++) {
            if (s[i] == L'\'') {
                inQuote = !inQuote;
                continue;
            }

            if (!inQuote && s[i] == L';') {
                posEnd = i;
                break;
            }
        }

        if (posEnd == s.size()) {
            break;
        }

        token = s.substr(posStart, posEnd - posStart);
        posStart = posEnd + 1;
        result.push_back(std::move(token));
    }

    token = s.substr(posStart);
    result.push_back(std::move(token));
    return result;
}

int GetTimeFormatExWithShowSeconds(LPCWSTR lpLocaleName,
                                   const SYSTEMTIME* lpTime,
                                   LPCWSTR lpFormat,
                                   LPWSTR lpTimeStr,
                                   int cchTime) {
    DWORD dwFlags = g_settings.showSeconds ? 0 : TIME_NOSECONDS;

    if (!g_settings.showSeconds && lpFormat) {
        std::wstring formatNoSeconds = ReplaceAll(lpFormat, L"':'ss", L"");
        return GetTimeFormatEx_Original(lpLocaleName, dwFlags, lpTime,
                                        formatNoSeconds.c_str(), lpTimeStr,
                                        cchTime);
    }

    return GetTimeFormatEx_Original(lpLocaleName, dwFlags, lpTime, lpFormat,
                                    lpTimeStr, cchTime);
}

PCWSTR GetTimeFormattedWithExtra(std::vector<std::wstring>** extra) {
    if (g_timeFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        auto timeFormatParts =
            SplitTimeFormatString(g_settings.timeFormat.get());

        GetTimeFormatExWithShowSeconds(
            nullptr, time,
            !timeFormatParts[0].empty() ? timeFormatParts[0].c_str() : nullptr,
            g_timeFormatted.buffer, ARRAYSIZE(g_timeFormatted.buffer));

        g_timeFormattedExtra.resize(timeFormatParts.size() - 1);
        for (size_t i = 1; i < timeFormatParts.size(); i++) {
            WCHAR formatted[FORMATTED_BUFFER_SIZE];
            GetTimeFormatExWithShowSeconds(nullptr, time,
                                           !timeFormatParts[i].empty()
                                               ? timeFormatParts[i].c_str()
                                               : nullptr,
                                           formatted, ARRAYSIZE(formatted));
            g_timeFormattedExtra[i - 1] = formatted;
        }

        g_timeFormatted.formatIndex = g_formatIndex;
    }

    if (extra) {
        *extra = &g_timeFormattedExtra;
    }

    return g_timeFormatted.buffer;
}

PCWSTR GetTimeFormatted() {
    return GetTimeFormattedWithExtra(nullptr);
}

std::vector<std::wstring>* GetTimeFormattedExtra() {
    std::vector<std::wstring>* extra;
    GetTimeFormattedWithExtra(&extra);
    return extra;
}

PCWSTR GetTimeFormattedTz(size_t index) {
    if (index >= g_settings.timeZones.size()) {
        return nullptr;
    }

    auto& timeFormattedTz = g_timeFormattedTz[index];

    if (timeFormattedTz.formatIndex != g_formatIndex) {
        const auto& timeZoneInformation = g_timeZoneInformation[index];
        if (timeZoneInformation && pSystemTimeToTzSpecificLocalTimeEx) {
            SYSTEMTIME systemTime;
            TzSpecificLocalTimeToSystemTime(nullptr, &g_formatTime,
                                            &systemTime);

            SYSTEMTIME timeTz;
            pSystemTimeToTzSpecificLocalTimeEx(&*timeZoneInformation,
                                               &systemTime, &timeTz);

            const SYSTEMTIME* time = &timeTz;

            auto timeFormatParts =
                SplitTimeFormatString(g_settings.timeFormat.get());

            GetTimeFormatExWithShowSeconds(
                nullptr, time,
                !timeFormatParts[0].empty() ? timeFormatParts[0].c_str()
                                            : nullptr,
                timeFormattedTz.buffer, ARRAYSIZE(timeFormattedTz.buffer));
        } else {
            wcscpy_s(timeFormattedTz.buffer, L"-");
        }

        timeFormattedTz.formatIndex = g_formatIndex;
    }

    return timeFormattedTz.buffer;
}

// Returns the locale of the date format at the given index, falling back to the
// first locale. GetDateFormatEx treats an empty locale name as the invariant
// locale, so return nullptr (the user's default locale) for an empty one.
PCWSTR GetDateLocaleName(size_t index) {
    const auto& locales = g_settings.dateLocales;
    if (index >= locales.size()) {
        index = 0;
    }

    return index < locales.size() && !locales[index].empty()
               ? locales[index].c_str()
               : nullptr;
}

PCWSTR GetDateFormattedWithExtra(std::vector<std::wstring>** extra) {
    if (g_dateFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        auto dateFormatParts =
            SplitTimeFormatString(g_settings.dateFormat.get());

        GetDateFormatEx_Original(
            GetDateLocaleName(0), DATE_AUTOLAYOUT, time,
            !dateFormatParts[0].empty() ? dateFormatParts[0].c_str() : nullptr,
            g_dateFormatted.buffer, ARRAYSIZE(g_dateFormatted.buffer), nullptr);

        g_dateFormattedExtra.resize(dateFormatParts.size() - 1);
        for (size_t i = 1; i < dateFormatParts.size(); i++) {
            WCHAR formatted[FORMATTED_BUFFER_SIZE];
            GetDateFormatEx_Original(
                GetDateLocaleName(i), DATE_AUTOLAYOUT, time,
                !dateFormatParts[i].empty() ? dateFormatParts[i].c_str()
                                            : nullptr,
                formatted, ARRAYSIZE(formatted), nullptr);
            g_dateFormattedExtra[i - 1] = formatted;
        }

        g_dateFormatted.formatIndex = g_formatIndex;
    }

    if (extra) {
        *extra = &g_dateFormattedExtra;
    }

    return g_dateFormatted.buffer;
}

PCWSTR GetDateFormatted() {
    return GetDateFormattedWithExtra(nullptr);
}

std::vector<std::wstring>* GetDateFormattedExtra() {
    std::vector<std::wstring>* extra;
    GetDateFormattedWithExtra(&extra);
    return extra;
}

PCWSTR GetDateFormattedTz(size_t index) {
    if (index >= g_settings.timeZones.size()) {
        return nullptr;
    }

    auto& dateFormattedTz = g_dateFormattedTz[index];

    if (dateFormattedTz.formatIndex != g_formatIndex) {
        const auto& timeZoneInformation = g_timeZoneInformation[index];
        if (timeZoneInformation && pSystemTimeToTzSpecificLocalTimeEx) {
            SYSTEMTIME systemTime;
            TzSpecificLocalTimeToSystemTime(nullptr, &g_formatTime,
                                            &systemTime);

            SYSTEMTIME timeTz;
            pSystemTimeToTzSpecificLocalTimeEx(&*timeZoneInformation,
                                               &systemTime, &timeTz);

            const SYSTEMTIME* time = &timeTz;

            auto dateFormatParts =
                SplitTimeFormatString(g_settings.dateFormat.get());

            GetDateFormatEx_Original(
                GetDateLocaleName(0), DATE_AUTOLAYOUT, time,
                !dateFormatParts[0].empty() ? dateFormatParts[0].c_str()
                                            : nullptr,
                dateFormattedTz.buffer, ARRAYSIZE(dateFormattedTz.buffer),
                nullptr);
        } else {
            wcscpy_s(dateFormattedTz.buffer, L"-");
        }

        dateFormattedTz.formatIndex = g_formatIndex;
    }

    return dateFormattedTz.buffer;
}

void FormatWeekday(const SYSTEMTIME* time, PWSTR buffer, size_t bufferSize) {
    if (g_settings.weekdayFormatCustom.empty()) {
        GetDateFormatEx_Original(GetDateLocaleName(0), DATE_AUTOLAYOUT, time,
                                 *g_settings.weekdayFormat
                                     ? g_settings.weekdayFormat.get()
                                     : L"dddd",
                                 buffer, bufferSize, nullptr);
    } else if (g_settings.weekdayFormatCustom.size() > time->wDayOfWeek) {
        // Copy truncated.
        wcsncpy_s(buffer, bufferSize,
                  g_settings.weekdayFormatCustom[time->wDayOfWeek].c_str(),
                  bufferSize - 1);
    } else {
        wcscpy_s(buffer, bufferSize, L"-");
    }
}

PCWSTR GetWeekdayFormatted() {
    if (g_weekdayFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        FormatWeekday(time, g_weekdayFormatted.buffer,
                      ARRAYSIZE(g_weekdayFormatted.buffer));

        g_weekdayFormatted.formatIndex = g_formatIndex;
    }

    return g_weekdayFormatted.buffer;
}

PCWSTR GetWeekdayFormattedTz(size_t index) {
    if (index >= g_settings.timeZones.size()) {
        return nullptr;
    }

    auto& weekdayFormattedTz = g_weekdayFormattedTz[index];

    if (weekdayFormattedTz.formatIndex != g_formatIndex) {
        const auto& timeZoneInformation = g_timeZoneInformation[index];
        if (timeZoneInformation && pSystemTimeToTzSpecificLocalTimeEx) {
            SYSTEMTIME systemTime;
            TzSpecificLocalTimeToSystemTime(nullptr, &g_formatTime,
                                            &systemTime);

            SYSTEMTIME timeTz;
            pSystemTimeToTzSpecificLocalTimeEx(&*timeZoneInformation,
                                               &systemTime, &timeTz);

            const SYSTEMTIME* time = &timeTz;

            FormatWeekday(time, weekdayFormattedTz.buffer,
                          ARRAYSIZE(weekdayFormattedTz.buffer));
        } else {
            wcscpy_s(weekdayFormattedTz.buffer, L"-");
        }

        weekdayFormattedTz.formatIndex = g_formatIndex;
    }

    return weekdayFormattedTz.buffer;
}

PCWSTR GetWeekdayNumFormatted() {
    if (g_weekdayNumFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        DWORD startDayOfWeek = GetStartDayOfWeek(time);

        swprintf_s(g_weekdayNumFormatted.buffer, L"%d",
                   1 + (7 + time->wDayOfWeek - startDayOfWeek) % 7);

        g_weekdayNumFormatted.formatIndex = g_formatIndex;
    }

    return g_weekdayNumFormatted.buffer;
}

PCWSTR GetWeeknumFormatted() {
    if (g_weeknumFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        DWORD startDayOfWeek = GetStartDayOfWeek(time);

        swprintf_s(g_weeknumFormatted.buffer, L"%02d",
                   CalculateWeeknum(time, startDayOfWeek));

        g_weeknumFormatted.formatIndex = g_formatIndex;
    }

    return g_weeknumFormatted.buffer;
}

PCWSTR GetWeeknumIsoFormatted() {
    if (g_weeknumIsoFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        swprintf_s(g_weeknumIsoFormatted.buffer, L"%02d",
                   CalculateWeeknumIso(time));

        g_weeknumIsoFormatted.formatIndex = g_formatIndex;
    }

    return g_weeknumIsoFormatted.buffer;
}

PCWSTR GetDayOfYearFormatted() {
    if (g_dayOfYearFormatted.formatIndex != g_formatIndex) {
        const SYSTEMTIME* time = &g_formatTime;

        swprintf_s(g_dayOfYearFormatted.buffer, L"%d",
                   CalculateDayOfYearNumber(time));

        g_dayOfYearFormatted.formatIndex = g_formatIndex;
    }

    return g_dayOfYearFormatted.buffer;
}

PCWSTR GetTimezoneFormatted() {
    if (g_timezoneFormatted.formatIndex != g_formatIndex) {
        GetTimeZone(g_timezoneFormatted.buffer,
                    ARRAYSIZE(g_timezoneFormatted.buffer));

        g_timezoneFormatted.formatIndex = g_formatIndex;
    }

    return g_timezoneFormatted.buffer;
}

constexpr double kGBInBytes = 1024.0 * 1024.0 * 1024.0;

enum class MetricType {
    kUploadSpeed,
    kDownloadSpeed,
    kDiskReadSpeed,
    kDiskWriteSpeed,
    kCpu,
    kGpuUsage,
    kVramUsed,
    kVramSharedUsed,
    kCpuTemp,

    kCount,
};

// D3DKMT is used to read the GPU temperature, which has no PDH counter. The
// types and gdi32 exports below are declared directly to avoid depending on the
// d3dkmthk.h header, which isn't available in all build environments.
using D3DKMT_HANDLE = UINT32;

typedef struct _D3DKMT_OPENADAPTERFROMLUID {
    LUID AdapterLuid;
    D3DKMT_HANDLE hAdapter;
} D3DKMT_OPENADAPTERFROMLUID;

typedef struct _D3DKMT_CLOSEADAPTER {
    D3DKMT_HANDLE hAdapter;
} D3DKMT_CLOSEADAPTER;

typedef struct _D3DKMT_QUERYADAPTERINFO {
    D3DKMT_HANDLE hAdapter;
    UINT Type;  // KMTQUERYADAPTERINFOTYPE
    VOID* pPrivateDriverData;
    UINT PrivateDriverDataSize;
} D3DKMT_QUERYADAPTERINFO;

typedef struct _D3DKMT_ADAPTER_PERFDATA {
    UINT PhysicalAdapterIndex;
    ULONGLONG MemoryFrequency;
    ULONGLONG MaxMemoryFrequency;
    ULONGLONG MaxMemoryFrequencyOC;
    ULONGLONG MemoryBandwidth;
    ULONGLONG PCIEBandwidth;
    ULONG FanRPM;
    ULONG Power;
    ULONG Temperature;
    UCHAR PowerStateOverride;
} D3DKMT_ADAPTER_PERFDATA;

// KMTQAITYPE_ADAPTERPERFDATA.
constexpr UINT kAdapterPerfDataQueryType = 62;

using D3DKMTOpenAdapterFromLuid_t =
    NTSTATUS(WINAPI*)(D3DKMT_OPENADAPTERFROMLUID*);
D3DKMTOpenAdapterFromLuid_t pD3DKMTOpenAdapterFromLuid;

using D3DKMTQueryAdapterInfo_t = NTSTATUS(WINAPI*)(D3DKMT_QUERYADAPTERINFO*);
D3DKMTQueryAdapterInfo_t pD3DKMTQueryAdapterInfo;

using D3DKMTCloseAdapter_t = NTSTATUS(WINAPI*)(const D3DKMT_CLOSEADAPTER*);
D3DKMTCloseAdapter_t pD3DKMTCloseAdapter;

// GPU adapter info from DXGI. This is static hardware capacity, independent of
// the PDH sampling session: it is queried lazily and cached, keyed by the
// configured adapter name so that changing the selection re-queries.
struct DxgiAdapterInfo {
    std::wstring description;
    std::wstring luid;
    LUID luidValue;
    SIZE_T dedicated_video_memory;
    SIZE_T shared_system_memory;
};

std::optional<std::wstring> g_dxgiAdapterInfoGpuName;
std::optional<DxgiAdapterInfo> g_dxgiAdapterInfo;

std::optional<DxgiAdapterInfo> GetDxgiAdapterInfo(PCWSTR gpu_name, bool quiet) {
    std::wstring gpu_name_key = gpu_name ? gpu_name : L"";
    if (g_dxgiAdapterInfoGpuName == gpu_name_key) {
        return g_dxgiAdapterInfo;
    }

    g_dxgiAdapterInfoGpuName = gpu_name_key;
    g_dxgiAdapterInfo.reset();

    winrt::com_ptr<IDXGIFactory> factory;
    if (FAILED(CreateDXGIFactory(IID_PPV_ARGS(factory.put())))) {
        return std::nullopt;
    }

    DXGI_ADAPTER_DESC best_desc{};
    bool found = false;

    for (UINT i = 0;; i++) {
        winrt::com_ptr<IDXGIAdapter> adapter;
        if (factory->EnumAdapters(i, adapter.put()) == DXGI_ERROR_NOT_FOUND) {
            break;
        }

        DXGI_ADAPTER_DESC desc{};
        if (FAILED(adapter->GetDesc(&desc))) {
            continue;
        }

        if (!quiet) {
            Wh_Log(L"DXGI adapter %u: %s (LUID: 0x%08X_0x%08X, VRAM: %zu)", i,
                   desc.Description, desc.AdapterLuid.HighPart,
                   desc.AdapterLuid.LowPart, desc.DedicatedVideoMemory);
        }

        // If a name is specified, check for a match.
        if (gpu_name && *gpu_name) {
            if (StrStrIW(desc.Description, gpu_name)) {
                best_desc = desc;
                found = true;
                break;
            }
        } else {
            // Auto-select the one with most dedicated VRAM.
            if (!found ||
                desc.DedicatedVideoMemory > best_desc.DedicatedVideoMemory) {
                best_desc = desc;
                found = true;
            }
        }
    }

    if (!found) {
        return std::nullopt;
    }

    WCHAR luid_str[32];
    swprintf_s(luid_str, L"0x%08X_0x%08X", best_desc.AdapterLuid.HighPart,
               best_desc.AdapterLuid.LowPart);

    g_dxgiAdapterInfo = DxgiAdapterInfo{
        best_desc.Description,        luid_str,
        best_desc.AdapterLuid,        best_desc.DedicatedVideoMemory,
        best_desc.SharedSystemMemory,
    };

    return g_dxgiAdapterInfo;
}

// Makes the next GetDxgiAdapterInfo call enumerate the adapters again. A driver
// update or a GPU reset assigns the adapter a new LUID.
void InvalidateDxgiAdapterInfo() {
    g_dxgiAdapterInfoGpuName.reset();
}

// Invalidates the cached adapter info if D3DKMT no longer recognizes its LUID.
// This is much cheaper than enumerating the adapters again.
void InvalidateDxgiAdapterInfoIfStale() {
    if (!g_dxgiAdapterInfo || !pD3DKMTOpenAdapterFromLuid ||
        !pD3DKMTCloseAdapter) {
        return;
    }

    D3DKMT_OPENADAPTERFROMLUID openAdapter{};
    openAdapter.AdapterLuid = g_dxgiAdapterInfo->luidValue;
    if (pD3DKMTOpenAdapterFromLuid(&openAdapter) != 0) {
        Wh_Log(L"GPU adapter LUID %s is stale",
               g_dxgiAdapterInfo->luid.c_str());
        InvalidateDxgiAdapterInfo();
        return;
    }

    D3DKMT_CLOSEADAPTER closeAdapter{};
    closeAdapter.hAdapter = openAdapter.hAdapter;
    pD3DKMTCloseAdapter(&closeAdapter);
}

std::optional<double> GetDedicatedVramTotalGb() {
    auto info =
        GetDxgiAdapterInfo(g_settings.dataCollection.gpuAdapterName, true);
    if (info && info->dedicated_video_memory > 0) {
        return (double)info->dedicated_video_memory / kGBInBytes;
    }
    return std::nullopt;
}

std::optional<double> GetSharedVramTotalGb() {
    auto info =
        GetDxgiAdapterInfo(g_settings.dataCollection.gpuAdapterName, true);
    if (info && info->shared_system_memory > 0) {
        return (double)info->shared_system_memory / kGBInBytes;
    }
    return std::nullopt;
}

// Queries the GPU temperature via D3DKMT. The selected DXGI adapter provides
// the LUID that identifies the adapter to D3DKMT. Returns nullopt if the driver
// doesn't report a temperature.
std::optional<double> GetGpuTemperatureCelsius() {
    if (!pD3DKMTOpenAdapterFromLuid || !pD3DKMTQueryAdapterInfo ||
        !pD3DKMTCloseAdapter) {
        return std::nullopt;
    }

    auto info =
        GetDxgiAdapterInfo(g_settings.dataCollection.gpuAdapterName, true);
    if (!info) {
        return std::nullopt;
    }

    D3DKMT_OPENADAPTERFROMLUID openAdapter{};
    openAdapter.AdapterLuid = info->luidValue;
    if (pD3DKMTOpenAdapterFromLuid(&openAdapter) != 0) {
        InvalidateDxgiAdapterInfo();
        return std::nullopt;
    }

    D3DKMT_ADAPTER_PERFDATA perfData{};
    D3DKMT_QUERYADAPTERINFO queryInfo{};
    queryInfo.hAdapter = openAdapter.hAdapter;
    queryInfo.Type = kAdapterPerfDataQueryType;
    queryInfo.pPrivateDriverData = &perfData;
    queryInfo.PrivateDriverDataSize = sizeof(perfData);

    NTSTATUS status = pD3DKMTQueryAdapterInfo(&queryInfo);

    D3DKMT_CLOSEADAPTER closeAdapter{};
    closeAdapter.hAdapter = openAdapter.hAdapter;
    pD3DKMTCloseAdapter(&closeAdapter);

    if (status != 0) {
        return std::nullopt;
    }

    // A zero reading means the driver doesn't expose a temperature; treat it as
    // unavailable rather than showing an implausible 0 degrees.
    if (perfData.Temperature == 0) {
        return std::nullopt;
    }

    // Temperature is reported in tenths of a degree Celsius.
    return perfData.Temperature / 10.0;
}

class QueryDataCollectionSession {
   public:
    QueryDataCollectionSession() {
        winrt::check_hresult(PdhOpenQuery(nullptr, 0, &query_));
    }

    QueryDataCollectionSession(const QueryDataCollectionSession&) = delete;
    QueryDataCollectionSession& operator=(const QueryDataCollectionSession&) =
        delete;
    QueryDataCollectionSession(QueryDataCollectionSession&&) = delete;
    QueryDataCollectionSession& operator=(QueryDataCollectionSession&&) =
        delete;

    ~QueryDataCollectionSession() { PdhCloseQuery(query_); }

    bool AddMetric(MetricType type);
    void UpdateAllMetrics();
    bool SampleData();
    std::optional<double> QueryData(MetricType type);
    std::optional<double> QueryDataAvg(MetricType type);

   private:
    struct QueryDataResult {
        double sum;
        size_t count;
    };
    std::optional<QueryDataResult> QueryDataWithCount(MetricType type);
    void UpdateMetric(MetricType type);

    std::vector<std::wstring> ExpandEnglishWildcard(PCWSTR wildcard_path,
                                                    bool quiet);
    static std::wstring_view ExtractInstanceName(std::wstring_view path);
    static std::wstring_view ExtractGpuLuid(std::wstring_view instance);
    static std::vector<std::wstring> FilterNetworkPathsByAdapterName(
        const std::vector<std::wstring>& paths,
        PCWSTR adapter_name,
        bool quiet);
    static std::vector<std::wstring> FilterGpuPathsByAdapterName(
        const std::vector<std::wstring>& paths,
        PCWSTR gpu_name,
        bool quiet);

    std::vector<std::wstring> ExpandAndFilterWildcardPaths(MetricType type,
                                                           PCWSTR counter_path,
                                                           PCWSTR adapter_name,
                                                           bool quiet) {
        auto paths = ExpandEnglishWildcard(counter_path, quiet);

        // Filter paths by adapter name if specified.
        if (!paths.empty()) {
            if (type == MetricType::kGpuUsage ||
                type == MetricType::kVramUsed ||
                type == MetricType::kVramSharedUsed) {
                // For GPU metrics, we always filter (to auto-select the best
                // adapter if name is empty).
                paths = FilterGpuPathsByAdapterName(paths, adapter_name, quiet);
            } else if (adapter_name && *adapter_name) {
                paths =
                    FilterNetworkPathsByAdapterName(paths, adapter_name, quiet);
            }
        }

        return paths;
    }

    struct CounterEntry {
        std::wstring path;
        PDH_HCOUNTER counter;
    };

    struct MetricData {
        std::vector<CounterEntry> counters;
        PCWSTR wildcard_path = nullptr;
        PCWSTR adapter_name = nullptr;
    };

    PDH_HQUERY query_;
    MetricData metrics_[static_cast<int>(MetricType::kCount)];
};

bool QueryDataCollectionSession::AddMetric(MetricType type) {
    PCWSTR counter_path;
    bool is_wildcard = false;
    PCWSTR adapter_name = nullptr;

    switch (type) {
        case MetricType::kDownloadSpeed:
            counter_path = L"\\Network Interface(*)\\Bytes Received/sec";
            is_wildcard = true;
            adapter_name = g_settings.dataCollection.networkAdapterName;
            break;
        case MetricType::kUploadSpeed:
            counter_path = L"\\Network Interface(*)\\Bytes Sent/sec";
            is_wildcard = true;
            adapter_name = g_settings.dataCollection.networkAdapterName;
            break;
        case MetricType::kDiskReadSpeed:
            counter_path = L"\\PhysicalDisk(_Total)\\Disk Read Bytes/sec";
            break;
        case MetricType::kDiskWriteSpeed:
            counter_path = L"\\PhysicalDisk(_Total)\\Disk Write Bytes/sec";
            break;
        case MetricType::kCpu:
            counter_path =
                L"\\Processor Information(_Total)\\% Processor Utility";
            break;
        case MetricType::kGpuUsage:
            counter_path = L"\\GPU Engine(*)\\Utilization Percentage";
            is_wildcard = true;
            adapter_name = g_settings.dataCollection.gpuAdapterName;
            break;
        case MetricType::kVramUsed:
            counter_path = L"\\GPU Adapter Memory(*)\\Dedicated Usage";
            is_wildcard = true;
            adapter_name = g_settings.dataCollection.gpuAdapterName;
            break;
        case MetricType::kVramSharedUsed:
            counter_path = L"\\GPU Adapter Memory(*)\\Shared Usage";
            is_wildcard = true;
            adapter_name = g_settings.dataCollection.gpuAdapterName;
            break;
        case MetricType::kCpuTemp:
            counter_path = L"\\Thermal Zone Information(*)\\Temperature";
            is_wildcard = true;
            break;
        default:
            return false;
    }

    auto& metric = metrics_[static_cast<int>(type)];
    if (!metric.counters.empty()) {
        return false;
    }

    metric.wildcard_path = is_wildcard ? counter_path : nullptr;
    metric.adapter_name = adapter_name;

    if (is_wildcard) {
        auto paths = ExpandAndFilterWildcardPaths(
            type, counter_path, adapter_name, /*quiet=*/false);

        for (const auto& path : paths) {
            PDH_HCOUNTER counter;
            PDH_STATUS hr = PdhAddCounter(query_, path.c_str(), 0, &counter);
            if (SUCCEEDED(hr)) {
                metric.counters.push_back({path, counter});
            } else {
                Wh_Log(L"PdhAddCounter error %08X", hr);
            }
        }
    } else {
        PDH_HCOUNTER counter;
        PDH_STATUS hr = PdhAddEnglishCounter(query_, counter_path, 0, &counter);
        if (SUCCEEDED(hr)) {
            metric.counters.push_back({counter_path, counter});
        } else {
            Wh_Log(L"PdhAddEnglishCounter error %08X", hr);
        }
    }

    return !metric.counters.empty();
}

void QueryDataCollectionSession::UpdateMetric(MetricType type) {
    auto& metric = metrics_[static_cast<int>(type)];

    if (!metric.wildcard_path) {
        return;
    }

    auto current_paths = ExpandAndFilterWildcardPaths(
        type, metric.wildcard_path, metric.adapter_name, /*quiet=*/true);

    // Build a set of current paths for quick lookup.
    std::unordered_set<std::wstring> current_path_set(current_paths.begin(),
                                                      current_paths.end());

    // Remove counters that are no longer valid.
    for (auto it = metric.counters.begin(); it != metric.counters.end();) {
        if (current_path_set.find(it->path) == current_path_set.end()) {
            Wh_Log(L"Removing outdated counter: %s", it->path.c_str());
            PdhRemoveCounter(it->counter);
            it = metric.counters.erase(it);
        } else {
            ++it;
        }
    }

    // Build a set of existing paths.
    std::unordered_set<std::wstring> existing_paths;
    for (const auto& entry : metric.counters) {
        existing_paths.insert(entry.path);
    }

    // Add new counters.
    for (const auto& path : current_paths) {
        if (existing_paths.find(path) == existing_paths.end()) {
            PDH_HCOUNTER counter;
            PDH_STATUS hr = PdhAddCounter(query_, path.c_str(), 0, &counter);
            if (SUCCEEDED(hr)) {
                Wh_Log(L"Adding new counter: %s", path.c_str());
                metric.counters.push_back({path, counter});
            } else {
                Wh_Log(L"PdhAddCounter error %08X for %s", hr, path.c_str());
            }
        }
    }
}

void QueryDataCollectionSession::UpdateAllMetrics() {
    for (int i = 0; i < static_cast<int>(MetricType::kCount); i++) {
        if (metrics_[i].wildcard_path) {
            UpdateMetric(static_cast<MetricType>(i));
        }
    }
}

bool QueryDataCollectionSession::SampleData() {
    PDH_STATUS hr = PdhCollectQueryData(query_);
    if (FAILED(hr)) {
        Wh_Log(L"PdhCollectQueryData error %08X", hr);
        return false;
    }

    return true;
}

std::optional<QueryDataCollectionSession::QueryDataResult>
QueryDataCollectionSession::QueryDataWithCount(MetricType type) {
    const auto& metric = metrics_[static_cast<int>(type)];

    if (metric.counters.empty()) {
        return std::nullopt;
    }

    double sum = 0.0;
    size_t count = 0;
    for (const auto& entry : metric.counters) {
        PDH_FMT_COUNTERVALUE val;
        PDH_STATUS hr = PdhGetFormattedCounterValue(
            entry.counter, PDH_FMT_DOUBLE, nullptr, &val);
        if (SUCCEEDED(hr)) {
            // Skip dead thermal zones that report implausible values (below 200
            // Kelvin / -73°C), which would skew the average.
            if (type == MetricType::kCpuTemp && val.doubleValue < 200) {
                continue;
            }

            sum += val.doubleValue;
            count++;
        } else {
            Wh_Log(L"PdhGetFormattedCounterValue error %08X", hr);
        }
    }

    if (count == 0) {
        return std::nullopt;
    }

    return QueryDataResult{sum, count};
}

std::optional<double> QueryDataCollectionSession::QueryData(MetricType type) {
    auto result = QueryDataWithCount(type);
    if (!result) {
        return std::nullopt;
    }
    return result->sum;
}

std::optional<double> QueryDataCollectionSession::QueryDataAvg(
    MetricType type) {
    auto result = QueryDataWithCount(type);
    if (!result) {
        return std::nullopt;
    }
    return result->sum / result->count;
}

// Implemented according to the note here:
// https://learn.microsoft.com/en-us/windows/win32/api/pdh/nf-pdh-pdhaddenglishcounterw
std::vector<std::wstring> QueryDataCollectionSession::ExpandEnglishWildcard(
    PCWSTR wildcard_path,
    bool quiet) {
    // Step 1: Add English counter with wildcards to get localized path.
    PDH_HCOUNTER temp_counter;
    PDH_STATUS hr =
        PdhAddEnglishCounter(query_, wildcard_path, 0, &temp_counter);
    if (FAILED(hr)) {
        Wh_Log(L"PdhAddEnglishCounter error %08X", hr);
        return {};
    }

    // Step 2: Get counter info to obtain localized full path.
    DWORD required = 0;
    hr = PdhGetCounterInfo(temp_counter, FALSE, &required, nullptr);
    if (FAILED(hr) && hr != static_cast<PDH_STATUS>(PDH_MORE_DATA)) {
        Wh_Log(L"PdhGetCounterInfo (size) error %08X", hr);
        PdhRemoveCounter(temp_counter);
        return {};
    }

    if (required == 0) {
        PdhRemoveCounter(temp_counter);
        return {};
    }

    std::vector<BYTE> counter_info_buffer(required);
    PDH_COUNTER_INFO* counter_info =
        reinterpret_cast<PDH_COUNTER_INFO*>(counter_info_buffer.data());

    hr = PdhGetCounterInfo(temp_counter, FALSE, &required, counter_info);
    PdhRemoveCounter(temp_counter);
    if (FAILED(hr)) {
        Wh_Log(L"PdhGetCounterInfo error %08X", hr);
        return {};
    }

    // Step 3: Expand wildcards using the localized path.
    required = 0;
    hr = PdhExpandWildCardPath(nullptr, counter_info->szFullPath, nullptr,
                               &required, 0);
    if (FAILED(hr) && hr != static_cast<PDH_STATUS>(PDH_MORE_DATA)) {
        Wh_Log(L"PdhExpandWildCardPath (localized, size) error %08X", hr);
        return {};
    }

    if (required == 0) {
        return {};
    }

    std::vector<WCHAR> path_buffer(required);
    hr = PdhExpandWildCardPath(nullptr, counter_info->szFullPath,
                               path_buffer.data(), &required, 0);
    if (FAILED(hr)) {
        Wh_Log(L"PdhExpandWildCardPath (localized) error %08X", hr);
        return {};
    }

    std::vector<std::wstring> out_paths;
    WCHAR* p = path_buffer.data();
    while (*p) {
        if (!quiet) {
            Wh_Log(L"Expanded localized path: %s", p);
        }
        out_paths.emplace_back(p);
        p += wcslen(p) + 1;
    }
    return out_paths;
}

// Extract the instance name from a PDH counter path.
// E.g., "\Network Interface(Intel...)\Bytes Received/sec" -> "Intel..."
std::wstring_view QueryDataCollectionSession::ExtractInstanceName(
    std::wstring_view path) {
    auto start = path.find(L'(');
    if (start == std::wstring_view::npos) {
        return {};
    }
    auto end = path.rfind(L')');
    if (end == std::wstring_view::npos || end <= start) {
        return {};
    }
    return path.substr(start + 1, end - start - 1);
}

// Extract the LUID from a GPU Engine instance name.
// E.g., "pid_1234_luid_0x00000000_0x0000ABCD_phys_0_eng_0_engtype_3D"
//       -> "0x00000000_0x0000ABCD"
std::wstring_view QueryDataCollectionSession::ExtractGpuLuid(
    std::wstring_view instance) {
    auto luid_pos = instance.find(L"luid_");
    if (luid_pos == std::wstring_view::npos) {
        return {};
    }
    auto luid_start = luid_pos + 5;  // Skip "luid_"
    auto phys_pos = instance.find(L"_phys_", luid_start);
    if (phys_pos == std::wstring_view::npos) {
        return {};
    }
    return instance.substr(luid_start, phys_pos - luid_start);
}

// Filter network paths by adapter name (case-insensitive substring match).
std::vector<std::wstring>
QueryDataCollectionSession::FilterNetworkPathsByAdapterName(
    const std::vector<std::wstring>& paths,
    PCWSTR adapter_name,
    bool quiet) {
    if (!quiet) {
        Wh_Log(L"Filtering network adapters by name: %s", adapter_name);
    }

    std::vector<std::wstring> filtered;
    for (const auto& path : paths) {
        std::wstring_view instance = ExtractInstanceName(path);
        if (instance.empty()) {
            continue;
        }

        if (StrStrIW(std::wstring(instance).c_str(), adapter_name)) {
            if (!quiet) {
                Wh_Log(L"Matched network adapter: %.*s",
                       static_cast<int>(instance.size()), instance.data());
            }
            filtered.push_back(path);
        }
    }

    if (filtered.empty()) {
        if (!quiet) {
            Wh_Log(L"No network adapters matched");
        }
        return {};
    }

    return filtered;
}

// Filter GPU paths by adapter name (uses DXGI to map name to LUID).
std::vector<std::wstring>
QueryDataCollectionSession::FilterGpuPathsByAdapterName(
    const std::vector<std::wstring>& paths,
    PCWSTR gpu_name,
    bool quiet) {
    if (!quiet) {
        Wh_Log(L"Filtering GPU adapters by name: %s", gpu_name);
    }

    auto info = GetDxgiAdapterInfo(gpu_name, quiet);
    if (!info) {
        if (!quiet) {
            Wh_Log(L"GPU not found by name");
        }
        return {};
    }

    if (!quiet) {
        Wh_Log(L"Selected GPU: %s -> LUID %s", info->description.c_str(),
               info->luid.c_str());
    }

    std::vector<std::wstring> filtered;
    for (const auto& path : paths) {
        std::wstring_view instance = ExtractInstanceName(path);
        if (instance.empty()) {
            continue;
        }

        auto luid = ExtractGpuLuid(instance);
        if (luid.empty()) {
            continue;
        }

        if (_wcsicmp(std::wstring(luid).c_str(), info->luid.c_str()) == 0) {
            filtered.push_back(path);
        }
    }

    if (filtered.empty()) {
        if (!quiet) {
            Wh_Log(L"No GPU paths matched LUID %s", info->luid.c_str());
        }

        // An idle GPU may have no instances either, so check the LUID before
        // enumerating the adapters again.
        InvalidateDxgiAdapterInfoIfStale();
        return {};
    }

    if (!quiet) {
        Wh_Log(L"Filtered to %zu GPU paths", filtered.size());
    }
    return filtered;
}

[[clang::no_destroy]] std::optional<QueryDataCollectionSession>
    g_dataCollectionSession;
DWORD g_dataCollectionLastFormatIndex;

// Whether a metric that changes over time is shown, in which case the clock
// refreshes every second so that the update interval takes effect.
bool g_dataCollectionPatternUsed;

// Media player helper functions

void UpdateMediaIgnoredPlayersNoLock() {
    g_mediaIgnoredPlayers.clear();

    for (const auto& ignored : g_settings.mediaPlayer.ignoredPlayers) {
        std::wstring ignoredLower(ignored.get());
        if (ignoredLower.empty()) {
            continue;
        }
        std::transform(ignoredLower.begin(), ignoredLower.end(),
                       ignoredLower.begin(), ::towlower);
        g_mediaIgnoredPlayers.push_back(std::move(ignoredLower));
    }
}

bool IsMediaPlayerIgnoredNoLock(const winrt::hstring& appId) {
    std::wstring appIdLower(appId);
    std::transform(appIdLower.begin(), appIdLower.end(), appIdLower.begin(),
                   ::towlower);

    for (const auto& ignored : g_mediaIgnoredPlayers) {
        if (appIdLower.find(ignored) != std::wstring::npos) {
            return true;
        }
    }
    return false;
}

void RemoveBracketedContent(std::wstring& str, wchar_t open, wchar_t close) {
    size_t start = 0;
    while ((start = str.find(open, start)) != std::wstring::npos) {
        // Find the matching close bracket, tracking depth so that nested
        // brackets of the same type, e.g. "(a (b))", are removed as a whole
        // instead of leaving a dangling close bracket behind.
        size_t end = std::wstring::npos;
        int depth = 0;
        for (size_t i = start; i < str.size(); i++) {
            if (str[i] == open) {
                depth++;
            } else if (str[i] == close && --depth == 0) {
                end = i;
                break;
            }
        }
        if (end == std::wstring::npos) {
            break;
        }

        // Check if brackets contain anything other than whitespace
        bool hasContent = false;
        for (size_t i = start + 1; i < end; i++) {
            wchar_t c = str[i];
            if (c != L' ' && c != L'\t' && c != L'\n' && c != L'\r') {
                hasContent = true;
                break;
            }
        }

        if (hasContent) {
            // Remove the brackets and content, plus one adjacent space
            size_t removeStart = start;
            size_t removeEnd = end;
            if (start > 0 && str[start - 1] == L' ') {
                // Prefer removing preceding space
                removeStart--;
            } else if (end + 1 < str.size() && str[end + 1] == L' ') {
                // Otherwise remove following space
                removeEnd++;
            }
            str.erase(removeStart, removeEnd - removeStart + 1);
            start = removeStart;
        } else {
            start = end + 1;
        }
    }
}

std::wstring RemoveBracketsFromString(std::wstring_view input) {
    if (!g_settings.mediaPlayer.removeBrackets) {
        return std::wstring(input);
    }

    std::wstring result(input);
    RemoveBracketedContent(result, L'(', L')');
    RemoveBracketedContent(result, L'[', L']');

    // Trim leading and trailing spaces
    size_t startPos = result.find_first_not_of(L' ');
    if (startPos == std::wstring::npos) {
        return std::wstring();
    }
    size_t endPos = result.find_last_not_of(L' ');
    return result.substr(startPos, endPos - startPos + 1);
}

// The media helpers below require g_mediaMutex to be held.

void ClearMediaFormattedStringsNoLock() {
    g_mediaActive = false;
    wcscpy_s(g_mediaTitleFormatted.buffer, L"");
    wcscpy_s(g_mediaArtistFormatted.buffer, L"");
    wcscpy_s(g_mediaAlbumFormatted.buffer, L"");
    wcscpy_s(g_mediaStatusFormatted.buffer, L"");
}

winrt::Windows::Media::Control::GlobalSystemMediaTransportControlsSession
FindActiveMediaSessionNoLock() {
    if (!g_mediaSessionManager) {
        return nullptr;
    }

    // First try the current session
    auto currentSession = g_mediaSessionManager.GetCurrentSession();
    if (currentSession) {
        try {
            auto appId = currentSession.SourceAppUserModelId();
            if (!IsMediaPlayerIgnoredNoLock(appId)) {
                return currentSession;
            }
        } catch (...) {
            HRESULT hr = winrt::to_hresult();
            Wh_Log(L"Failed to get app ID for current session: %08X", hr);
            return currentSession;
        }
    }

    // If current session is ignored or null, search for an alternative
    try {
        auto sessions = g_mediaSessionManager.GetSessions();
        for (uint32_t i = 0; i < sessions.Size(); i++) {
            auto session = sessions.GetAt(i);
            try {
                auto appId = session.SourceAppUserModelId();
                if (IsMediaPlayerIgnoredNoLock(appId)) {
                    continue;
                }

                auto playbackInfo = session.GetPlaybackInfo();
                auto status = playbackInfo.PlaybackStatus();

                // Prefer playing or paused sessions
                using Status = winrt::Windows::Media::Control::
                    GlobalSystemMediaTransportControlsSessionPlaybackStatus;
                if (status == Status::Playing || status == Status::Paused) {
                    return session;
                }
            } catch (...) {
                HRESULT hr = winrt::to_hresult();
                Wh_Log(L"Failed to query session %u: %08X", i, hr);
                continue;
            }
        }

        // If no active session found, return first non-ignored one
        for (uint32_t i = 0; i < sessions.Size(); i++) {
            auto session = sessions.GetAt(i);
            try {
                auto appId = session.SourceAppUserModelId();
                if (!IsMediaPlayerIgnoredNoLock(appId)) {
                    return session;
                }
            } catch (...) {
                HRESULT hr = winrt::to_hresult();
                Wh_Log(L"Failed to get app ID for session %u: %08X", i, hr);
                return session;
            }
        }
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"Failed to get media sessions: %08X", hr);
    }

    return nullptr;
}

void RefreshMediaDataNoLock() {
    // Clear the flag before reading, so that a change signaled while the query
    // below is in flight schedules another refresh instead of being swallowed.
    g_mediaDataDirty = false;

    try {
        if (!g_mediaSessionManager) {
            ClearMediaFormattedStringsNoLock();
            return;
        }

        auto session = FindActiveMediaSessionNoLock();
        if (!session) {
            ClearMediaFormattedStringsNoLock();
            return;
        }

        auto mediaProperties = session.TryGetMediaPropertiesAsync().get();
        auto playbackInfo = session.GetPlaybackInfo();

        if (!mediaProperties) {
            ClearMediaFormattedStringsNoLock();
            return;
        }

        g_mediaActive = true;

        // Get playback status as emoji
        auto status = playbackInfo.PlaybackStatus();
        using Status = winrt::Windows::Media::Control::
            GlobalSystemMediaTransportControlsSessionPlaybackStatus;

        switch (status) {
            case Status::Playing:
                wcscpy_s(g_mediaStatusFormatted.buffer, L"\u23EF");  // ⏯
                break;
            case Status::Paused:
                wcscpy_s(g_mediaStatusFormatted.buffer, L"\u23F8");  // ⏸
                break;
            case Status::Stopped:
                wcscpy_s(g_mediaStatusFormatted.buffer, L"\u23F9");  // ⏹
                break;
            default:
                wcscpy_s(g_mediaStatusFormatted.buffer, L"");
                break;
        }

        std::wstring title = RemoveBracketsFromString(mediaProperties.Title());
        std::wstring artist =
            RemoveBracketsFromString(mediaProperties.Artist());
        auto album = mediaProperties.AlbumTitle();

        StringCopyTruncatedWithEllipsis(g_mediaTitleFormatted.buffer,
                                        ARRAYSIZE(g_mediaTitleFormatted.buffer),
                                        title.c_str());
        StringCopyTruncatedWithEllipsis(
            g_mediaArtistFormatted.buffer,
            ARRAYSIZE(g_mediaArtistFormatted.buffer), artist.c_str());
        StringCopyTruncatedWithEllipsis(g_mediaAlbumFormatted.buffer,
                                        ARRAYSIZE(g_mediaAlbumFormatted.buffer),
                                        album.c_str());
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"RefreshMediaData error: %08X", hr);
        ClearMediaFormattedStringsNoLock();
    }
}

void DataCollectionSessionInit() {
    bool metrics[static_cast<int>(MetricType::kCount)]{};
    metrics[static_cast<int>(MetricType::kUploadSpeed)] =
        IsStrInDateTimePatternSettings(L"%upload_speed%");
    metrics[static_cast<int>(MetricType::kDownloadSpeed)] =
        IsStrInDateTimePatternSettings(L"%download_speed%");

    // If total_speed is used, we need both upload and download metrics.
    if (IsStrInDateTimePatternSettings(L"%total_speed%")) {
        metrics[static_cast<int>(MetricType::kUploadSpeed)] = true;
        metrics[static_cast<int>(MetricType::kDownloadSpeed)] = true;
    }

    metrics[static_cast<int>(MetricType::kDiskReadSpeed)] =
        IsStrInDateTimePatternSettings(L"%disk_read%");
    metrics[static_cast<int>(MetricType::kDiskWriteSpeed)] =
        IsStrInDateTimePatternSettings(L"%disk_write%");

    // If disk_total is used, we need both read and write metrics.
    if (IsStrInDateTimePatternSettings(L"%disk_total%")) {
        metrics[static_cast<int>(MetricType::kDiskReadSpeed)] = true;
        metrics[static_cast<int>(MetricType::kDiskWriteSpeed)] = true;
    }

    metrics[static_cast<int>(MetricType::kCpu)] =
        IsStrInDateTimePatternSettings(L"%cpu%");
    metrics[static_cast<int>(MetricType::kGpuUsage)] =
        IsStrInDateTimePatternSettings(L"%gpu%");
    // %vram% and %vram_used% both read the dedicated VRAM usage counter; the
    // percentage is derived from it and the total reported by DXGI. The totals
    // (%vram_total% / %vram_shared_total%) come straight from DXGI and need no
    // session, so they don't gate session creation here.
    metrics[static_cast<int>(MetricType::kVramUsed)] =
        IsStrInDateTimePatternSettings(L"%vram%") ||
        IsStrInDateTimePatternSettings(L"%vram_used%");
    metrics[static_cast<int>(MetricType::kVramSharedUsed)] =
        IsStrInDateTimePatternSettings(L"%vram_shared%") ||
        IsStrInDateTimePatternSettings(L"%vram_shared_used%");
    metrics[static_cast<int>(MetricType::kCpuTemp)] =
        IsStrInDateTimePatternSettings(L"%cpu_temp%") ||
        IsStrInDateTimePatternSettings(L"%cpu_temp_f%");

    bool sessionNeeded = std::any_of(std::begin(metrics), std::end(metrics),
                                     [](bool x) { return x; });

    // Metrics read without the session. Totals that never change are left out.
    g_dataCollectionPatternUsed =
        sessionNeeded || IsStrInDateTimePatternSettings(L"%ram%") ||
        IsStrInDateTimePatternSettings(L"%ram_used%") ||
        IsStrInDateTimePatternSettings(L"%ram_committed%") ||
        IsStrInDateTimePatternSettings(L"%ram_committed_used%") ||
        IsStrInDateTimePatternSettings(L"%ram_committed_total%") ||
        IsStrInDateTimePatternSettings(L"%gpu_temp%") ||
        IsStrInDateTimePatternSettings(L"%gpu_temp_f%") ||
        IsStrInDateTimePatternSettings(L"%battery%") ||
        IsStrInDateTimePatternSettings(L"%battery_time%") ||
        IsStrInDateTimePatternSettings(L"%power%");

    if (!sessionNeeded) {
        return;
    }

    try {
        g_dataCollectionSession.emplace();
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"Error %08X", hr);
        return;
    }

    for (size_t i = 0; i < ARRAYSIZE(metrics); i++) {
        if (metrics[i]) {
            MetricType metric = static_cast<MetricType>(i);
            g_dataCollectionSession->AddMetric(metric);
        }
    }

    g_dataCollectionSession->SampleData();
}

void DataCollectionSessionUninit() {
    g_dataCollectionSession.reset();
    g_dataCollectionLastFormatIndex = 0;
    g_dataCollectionPatternUsed = false;
}

bool IsMediaPatternUsed() {
    return IsStrInDateTimePatternSettings(L"%media_title%") ||
           IsStrInDateTimePatternSettings(L"%media_artist%") ||
           IsStrInDateTimePatternSettings(L"%media_album%") ||
           IsStrInDateTimePatternSettings(L"%media_status%") ||
           IsStrInDateTimePatternSettings(L"%media_info%");
}

void UnsubscribeFromMediaSessionNoLock() {
    if (g_mediaCurrentSession) {
        try {
            g_mediaCurrentSession.MediaPropertiesChanged(
                g_mediaPropertiesChangedToken);
            g_mediaCurrentSession.PlaybackInfoChanged(
                g_mediaPlaybackChangedToken);
        } catch (...) {
            HRESULT hr = winrt::to_hresult();
            Wh_Log(L"UnsubscribeFromMediaSession error: %08X", hr);
        }
        g_mediaCurrentSession = nullptr;
    }
}

void SubscribeToMediaSessionNoLock() {
    UnsubscribeFromMediaSessionNoLock();

    if (!g_mediaSessionManager) {
        return;
    }

    try {
        auto session = FindActiveMediaSessionNoLock();
        if (!session) {
            return;
        }

        g_mediaCurrentSession = session;

        g_mediaPropertiesChangedToken = session.MediaPropertiesChanged(
            [](auto&&, auto&&) { g_mediaDataDirty = true; });

        g_mediaPlaybackChangedToken = session.PlaybackInfoChanged(
            [](auto&&, auto&&) { g_mediaDataDirty = true; });
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"SubscribeToMediaSession error %08X", hr);
    }
}

void MediaSessionUninit() {
    winrt::Windows::Media::Control::
        GlobalSystemMediaTransportControlsSessionManager sessionManager{
            nullptr};
    winrt::event_token sessionsChangedToken;

    {
        std::lock_guard<std::mutex> guard(g_mediaMutex);

        UnsubscribeFromMediaSessionNoLock();

        sessionManager = std::move(g_mediaSessionManager);
        sessionsChangedToken = g_mediaSessionsChangedToken;
        g_mediaSessionsChangedToken = {};

        g_mediaIgnoredPlayers.clear();
        g_mediaDataDirty = true;
    }

    // Detach outside the lock: this waits for an in-flight
    // OnMediaSessionsChanged, which takes the lock itself.
    if (sessionManager) {
        try {
            sessionManager.SessionsChanged(sessionsChangedToken);
        } catch (...) {
            HRESULT hr = winrt::to_hresult();
            Wh_Log(L"MediaSessionUninit error: %08X", hr);
        }
    }
}

void OnMediaSessionsChanged() {
    g_mediaDataDirty = true;

    std::lock_guard<std::mutex> guard(g_mediaMutex);
    SubscribeToMediaSessionNoLock();
}

void MediaSessionInit() {
    g_mediaPatternUsed = IsMediaPatternUsed();
    if (!g_mediaPatternUsed) {
        return;
    }

    bool failed = false;

    {
        std::lock_guard<std::mutex> guard(g_mediaMutex);

        UpdateMediaIgnoredPlayersNoLock();

        try {
            g_mediaSessionManager =
                winrt::Windows::Media::Control::
                    GlobalSystemMediaTransportControlsSessionManager::
                        RequestAsync()
                            .get();

            // Subscribe to SessionsChanged event
            g_mediaSessionsChangedToken = g_mediaSessionManager.SessionsChanged(
                [](auto&&, auto&&) { OnMediaSessionsChanged(); });

            // Subscribe to current session events
            SubscribeToMediaSessionNoLock();

            RefreshMediaDataNoLock();
        } catch (...) {
            HRESULT hr = winrt::to_hresult();
            Wh_Log(L"MediaSessionInit error %08X", hr);
            failed = true;
        }
    }

    if (failed) {
        MediaSessionUninit();
    }
}

DWORD GetDataCollectionFormatIndex() {
    FILETIME formatTimeFt{};
    SystemTimeToFileTime(&g_formatTime, &formatTimeFt);
    ULARGE_INTEGER formatTimeInt{
        .LowPart = formatTimeFt.dwLowDateTime,
        .HighPart = formatTimeFt.dwHighDateTime,
    };

    constexpr ULONGLONG kSecondIn100Ns = 10000000ULL;
    ULONGLONG interval =
        kSecondIn100Ns * std::max(g_settings.dataCollection.updateInterval, 1);
    return static_cast<DWORD>(formatTimeInt.QuadPart / interval);
}

void DataCollectionSampleIfNeeded() {
    DWORD dataCollectionFormatIndex = GetDataCollectionFormatIndex();
    if (g_dataCollectionLastFormatIndex != dataCollectionFormatIndex) {
        if (g_dataCollectionSession) {
            g_dataCollectionSession->UpdateAllMetrics();
            g_dataCollectionSession->SampleData();
        }

        g_dataCollectionLastFormatIndex = dataCollectionFormatIndex;
    }
}

// System memory status, sampled at most once per update interval. Empty if the
// query failed.
std::optional<MEMORYSTATUSEX> GetRamStatus() {
    static MEMORYSTATUSEX status{};
    static bool valid = false;
    static DWORD lastFormatIndex = 0xFFFFFFFF;

    DWORD formatIndex = GetDataCollectionFormatIndex();
    if (lastFormatIndex != formatIndex) {
        status.dwLength = sizeof(status);
        valid = GlobalMemoryStatusEx(&status);
        lastFormatIndex = formatIndex;
    }

    return valid ? std::optional<MEMORYSTATUSEX>(status) : std::nullopt;
}

std::wstring FormatLocaleNum(double val, unsigned int digitsAfterDecimal) {
    int valStrLen = _scwprintf(L"%.17f", val);
    if (valStrLen < 0) {
        return std::wstring();
    }

    std::wstring valStr(valStrLen + 1, L'\0');
    if (swprintf_s(valStr.data(), valStr.size(), L"%.17f", val) < 0) {
        return std::wstring();
    }

    WCHAR decSep[4];
    if (!GetLocaleInfoEx(LOCALE_NAME_USER_DEFAULT, LOCALE_SDECIMAL, decSep,
                         ARRAYSIZE(decSep))) {
        // Fallback.
        decSep[0] = L'.';
        decSep[1] = L'\0';
    }

    NUMBERFMTW fmt{
        .NumDigits = digitsAfterDecimal,
        .LeadingZero = 1,
        .lpDecimalSep = const_cast<LPWSTR>(decSep),
        .lpThousandSep = const_cast<LPWSTR>(L""),
    };

    // Query required size.
    int needed = GetNumberFormatEx(LOCALE_NAME_USER_DEFAULT, 0, valStr.c_str(),
                                   &fmt, nullptr, 0);
    if (needed == 0) {
        return std::wstring();
    }

    // Format.
    std::wstring out(needed - 1, L'\0');
    if (GetNumberFormatEx(LOCALE_NAME_USER_DEFAULT, 0, valStr.c_str(), &fmt,
                          out.data(), needed) == 0) {
        return std::wstring();
    }

    return out;
}

void FormatTransferSpeed(double val,
                         NetworkMetricsFormat format,
                         int fixedDecimals,
                         PWSTR buffer,
                         size_t bufferSize) {
    constexpr int kKBInBytes = 1024;
    constexpr int kMBInBytes = 1024 * kKBInBytes;
    constexpr int kKbitInBytes = 1000 / 8;
    constexpr int kMbitInBytes = 1000 * kKbitInBytes;

    double valUnit;
    PCWSTR unit = L"";

    switch (format) {
        case NetworkMetricsFormat::mbs:
            valUnit = val / kMBInBytes;
            unit = L" MB/s";
            break;

        case NetworkMetricsFormat::mbsNumberOnly:
            valUnit = val / kMBInBytes;
            break;

        case NetworkMetricsFormat::mbsDynamic:
            if (val / kKBInBytes < 1000) {
                valUnit = val / kKBInBytes;
                unit = L" KB/s";
            } else {
                valUnit = val / kMBInBytes;
                unit = L" MB/s";
            }
            break;

        case NetworkMetricsFormat::mbits:
            valUnit = val / kMbitInBytes;
            unit = L" MBit/s";
            break;

        case NetworkMetricsFormat::mbitsNumberOnly:
            valUnit = val / kMbitInBytes;
            break;

        case NetworkMetricsFormat::mbitsDynamic:
            if (val / kKbitInBytes < 1000) {
                valUnit = val / kKbitInBytes;
                unit = L" KBit/s";
            } else {
                valUnit = val / kMbitInBytes;
                unit = L" MBit/s";
            }
            break;
    }

    int digitsAfterDecimal = 0;
    PCWSTR prefix = L"";

    if (fixedDecimals == -1) {
        // Keep identical width for <1000 values.
        if (valUnit < 10) {
            digitsAfterDecimal = 2;
        } else if (valUnit < 100) {
            digitsAfterDecimal = 1;
        } else if (valUnit < 1000) {
            // Punctuation Space.
            prefix = L"\u2008";
        }
    } else {
        digitsAfterDecimal = fixedDecimals;
    }

    std::wstring valUnitFormatted =
        FormatLocaleNum(valUnit, digitsAfterDecimal);

    swprintf_s(buffer, bufferSize, L"%s%s%s", prefix, valUnitFormatted.c_str(),
               unit);
}

void FormatNetworkTransferSpeed(double val, PWSTR buffer, size_t bufferSize) {
    FormatTransferSpeed(val, g_settings.dataCollection.networkMetricsFormat,
                        g_settings.dataCollection.networkMetricsFixedDecimals,
                        buffer, bufferSize);
}

void FormatDiskTransferSpeed(double val, PWSTR buffer, size_t bufferSize) {
    FormatTransferSpeed(val, g_settings.dataCollection.diskMetricsFormat,
                        g_settings.dataCollection.diskMetricsFixedDecimals,
                        buffer, bufferSize);
}

void FormatGbValue(double val, PWSTR buffer, size_t bufferSize) {
    wcscpy_s(buffer, bufferSize, FormatLocaleNum(val, 1).c_str());
}

void FormatPercentValue(int val, PWSTR buffer, size_t bufferSize, int maxVal) {
    if (val > maxVal) {
        val = maxVal;
    }

    PCWSTR padding = L"";
    PCWSTR suffix = L"";

    switch (g_settings.dataCollection.percentageFormat) {
        case PercentageFormat::spacePaddingAndSymbol:
            padding = L"  ";
            suffix = L"%";
            break;

        case PercentageFormat::spacePadding:
            padding = L"  ";
            break;

        case PercentageFormat::singleSpacePadding:
            padding = L" ";
            break;

        case PercentageFormat::zeroPadding:
            padding = L"0";
            break;

        case PercentageFormat::noPadding:
            break;
    }

    // Pad to keep identical width in all cases.
    PCWSTR prefix = val < 10 ? padding : L"";

    swprintf_s(buffer, bufferSize, L"%s%d%s", prefix, val, suffix);
}

template <size_t N, typename Formatter>
PCWSTR GetMetricFormatted(FormattedString<N>& formattedString,
                          Formatter formatter) {
    DWORD dataCollectionFormatIndex = GetDataCollectionFormatIndex();
    if (formattedString.formatIndex != dataCollectionFormatIndex) {
        if (!formatter(formattedString.buffer,
                       ARRAYSIZE(formattedString.buffer))) {
            wcscpy_s(formattedString.buffer, L"-");
        }

        formattedString.formatIndex = dataCollectionFormatIndex;
    }

    return formattedString.buffer;
}

PCWSTR GetUploadSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_uploadSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kUploadSpeed);
            if (!val) {
                return false;
            }
            FormatNetworkTransferSpeed(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetDownloadSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_downloadSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kDownloadSpeed);
            if (!val) {
                return false;
            }
            FormatNetworkTransferSpeed(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetTotalSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_totalSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> uploadSpeed =
                g_dataCollectionSession->QueryData(MetricType::kUploadSpeed);
            std::optional<double> downloadSpeed =
                g_dataCollectionSession->QueryData(MetricType::kDownloadSpeed);
            if (!uploadSpeed || !downloadSpeed) {
                return false;
            }
            double totalSpeed = *uploadSpeed + *downloadSpeed;
            FormatNetworkTransferSpeed(totalSpeed, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetDiskReadSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_diskReadSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kDiskReadSpeed);
            if (!val) {
                return false;
            }
            FormatDiskTransferSpeed(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetDiskWriteSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_diskWriteSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kDiskWriteSpeed);
            if (!val) {
                return false;
            }
            FormatDiskTransferSpeed(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetDiskTotalSpeedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_diskTotalSpeedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> readSpeed =
                g_dataCollectionSession->QueryData(MetricType::kDiskReadSpeed);
            std::optional<double> writeSpeed =
                g_dataCollectionSession->QueryData(MetricType::kDiskWriteSpeed);
            if (!readSpeed || !writeSpeed) {
                return false;
            }
            double totalSpeed = *readSpeed + *writeSpeed;
            FormatDiskTransferSpeed(totalSpeed, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetCpuFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(g_cpuFormatted, [](PWSTR buffer,
                                                 size_t bufferSize) {
        if (!g_dataCollectionSession) {
            return false;
        }
        std::optional<double> val =
            g_dataCollectionSession->QueryData(MetricType::kCpu);
        if (!val) {
            return false;
        }
        // Cap to 99 to keep identical width in all cases.
        int maxVal = 99;
        FormatPercentValue(static_cast<int>(*val), buffer, bufferSize, maxVal);
        return true;
    });
}

PCWSTR GetRamFormatted() {
    return GetMetricFormatted(g_ramFormatted, [](PWSTR buffer,
                                                 size_t bufferSize) {
        auto status = GetRamStatus();
        if (!status) {
            return false;
        }
        // Cap to 99 to keep identical width in all cases.
        int maxVal = 99;
        FormatPercentValue(status->dwMemoryLoad, buffer, bufferSize, maxVal);
        return true;
    });
}

PCWSTR GetRamUsedFormatted() {
    return GetMetricFormatted(g_ramUsedFormatted, [](PWSTR buffer,
                                                     size_t bufferSize) {
        auto status = GetRamStatus();
        if (!status) {
            return false;
        }
        double usedGb =
            (double)(status->ullTotalPhys - status->ullAvailPhys) / kGBInBytes;
        FormatGbValue(usedGb, buffer, bufferSize);
        return true;
    });
}

PCWSTR GetRamTotalFormatted() {
    return GetMetricFormatted(
        g_ramTotalFormatted, [](PWSTR buffer, size_t bufferSize) {
            auto status = GetRamStatus();
            if (!status) {
                return false;
            }
            double totalGb = (double)status->ullTotalPhys / kGBInBytes;
            FormatGbValue(totalGb, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetRamCommittedFormatted() {
    return GetMetricFormatted(
        g_ramCommittedFormatted, [](PWSTR buffer, size_t bufferSize) {
            auto status = GetRamStatus();
            if (!status || status->ullTotalPageFile == 0) {
                return false;
            }
            int committed = static_cast<int>(
                ((status->ullTotalPageFile - status->ullAvailPageFile) * 100) /
                status->ullTotalPageFile);
            // Cap to 99 to keep identical width in all cases.
            int maxVal = 99;
            FormatPercentValue(committed, buffer, bufferSize, maxVal);
            return true;
        });
}

PCWSTR GetRamCommittedUsedFormatted() {
    return GetMetricFormatted(
        g_ramCommittedUsedFormatted, [](PWSTR buffer, size_t bufferSize) {
            auto status = GetRamStatus();
            if (!status) {
                return false;
            }
            double usedGb =
                (double)(status->ullTotalPageFile - status->ullAvailPageFile) /
                kGBInBytes;
            FormatGbValue(usedGb, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetRamCommittedTotalFormatted() {
    return GetMetricFormatted(
        g_ramCommittedTotalFormatted, [](PWSTR buffer, size_t bufferSize) {
            auto status = GetRamStatus();
            if (!status) {
                return false;
            }
            double totalGb = (double)status->ullTotalPageFile / kGBInBytes;
            FormatGbValue(totalGb, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetGpuFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(g_gpuFormatted, [](PWSTR buffer,
                                                 size_t bufferSize) {
        if (!g_dataCollectionSession) {
            return false;
        }
        std::optional<double> val =
            g_dataCollectionSession->QueryData(MetricType::kGpuUsage);
        if (!val) {
            return false;
        }
        // Cap to 99 to keep identical width in all cases.
        int maxVal = 99;
        FormatPercentValue(static_cast<int>(*val), buffer, bufferSize, maxVal);
        return true;
    });
}

PCWSTR GetVramFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_vramFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> usedBytes =
                g_dataCollectionSession->QueryData(MetricType::kVramUsed);
            std::optional<double> totalGb = GetDedicatedVramTotalGb();
            if (!usedBytes || !totalGb || *totalGb <= 0) {
                return false;
            }
            double usedGb = *usedBytes / kGBInBytes;
            // Cap to 99 to keep identical width in all cases.
            int maxVal = 99;
            FormatPercentValue(static_cast<int>(usedGb / *totalGb * 100.0),
                               buffer, bufferSize, maxVal);
            return true;
        });
}

PCWSTR GetVramUsedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_vramUsedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kVramUsed);
            if (!val) {
                return false;
            }
            FormatGbValue(*val / kGBInBytes, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetVramTotalFormatted() {
    return GetMetricFormatted(
        g_vramTotalFormatted, [](PWSTR buffer, size_t bufferSize) {
            std::optional<double> val = GetDedicatedVramTotalGb();
            if (!val) {
                return false;
            }
            FormatGbValue(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetVramSharedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_vramSharedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> usedBytes =
                g_dataCollectionSession->QueryData(MetricType::kVramSharedUsed);
            std::optional<double> totalGb = GetSharedVramTotalGb();
            if (!usedBytes || !totalGb || *totalGb <= 0) {
                return false;
            }
            double usedGb = *usedBytes / kGBInBytes;
            // Cap to 99 to keep identical width in all cases.
            int maxVal = 99;
            FormatPercentValue(static_cast<int>(usedGb / *totalGb * 100.0),
                               buffer, bufferSize, maxVal);
            return true;
        });
}

PCWSTR GetVramSharedUsedFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_vramSharedUsedFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            std::optional<double> val =
                g_dataCollectionSession->QueryData(MetricType::kVramSharedUsed);
            if (!val) {
                return false;
            }
            FormatGbValue(*val / kGBInBytes, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetVramSharedTotalFormatted() {
    return GetMetricFormatted(
        g_vramSharedTotalFormatted, [](PWSTR buffer, size_t bufferSize) {
            std::optional<double> val = GetSharedVramTotalGb();
            if (!val) {
                return false;
            }
            FormatGbValue(*val, buffer, bufferSize);
            return true;
        });
}

PCWSTR GetCpuTempFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_cpuTempFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            auto kelvin =
                g_dataCollectionSession->QueryDataAvg(MetricType::kCpuTemp);
            if (!kelvin) {
                return false;
            }
            int celsius = static_cast<int>(*kelvin - 273.15);
            swprintf_s(buffer, bufferSize, L"%d\u00B0C", celsius);
            return true;
        });
}

PCWSTR GetCpuTempFFormatted() {
    DataCollectionSampleIfNeeded();
    return GetMetricFormatted(
        g_cpuTempFFormatted, [](PWSTR buffer, size_t bufferSize) {
            if (!g_dataCollectionSession) {
                return false;
            }
            auto kelvin =
                g_dataCollectionSession->QueryDataAvg(MetricType::kCpuTemp);
            if (!kelvin) {
                return false;
            }
            double celsius = *kelvin - 273.15;
            double fahrenheit = celsius * 9.0 / 5.0 + 32.0;
            swprintf_s(buffer, bufferSize, L"%d\u00B0F",
                       static_cast<int>(fahrenheit));
            return true;
        });
}

PCWSTR GetGpuTempFormatted() {
    return GetMetricFormatted(g_gpuTempFormatted,
                              [](PWSTR buffer, size_t bufferSize) {
                                  auto celsius = GetGpuTemperatureCelsius();
                                  if (!celsius) {
                                      return false;
                                  }
                                  swprintf_s(buffer, bufferSize, L"%d\u00B0C",
                                             static_cast<int>(*celsius));
                                  return true;
                              });
}

PCWSTR GetGpuTempFFormatted() {
    return GetMetricFormatted(
        g_gpuTempFFormatted, [](PWSTR buffer, size_t bufferSize) {
            auto celsius = GetGpuTemperatureCelsius();
            if (!celsius) {
                return false;
            }
            double fahrenheit = *celsius * 9.0 / 5.0 + 32.0;
            swprintf_s(buffer, bufferSize, L"%d\u00B0F",
                       static_cast<int>(fahrenheit));
            return true;
        });
}

PCWSTR GetBatteryFormatted() {
    return GetMetricFormatted(
        g_batteryFormatted, [](PWSTR buffer, size_t bufferSize) {
            SYSTEM_POWER_STATUS powerStatus;
            // A level of 255 means unknown.
            if (!GetSystemPowerStatus(&powerStatus) ||
                powerStatus.BatteryLifePercent == 255) {
                return false;
            }
            int maxVal = 100;
            FormatPercentValue(powerStatus.BatteryLifePercent, buffer,
                               bufferSize, maxVal);
            return true;
        });
}

PCWSTR GetBatteryTimeFormatted() {
    return GetMetricFormatted(g_batteryTimeFormatted, [](PWSTR buffer,
                                                         size_t bufferSize) {
        DWORD totalSeconds = 0;
        SYSTEM_POWER_STATUS ps;

        if (GetSystemPowerStatus(&ps)) {
            if (ps.BatteryLifeTime != (DWORD)-1) {
                totalSeconds = ps.BatteryLifeTime;
            } else if (ps.ACLineStatus == 1 && ps.BatteryLifePercent < 100) {
                SYSTEM_BATTERY_STATE bs{};
                NTSTATUS status = CallNtPowerInformation(
                    SystemBatteryState, nullptr, 0, &bs, sizeof(bs));
                if (status == 0 && bs.Rate > 0) {
                    DWORD remainingCapacity =
                        bs.MaxCapacity - bs.RemainingCapacity;
                    totalSeconds = (remainingCapacity * 3600) / bs.Rate;
                }
            }
        }

        DWORD hours = totalSeconds / 3600;
        DWORD minutes = (totalSeconds % 3600) / 60;
        swprintf_s(buffer, bufferSize, L"%u:%02u", hours, minutes);
        return true;
    });
}

PCWSTR GetPowerFormatted() {
    return GetMetricFormatted(g_powerFormatted, [](PWSTR buffer,
                                                   size_t bufferSize) {
        SYSTEM_BATTERY_STATE batteryState{};
        NTSTATUS status =
            CallNtPowerInformation(SystemBatteryState, nullptr, 0,
                                   &batteryState, sizeof(batteryState));
        if (status == 0 && batteryState.MaxCapacity > 0) {
            DWORD rate = batteryState.Rate;

            // When some batteries charge the Rate is:
            // 0x80000000 == -2147483648 (LONG) == 2147483648 (DWORD)
            // https://github.com/jay/battstatus/blob/418d1872f6c4e560f6b46880d9577947f17cc414/battstatus.cpp#L265
            if (rate == 0x80000000) {
                rate = 0;
            }

            long powerMilliWatts = static_cast<long>(rate);

            long powerWatts =
                (powerMilliWatts + (powerMilliWatts >= 0 ? 500 : -500)) / 1000;

            swprintf_s(buffer, bufferSize, L"%+ldW", powerWatts);
            return true;
        }

        return false;
    });
}

void RefreshMediaDataIfDirty() {
    if (!g_mediaDataDirty) {
        return;
    }

    std::lock_guard<std::mutex> guard(g_mediaMutex);
    RefreshMediaDataNoLock();
}

PCWSTR GetMediaTitleFormatted() {
    RefreshMediaDataIfDirty();
    return g_mediaTitleFormatted.buffer;
}

PCWSTR GetMediaArtistFormatted() {
    RefreshMediaDataIfDirty();
    return g_mediaArtistFormatted.buffer;
}

PCWSTR GetMediaAlbumFormatted() {
    RefreshMediaDataIfDirty();
    return g_mediaAlbumFormatted.buffer;
}

PCWSTR GetMediaStatusFormatted() {
    RefreshMediaDataIfDirty();
    return g_mediaStatusFormatted.buffer;
}

int FormatLineNoLock(PWSTR buffer, size_t bufferSize, std::wstring_view format);

PCWSTR GetMediaInfoFormatted() {
    RefreshMediaDataIfDirty();

    // A %media_info% tag nested within a media info format expands to nothing.
    if (g_inMediaInfoFormat) {
        return L"";
    }

    if (g_mediaInfoFormatted.formatIndex != g_formatIndex) {
        // The format strings may contain any tags, including media tags such as
        // %media_artist% and %media_title%.
        PCWSTR format = g_mediaActive
                            ? g_settings.mediaPlayer.mediaInfoFormat.get()
                            : g_settings.mediaPlayer.noMediaText.get();

        int maxLen = ARRAYSIZE(g_mediaInfoFormatted.buffer) - 1;
        if (g_settings.mediaPlayer.maxLength > 0 &&
            g_settings.mediaPlayer.maxLength < maxLen) {
            maxLen = g_settings.mediaPlayer.maxLength;
        }

        // Format directly into the buffer, capped at maxLen characters.
        // FormatLineNoLock truncates with a trailing ellipsis.
        g_inMediaInfoFormat = true;
        FormatLineNoLock(g_mediaInfoFormatted.buffer, maxLen + 1, format);
        g_inMediaInfoFormat = false;

        g_mediaInfoFormatted.formatIndex = g_formatIndex;
    }

    return g_mediaInfoFormatted.buffer;
}

// Matches a token of the form <prefix><n><suffix>, where <n> is a positive
// decimal number without leading zeros. Returns the token length and sets
// *number, or returns 0 if there's no match.
size_t ResolveFormatTokenWithNumber(std::wstring_view format,
                                    std::wstring_view formatTokenPrefix,
                                    std::wstring_view formatTokenSuffix,
                                    int* number) {
    if (!format.starts_with(formatTokenPrefix)) {
        return 0;
    }

    size_t pos = formatTokenPrefix.size();
    if (pos >= format.size() || format[pos] < L'1' || format[pos] > L'9') {
        return 0;
    }

    int value = 0;
    for (; pos < format.size() && format[pos] >= L'0' && format[pos] <= L'9';
         pos++) {
        // Prevent overflow, far beyond any practical list size.
        if (value >= 100000) {
            return 0;
        }

        value = value * 10 + (format[pos] - L'0');
    }

    if (!format.substr(pos).starts_with(formatTokenSuffix)) {
        return 0;
    }

    *number = value;
    return pos + formatTokenSuffix.size();
}

size_t ResolveFormatToken(
    std::wstring_view format,
    std::function<void(PCWSTR resolvedStr)> resolvedCallback) {
    using FormattedStringValueGetter = PCWSTR (*)();

    struct {
        std::wstring_view token;
        FormattedStringValueGetter valueGetter;
    } formatTokens[] = {
        {L"%time%"sv, GetTimeFormatted},
        {L"%date%"sv, GetDateFormatted},
        {L"%weekday%"sv, GetWeekdayFormatted},
        {L"%weekday_num%"sv, GetWeekdayNumFormatted},
        {L"%weeknum%"sv, GetWeeknumFormatted},
        {L"%weeknum_iso%"sv, GetWeeknumIsoFormatted},
        {L"%dayofyear%"sv, GetDayOfYearFormatted},
        {L"%timezone%"sv, GetTimezoneFormatted},
        {L"%upload_speed%"sv, GetUploadSpeedFormatted},
        {L"%download_speed%"sv, GetDownloadSpeedFormatted},
        {L"%total_speed%"sv, GetTotalSpeedFormatted},
        {L"%disk_read%"sv, GetDiskReadSpeedFormatted},
        {L"%disk_write%"sv, GetDiskWriteSpeedFormatted},
        {L"%disk_total%"sv, GetDiskTotalSpeedFormatted},
        {L"%cpu%"sv, GetCpuFormatted},
        {L"%ram%"sv, GetRamFormatted},
        {L"%ram_used%"sv, GetRamUsedFormatted},
        {L"%ram_total%"sv, GetRamTotalFormatted},
        {L"%ram_committed%"sv, GetRamCommittedFormatted},
        {L"%ram_committed_used%"sv, GetRamCommittedUsedFormatted},
        {L"%ram_committed_total%"sv, GetRamCommittedTotalFormatted},
        {L"%gpu%"sv, GetGpuFormatted},
        {L"%vram%"sv, GetVramFormatted},
        {L"%vram_used%"sv, GetVramUsedFormatted},
        {L"%vram_total%"sv, GetVramTotalFormatted},
        {L"%vram_shared%"sv, GetVramSharedFormatted},
        {L"%vram_shared_used%"sv, GetVramSharedUsedFormatted},
        {L"%vram_shared_total%"sv, GetVramSharedTotalFormatted},
        {L"%cpu_temp%"sv, GetCpuTempFormatted},
        {L"%cpu_temp_f%"sv, GetCpuTempFFormatted},
        {L"%gpu_temp%"sv, GetGpuTempFormatted},
        {L"%gpu_temp_f%"sv, GetGpuTempFFormatted},
        {L"%battery%"sv, GetBatteryFormatted},
        {L"%battery_time%"sv, GetBatteryTimeFormatted},
        {L"%power%"sv, GetPowerFormatted},
        {L"%media_title%"sv, GetMediaTitleFormatted},
        {L"%media_artist%"sv, GetMediaArtistFormatted},
        {L"%media_album%"sv, GetMediaAlbumFormatted},
        {L"%media_status%"sv, GetMediaStatusFormatted},
        {L"%media_info%"sv, GetMediaInfoFormatted},
        {L"%newline%"sv, []() { return L"\n"; }},
        {L"%n%"sv, []() { return L"\n"; }},
    };

    for (const auto& formatToken : formatTokens) {
        if (format.starts_with(formatToken.token)) {
            resolvedCallback(formatToken.valueGetter());
            return formatToken.token.size();
        }
    }

    using FormattedStringValueGetterTz = PCWSTR (*)(size_t index);

    struct {
        std::wstring_view prefix;
        FormattedStringValueGetterTz valueGetter;
    } formatTzTokens[] = {
        {L"%time_tz"sv, GetTimeFormattedTz},
        {L"%date_tz"sv, GetDateFormattedTz},
        {L"%weekday_tz"sv, GetWeekdayFormattedTz},
    };

    for (auto formatTzToken : formatTzTokens) {
        int number;
        size_t tokenLen = ResolveFormatTokenWithNumber(
            format, formatTzToken.prefix, L"%"sv, &number);
        if (!tokenLen) {
            continue;
        }

        PCWSTR value = formatTzToken.valueGetter(number - 1);
        if (!value) {
            value = L"-";
        }

        resolvedCallback(value);
        return tokenLen;
    }

    if (auto token = L"%web%"sv; format.starts_with(token)) {
        std::lock_guard<std::mutex> guard(g_webContentMutex);
        resolvedCallback(*g_webContent ? g_webContent : L"Loading...");
        return token.size();
    }

    if (auto token = L"%web_full%"sv; format.starts_with(token)) {
        std::lock_guard<std::mutex> guard(g_webContentMutex);
        resolvedCallback(*g_webContentFull ? g_webContentFull : L"Loading...");
        return token.size();
    }

    using FormattedStringVectorGetter = std::vector<std::wstring>* (*)();

    struct {
        std::wstring_view prefix;
        FormattedStringVectorGetter valueVectorGetter;
    } formatExtraTokens[] = {
        {L"%time"sv, GetTimeFormattedExtra},
        {L"%date"sv, GetDateFormattedExtra},
    };

    for (auto formatExtraToken : formatExtraTokens) {
        int number;
        size_t tokenLen = ResolveFormatTokenWithNumber(
            format, formatExtraToken.prefix, L"%"sv, &number);
        if (!tokenLen) {
            continue;
        }

        const auto& valueVector = *formatExtraToken.valueVectorGetter();

        PCWSTR value;
        if (number < 2 ||
            static_cast<size_t>(number - 2) >= valueVector.size()) {
            value = L"-";
        } else {
            value = valueVector[number - 2].c_str();
        }

        resolvedCallback(value);
        return tokenLen;
    }

    if (int number; size_t tokenLen = ResolveFormatTokenWithNumber(
                        format, L"%web"sv, L"%"sv, &number)) {
        size_t index = number - 1;

        std::lock_guard<std::mutex> guard(g_webContentMutex);

        PCWSTR value;
        if (index >= g_webContentStrings.size()) {
            value = L"-";
        } else if (!g_webContentStrings[index]) {
            value = L"Loading...";
        } else {
            value = g_webContentStrings[index]->c_str();
        }

        resolvedCallback(value);
        return tokenLen;
    }

    if (int number; size_t tokenLen = ResolveFormatTokenWithNumber(
                        format, L"%web"sv, L"_full%"sv, &number)) {
        size_t index = number - 1;

        std::lock_guard<std::mutex> guard(g_webContentMutex);

        PCWSTR value;
        if (index >= g_webContentStringsFull.size()) {
            value = L"-";
        } else if (!g_webContentStringsFull[index]) {
            value = L"Loading...";
        } else {
            value = g_webContentStringsFull[index]->c_str();
        }

        resolvedCallback(value);
        return tokenLen;
    }

    if (auto token = L"%weather%"sv; format.starts_with(token)) {
        std::lock_guard<std::mutex> guard(g_webContentMutex);
        resolvedCallback(g_webContentWeather ? g_webContentWeather->c_str()
                                             : L"Loading...");
        return token.size();
    }

    return 0;
}

void EnsureFormattingInitialized() {
    if (g_formattingInitialized) {
        return;
    }

    g_formattingInitialized = true;

    WebContentUpdateThreadInit();
    DataCollectionSessionInit();
    MediaSessionInit();
}

// Requires g_formatLineMutex to be held, both for the formatting state and for
// the format string itself, which is normally owned by g_settings.
int FormatLineNoLock(PWSTR buffer,
                     size_t bufferSize,
                     std::wstring_view format) {
    if (bufferSize == 0) {
        return 0;
    }

    EnsureFormattingInitialized();

    std::wstring_view formatSuffix = format;

    PWSTR bufferStart = buffer;
    PWSTR bufferEnd = bufferStart + bufferSize;
    while (!formatSuffix.empty() && bufferEnd - buffer > 1) {
        if (formatSuffix[0] == L'%') {
            bool truncated = false;
            size_t formatTokenLen = ResolveFormatToken(
                formatSuffix,
                [&buffer, bufferEnd, &truncated](PCWSTR resolvedStr) {
                    buffer += StringCopyTruncated(buffer, bufferEnd - buffer,
                                                  resolvedStr, &truncated);
                });
            if (formatTokenLen > 0) {
                if (truncated) {
                    break;
                }

                formatSuffix = formatSuffix.substr(formatTokenLen);
                continue;
            }
        }

        *buffer++ = formatSuffix[0];
        formatSuffix = formatSuffix.substr(1);
    }

    if (!formatSuffix.empty() && bufferSize >= 4) {
        buffer[-1] = L'.';
        buffer[-2] = L'.';
        buffer[-3] = L'.';
    }

    *buffer = L'\0';

    return buffer - bufferStart;
}

#pragma region Win11Hooks

// Scratch state for the refresh currently running on this thread. Several
// taskbars refresh independently on thread pool threads, so this cannot be
// shared between them.
thread_local bool g_inRefreshIcon;
thread_local bool g_refreshIconNeedToAdjustTimer;
thread_local bool g_inGetTimeToolTipString;

using ClockSystemTrayIconDataModel_RefreshIcon_t = void(WINAPI*)(
    LPVOID pThis,
    LPVOID  // SystemTrayTelemetry::ClockUpdate&
);
ClockSystemTrayIconDataModel_RefreshIcon_t
    ClockSystemTrayIconDataModel_RefreshIcon_Original;
ClockSystemTrayIconDataModel_RefreshIcon_t
    ClockSystemTrayIconDataModel2_RefreshIcon_Original;

using ClockSystemTrayIconDataModel_GetTimeToolTipString_t =
    LPVOID(WINAPI*)(LPVOID pThis, LPVOID, LPVOID, LPVOID, LPVOID);
ClockSystemTrayIconDataModel_GetTimeToolTipString_t
    ClockSystemTrayIconDataModel_GetTimeToolTipString_Original;
ClockSystemTrayIconDataModel_GetTimeToolTipString_t
    ClockSystemTrayIconDataModel2_GetTimeToolTipString_Original;

using ClockSystemTrayIconDataModel_GetTimeToolTipString2_t =
    LPVOID(WINAPI*)(LPVOID pThis, LPVOID, LPVOID, LPVOID, LPVOID);
ClockSystemTrayIconDataModel_GetTimeToolTipString2_t
    ClockSystemTrayIconDataModel_GetTimeToolTipString2_Original;
ClockSystemTrayIconDataModel_GetTimeToolTipString2_t
    ClockSystemTrayIconDataModel2_GetTimeToolTipString2_Original;

using DateTimeIconContent_OnApplyTemplate_t = HRESULT(WINAPI*)(LPVOID pThis);
DateTimeIconContent_OnApplyTemplate_t
    DateTimeIconContent_OnApplyTemplate_Original;

using BadgeIconContent_get_ViewModel_t = HRESULT(WINAPI*)(LPVOID pThis,
                                                          LPVOID pArgs);
BadgeIconContent_get_ViewModel_t BadgeIconContent_get_ViewModel_Original;

using ClockSystemTrayIconDataModel_GetTimeToolTipString_2_t =
    LPVOID(WINAPI*)(LPVOID pThis, LPVOID, LPVOID, LPVOID, LPVOID);
ClockSystemTrayIconDataModel_GetTimeToolTipString_2_t
    ClockSystemTrayIconDataModel_GetTimeToolTipString_2_Original;

using ICalendar_Second_t = int(WINAPI*)(LPVOID pThis);
ICalendar_Second_t ICalendar_Second_Original;

using ThreadPoolTimer_CreateTimer_t = LPVOID(WINAPI*)(LPVOID param1,
                                                      LPVOID param2,
                                                      LPVOID param3,
                                                      LPVOID param4);
ThreadPoolTimer_CreateTimer_t ThreadPoolTimer_CreateTimer_Original;

using ThreadPoolTimer_CreateTimer_lambda_t = LPVOID(WINAPI*)(DWORD_PTR** param1,
                                                             LPVOID param2,
                                                             LPVOID param3);
ThreadPoolTimer_CreateTimer_lambda_t
    ThreadPoolTimer_CreateTimer_lambda_Original;

void ClockSystemTrayIconDataModel_RefreshIcon_Hook_Impl(
    LPVOID pThis,
    LPVOID param1,
    ClockSystemTrayIconDataModel_RefreshIcon_t original) {
    // Formatting creates the data collection session and the web content thread
    // on demand, but it only runs while calling the original function below,
    // after g_refreshIconNeedToAdjustTimer is set. Create them beforehand so
    // the flag accounts for them, otherwise the first refresh keeps the default
    // one-minute timer instead of shortening it to one second.
    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);

        EnsureFormattingInitialized();

        bool webContentPending =
            g_webContentUpdateThread && !g_webContentLoaded;
        g_refreshIconNeedToAdjustTimer =
            g_settings.showSeconds || g_dataCollectionPatternUsed ||
            g_mediaPatternUsed || webContentPending;
    }

    g_inRefreshIcon = true;

    original(pThis, param1);

    g_inRefreshIcon = false;
    g_refreshIconNeedToAdjustTimer = false;
}

void WINAPI ClockSystemTrayIconDataModel_RefreshIcon_Hook(LPVOID pThis,
                                                          LPVOID param1) {
    Wh_Log(L">");

    ClockSystemTrayIconDataModel_RefreshIcon_Hook_Impl(
        pThis, param1, ClockSystemTrayIconDataModel_RefreshIcon_Original);
}

void WINAPI ClockSystemTrayIconDataModel2_RefreshIcon_Hook(LPVOID pThis,
                                                           LPVOID param1) {
    Wh_Log(L">");

    ClockSystemTrayIconDataModel_RefreshIcon_Hook_Impl(
        pThis, param1, ClockSystemTrayIconDataModel2_RefreshIcon_Original);
}

void UpdateToolTipString(LPVOID tooltipPtrPtr) {
    auto separator = L"\r\n\r\n"sv;

    WCHAR extraLine[4096];
    size_t extraLength;
    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);
        extraLength = FormatLineNoLock(extraLine, ARRAYSIZE(extraLine),
                                       g_settings.tooltipLine.get());
    }

    if (extraLength == 0) {
        return;
    }

    // Reference:
    // https://github.com/microsoft/cppwinrt/blob/0a6cb062e2151cf6c8f357aa8ef735e359f8a98c/strings/base_string.h
    struct hstring_header {
        uint32_t flags;
        uint32_t length;
        uint32_t padding1;
        uint32_t padding2;
        wchar_t const* ptr;
    };

    struct shared_hstring_header : hstring_header {
        int32_t /*atomic_ref_count*/ count;
        wchar_t buffer[1];
    };

    shared_hstring_header* tooltipHeader =
        *(shared_hstring_header**)tooltipPtrPtr;

    uint64_t bytesRequired = sizeof(shared_hstring_header);
    if (g_settings.tooltipLineMode == TooltipLineMode::replace) {
        bytesRequired += sizeof(wchar_t) * extraLength;
    } else {
        bytesRequired += sizeof(wchar_t) * (tooltipHeader->length +
                                            separator.length() + extraLength);
    }

    shared_hstring_header* tooltipHeaderNew =
        (shared_hstring_header*)HeapReAlloc(GetProcessHeap(), 0, tooltipHeader,
                                            bytesRequired);
    if (!tooltipHeaderNew) {
        return;
    }

    tooltipHeaderNew->ptr = tooltipHeaderNew->buffer;

    if (g_settings.tooltipLineMode == TooltipLineMode::replace) {
        memcpy(tooltipHeaderNew->buffer, extraLine,
               sizeof(wchar_t) * extraLength);
        tooltipHeaderNew->length = extraLength;
    } else {
        memcpy(tooltipHeaderNew->buffer + tooltipHeaderNew->length,
               separator.data(), sizeof(wchar_t) * separator.length());
        tooltipHeaderNew->length += separator.length();

        memcpy(tooltipHeaderNew->buffer + tooltipHeaderNew->length, extraLine,
               sizeof(wchar_t) * extraLength);
        tooltipHeaderNew->length += extraLength;
    }

    tooltipHeaderNew->buffer[tooltipHeaderNew->length] = L'\0';

    *(shared_hstring_header**)tooltipPtrPtr = tooltipHeaderNew;
}

LPVOID ClockSystemTrayIconDataModel_GetTimeToolTipString_Hook_Impl(
    LPVOID pThis,
    LPVOID param1,
    LPVOID param2,
    LPVOID param3,
    LPVOID param4,
    ClockSystemTrayIconDataModel_GetTimeToolTipString_t original) {
    g_inGetTimeToolTipString = true;

    LPVOID ret = original(pThis, param1, param2, param3, param4);

    UpdateToolTipString(ret);

    g_inGetTimeToolTipString = false;

    return ret;
}

LPVOID WINAPI
ClockSystemTrayIconDataModel_GetTimeToolTipString_Hook(LPVOID pThis,
                                                       LPVOID param1,
                                                       LPVOID param2,
                                                       LPVOID param3,
                                                       LPVOID param4) {
    Wh_Log(L">");

    return ClockSystemTrayIconDataModel_GetTimeToolTipString_Hook_Impl(
        pThis, param1, param2, param3, param4,
        ClockSystemTrayIconDataModel_GetTimeToolTipString_Original);
}

LPVOID WINAPI
ClockSystemTrayIconDataModel2_GetTimeToolTipString_Hook(LPVOID pThis,
                                                        LPVOID param1,
                                                        LPVOID param2,
                                                        LPVOID param3,
                                                        LPVOID param4) {
    Wh_Log(L">");

    return ClockSystemTrayIconDataModel_GetTimeToolTipString_Hook_Impl(
        pThis, param1, param2, param3, param4,
        ClockSystemTrayIconDataModel2_GetTimeToolTipString_Original);
}

LPVOID
ClockSystemTrayIconDataModel_GetTimeToolTipString2_Hook_Impl(
    LPVOID pThis,
    LPVOID param1,
    LPVOID param2,
    LPVOID param3,
    LPVOID param4,
    ClockSystemTrayIconDataModel_GetTimeToolTipString2_t original) {
    g_inGetTimeToolTipString = true;

    LPVOID ret = original(pThis, param1, param2, param3, param4);

    UpdateToolTipString(ret);

    g_inGetTimeToolTipString = false;

    return ret;
}

LPVOID WINAPI
ClockSystemTrayIconDataModel_GetTimeToolTipString2_Hook(LPVOID pThis,
                                                        LPVOID param1,
                                                        LPVOID param2,
                                                        LPVOID param3,
                                                        LPVOID param4) {
    Wh_Log(L">");

    return ClockSystemTrayIconDataModel_GetTimeToolTipString2_Hook_Impl(
        pThis, param1, param2, param3, param4,
        ClockSystemTrayIconDataModel_GetTimeToolTipString2_Original);
}

LPVOID WINAPI
ClockSystemTrayIconDataModel2_GetTimeToolTipString2_Hook(LPVOID pThis,
                                                         LPVOID param1,
                                                         LPVOID param2,
                                                         LPVOID param3,
                                                         LPVOID param4) {
    Wh_Log(L">");

    return ClockSystemTrayIconDataModel_GetTimeToolTipString2_Hook_Impl(
        pThis, param1, param2, param3, param4,
        ClockSystemTrayIconDataModel2_GetTimeToolTipString2_Original);
}

FrameworkElement FindChildByName(FrameworkElement element,
                                 winrt::hstring name) {
    int childrenCount = Media::VisualTreeHelper::GetChildrenCount(element);

    for (int i = 0; i < childrenCount; i++) {
        auto child = Media::VisualTreeHelper::GetChild(element, i)
                         .try_as<FrameworkElement>();
        if (!child) {
            Wh_Log(L"Failed to get child %d of %d", i + 1, childrenCount);
            continue;
        }

        if (child.Name() == name) {
            return child;
        }
    }

    return nullptr;
}

void ApplyStackPanelStyles(Controls::StackPanel stackPanel,
                           int maxWidth,
                           int textSpacing) {
    if (maxWidth) {
        stackPanel.MaxWidth(maxWidth);
    } else {
        stackPanel.as<DependencyObject>().ClearValue(
            FrameworkElement::MaxWidthProperty());
    }

    if (textSpacing) {
        stackPanel.Spacing(textSpacing);
    } else {
        stackPanel.as<DependencyObject>().ClearValue(
            Controls::StackPanel::SpacingProperty());
    }
}

void ApplyTextBlockStyles(
    Controls::TextBlock textBlock,
    const TextStyleSettings* textStyleSettings,
    bool noWrap,
    std::optional<int64_t>* visibilityPropertyChangedToken) {
    if (visibilityPropertyChangedToken->has_value()) {
        textBlock.UnregisterPropertyChangedCallback(
            UIElement::VisibilityProperty(),
            visibilityPropertyChangedToken->value());
    }

    if (textStyleSettings && textStyleSettings->hidden) {
        textBlock.Visibility(Visibility::Collapsed);
        *visibilityPropertyChangedToken =
            textBlock.RegisterPropertyChangedCallback(
                UIElement::VisibilityProperty(),
                [](DependencyObject sender, DependencyProperty property) {
                    auto textBlock = sender.try_as<Controls::TextBlock>();
                    if (!textBlock) {
                        return;
                    }

                    textBlock.Visibility(Visibility::Collapsed);
                });
        return;
    }

    visibilityPropertyChangedToken->reset();

    textBlock.Visibility(Visibility::Visible);

    if (noWrap) {
        textBlock.TextWrapping(TextWrapping::NoWrap);
        textBlock.TextTrimming(TextTrimming::CharacterEllipsis);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::TextWrappingProperty());
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::TextTrimmingProperty());
    }

    if (textStyleSettings && *textStyleSettings->textColor) {
        auto textColor =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<winrt::Windows::UI::Color>(),
                winrt::box_value(textStyleSettings->textColor.get()))
                .as<winrt::Windows::UI::Color>();
        textBlock.Foreground(Media::SolidColorBrush{textColor});
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::ForegroundProperty());
    }

    if (textStyleSettings && *textStyleSettings->textAlignment) {
        auto textAlignment =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<TextAlignment>(),
                winrt::box_value(textStyleSettings->textAlignment.get()))
                .as<TextAlignment>();
        textBlock.TextAlignment(textAlignment);
    } else {
        textBlock.TextAlignment(TextAlignment::End);
    }

    if (textStyleSettings && textStyleSettings->fontSize) {
        textBlock.FontSize(textStyleSettings->fontSize);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::FontSizeProperty());
    }

    if (textStyleSettings && *textStyleSettings->fontFamily) {
        auto fontFamily =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<Media::FontFamily>(),
                winrt::box_value(textStyleSettings->fontFamily.get()))
                .as<Media::FontFamily>();
        textBlock.FontFamily(fontFamily);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::FontFamilyProperty());
    }

    if (textStyleSettings && *textStyleSettings->fontWeight) {
        auto fontWeight =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<winrt::Windows::UI::Text::FontWeight>(),
                winrt::box_value(textStyleSettings->fontWeight.get()))
                .as<winrt::Windows::UI::Text::FontWeight>();
        textBlock.FontWeight(fontWeight);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::FontWeightProperty());
    }

    if (textStyleSettings && *textStyleSettings->fontStyle) {
        auto fontStyle =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<winrt::Windows::UI::Text::FontStyle>(),
                winrt::box_value(textStyleSettings->fontStyle.get()))
                .as<winrt::Windows::UI::Text::FontStyle>();
        textBlock.FontStyle(fontStyle);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::FontStyleProperty());
    }

    if (textStyleSettings && *textStyleSettings->fontStretch) {
        auto fontStretch =
            Markup::XamlBindingHelper::ConvertValue(
                winrt::xaml_typename<winrt::Windows::UI::Text::FontStretch>(),
                winrt::box_value(textStyleSettings->fontStretch.get()))
                .as<winrt::Windows::UI::Text::FontStretch>();
        textBlock.FontStretch(fontStretch);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::FontStretchProperty());
    }

    if (textStyleSettings && textStyleSettings->characterSpacing) {
        textBlock.CharacterSpacing(textStyleSettings->characterSpacing);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::CharacterSpacingProperty());
    }

    if (textStyleSettings && textStyleSettings->lineHeight) {
        textBlock.LineHeight(textStyleSettings->lineHeight);
        // Honor the line height exactly, even when it's smaller than the
        // natural line height. Without this, lines never shrink below the
        // font's default height.
        textBlock.LineStackingStrategy(LineStackingStrategy::BlockLineHeight);
    } else {
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::LineHeightProperty());
        textBlock.as<DependencyObject>().ClearValue(
            Controls::TextBlock::LineStackingStrategyProperty());
    }
}

void ApplyDateTimeIconContentStyles(
    FrameworkElement dateTimeIconContentElement) {
    std::lock_guard<std::mutex> guard(g_clockElementStyleMutex);

    ClockElementStyleData* clockElementStyleData = nullptr;

    for (auto it = g_clockElementStyleData.begin();
         it != g_clockElementStyleData.end();) {
        auto& data = *it;
        auto element = data.dateTimeIconContentElement.get();
        if (!element) {
            it = g_clockElementStyleData.erase(it);
            continue;
        }

        if (element == dateTimeIconContentElement) {
            clockElementStyleData = &data;
            break;
        }

        ++it;
    }

    bool clockElementStyleEnabled = g_clockElementStyleEnabled;
    DWORD clockElementStyleIndex = g_clockElementStyleIndex;

    if (!clockElementStyleData && !clockElementStyleEnabled) {
        return;
    }

    if (clockElementStyleData &&
        clockElementStyleData->styleIndex == clockElementStyleIndex) {
        return;
    }

    auto containerGridElement =
        FindChildByName(dateTimeIconContentElement, L"ContainerGrid")
            .as<Controls::Grid>();
    if (!containerGridElement) {
        return;
    }

    auto stackPanel =
        containerGridElement.Children().GetAt(0).as<Controls::StackPanel>();

    Controls::TextBlock dateInnerTextBlock = nullptr;
    Controls::TextBlock timeInnerTextBlock = nullptr;

    for (const auto& child : stackPanel.Children()) {
        auto childTextBlock = child.try_as<Controls::TextBlock>();
        if (!childTextBlock) {
            continue;
        }

        if (childTextBlock.Name() == L"DateInnerTextBlock") {
            dateInnerTextBlock = childTextBlock;
            continue;
        }

        if (childTextBlock.Name() == L"TimeInnerTextBlock") {
            timeInnerTextBlock = childTextBlock;
            continue;
        }
    }

    if (!dateInnerTextBlock || !timeInnerTextBlock) {
        return;
    }

    if (!clockElementStyleData) {
        g_clockElementStyleData.push_back(ClockElementStyleData{
            .dateTimeIconContentElement = dateTimeIconContentElement,
        });
        clockElementStyleData = &g_clockElementStyleData.back();
    }

    const ClockElementStyleSettings* styleSettings =
        clockElementStyleEnabled ? &g_clockElementStyleSettings : nullptr;

    int maxWidth = styleSettings ? styleSettings->maxWidth : 0;
    int textSpacing = styleSettings ? styleSettings->textSpacing : 0;
    bool noWrap = maxWidth;

    ApplyStackPanelStyles(stackPanel, maxWidth, textSpacing);
    ApplyTextBlockStyles(
        dateInnerTextBlock, styleSettings ? &styleSettings->dateStyle : nullptr,
        noWrap, &clockElementStyleData->dateVisibilityPropertyChangedToken);
    ApplyTextBlockStyles(
        timeInnerTextBlock, styleSettings ? &styleSettings->timeStyle : nullptr,
        noWrap, &clockElementStyleData->timeVisibilityPropertyChangedToken);

    clockElementStyleData->styleIndex = clockElementStyleIndex;
}

HRESULT WINAPI DateTimeIconContent_OnApplyTemplate_Hook(LPVOID pThis) {
    Wh_Log(L">");

    HRESULT ret = DateTimeIconContent_OnApplyTemplate_Original(pThis);

    FrameworkElement dateTimeIconContent = nullptr;
    ((IUnknown*)pThis)
        ->QueryInterface(winrt::guid_of<FrameworkElement>(),
                         winrt::put_abi(dateTimeIconContent));
    if (!dateTimeIconContent) {
        return ret;
    }

    try {
        ApplyDateTimeIconContentStyles(dateTimeIconContent);
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"Error %08X", hr);
    }

    return ret;
}

HRESULT WINAPI BadgeIconContent_get_ViewModel_Hook(LPVOID pThis, LPVOID pArgs) {
    // Wh_Log(L">");

    HRESULT ret = BadgeIconContent_get_ViewModel_Original(pThis, pArgs);

    try {
        winrt::Windows::Foundation::IInspectable obj = nullptr;
        winrt::check_hresult(
            ((IUnknown*)pThis)
                ->QueryInterface(
                    winrt::guid_of<winrt::Windows::Foundation::IInspectable>(),
                    winrt::put_abi(obj)));

        if (winrt::get_class_name(obj) == L"SystemTray.DateTimeIconContent") {
            auto dateTimeIconContentElement = obj.as<FrameworkElement>();
            if (dateTimeIconContentElement.IsLoaded()) {
                ApplyDateTimeIconContentStyles(dateTimeIconContentElement);
            }
        }
    } catch (...) {
        HRESULT hr = winrt::to_hresult();
        Wh_Log(L"Error %08X", hr);
    }

    return ret;
}

LPVOID WINAPI
ClockSystemTrayIconDataModel_GetTimeToolTipString_2_Hook(LPVOID pThis,
                                                         LPVOID param1,
                                                         LPVOID param2,
                                                         LPVOID param3,
                                                         LPVOID param4) {
    Wh_Log(L">");

    g_inGetTimeToolTipString = true;

    LPVOID ret = ClockSystemTrayIconDataModel_GetTimeToolTipString_2_Original(
        pThis, param1, param2, param3, param4);

    UpdateToolTipString(ret);

    g_inGetTimeToolTipString = false;

    return ret;
}

int WINAPI ICalendar_Second_Hook(LPVOID pThis) {
    Wh_Log(L">");

    if (g_inRefreshIcon && !g_inGetTimeToolTipString &&
        g_refreshIconNeedToAdjustTimer) {
        g_refreshIconNeedToAdjustTimer = false;

        // Make the next refresh happen in a second.
        return 59;
    }

    int ret = ICalendar_Second_Original(pThis);

    return ret;
}

// Similar to ThreadPoolTimer_CreateTimer_lambda_Hook. Only one of them is
// called in some Windows versions due to function inlining.
LPVOID WINAPI ThreadPoolTimer_CreateTimer_Hook(LPVOID param1,
                                               LPVOID param2,
                                               LPVOID param3,
                                               LPVOID param4) {
    // In newer Windows 11 versions, there are only 3 arguments, but that's OK
    // because argument 4 is just ignored (register d9).
    ULONGLONG** elapse =
        (ULONGLONG**)(g_winVersion >= WinVersion::Win11_22H2 ? &param3
                                                             : &param4);

    Wh_Log(L"> %zu", **elapse);

    ULONGLONG elapseNew;

    if (g_inRefreshIcon && !g_inGetTimeToolTipString && **elapse == 10000000) {
        // Make the next refresh happen next second. Without this hook, the
        // timer was always set one second forward, and so the clock was
        // accumulating a delay, finally caused one second to be skipped.
        SYSTEMTIME time;
        if (GetLocalTime_Original) {
            GetLocalTime_Original(&time);
        } else {
            GetLocalTime(&time);
        }
        elapseNew = 10000ULL * (1000 - time.wMilliseconds);
        *elapse = &elapseNew;
    }

    return ThreadPoolTimer_CreateTimer_Original(param1, param2, param3, param4);
}

// Similar to ThreadPoolTimer_CreateTimer_Hook. Only one of them is called in
// some Windows versions due to function inlining.
LPVOID WINAPI ThreadPoolTimer_CreateTimer_lambda_Hook(DWORD_PTR** param1,
                                                      LPVOID param2,
                                                      LPVOID param3) {
    DWORD_PTR* elapse = param1[1];

    Wh_Log(L"> %zu", *elapse);

    if (g_inRefreshIcon && !g_inGetTimeToolTipString && *elapse == 10000000) {
        // Make the next refresh happen next second. Without this hook, the
        // timer was always set one second forward, and so the clock was
        // accumulating a delay, finally caused one second to be skipped.
        SYSTEMTIME time;
        if (GetLocalTime_Original) {
            GetLocalTime_Original(&time);
        } else {
            GetLocalTime(&time);
        }
        *elapse = 10000ULL * (1000 - time.wMilliseconds);
    }

    return ThreadPoolTimer_CreateTimer_lambda_Original(param1, param2, param3);
}

VOID WINAPI GetLocalTime_Hook_Win11(LPSYSTEMTIME lpSystemTime) {
    Wh_Log(L">");

    if (g_inRefreshIcon && !g_inGetTimeToolTipString &&
        g_refreshIconNeedToAdjustTimer) {
        g_refreshIconNeedToAdjustTimer = false;

        // Make the next refresh happen in a second.
        memset(lpSystemTime, 0, sizeof(*lpSystemTime));
        lpSystemTime->wSecond = 59;
        return;
    }

    GetLocalTime_Original(lpSystemTime);
}

int WINAPI GetTimeFormatEx_Hook_Win11(LPCWSTR lpLocaleName,
                                      DWORD dwFlags,
                                      CONST SYSTEMTIME* lpTime,
                                      LPCWSTR lpFormat,
                                      LPWSTR lpTimeStr,
                                      int cchTime) {
    if (g_inRefreshIcon && !g_inGetTimeToolTipString) {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);

        if (wcscmp(g_settings.topLine, L"-") != 0) {
            if (!cchTime) {
                // Hopefully a large enough buffer size.
                return FORMATTED_BUFFER_SIZE;
            }

            return FormatLineNoLock(lpTimeStr, cchTime,
                                    g_settings.topLine.get()) +
                   1;
        }
    }

    int ret = GetTimeFormatEx_Original(lpLocaleName, dwFlags, lpTime, lpFormat,
                                       lpTimeStr, cchTime);

    return ret;
}

int WINAPI GetDateFormatEx_Hook_Win11(LPCWSTR lpLocaleName,
                                      DWORD dwFlags,
                                      CONST SYSTEMTIME* lpDate,
                                      LPCWSTR lpFormat,
                                      LPWSTR lpDateStr,
                                      int cchDate,
                                      LPCWSTR lpCalendar) {
    if (g_inRefreshIcon && !g_inGetTimeToolTipString) {
        // Below is a fix for the following situation. The code inside
        // winrt::SystemTray::implementation::ClockSystemTrayIconDataModel::RefreshIcon
        // looks similar to the following (pseudo code):
        //
        // ----------------------------------------
        // if (someFlag) {
        //     SYSTEMTIME t1;
        //     GetLocalTime(&t1);
        //     setTimeout(nextUpdate, calcNextUpdate(t1.wSecond));
        // }
        // SYSTEMTIME t2;
        // GetLocalTime(&t2);
        // GetDateFormatEx(..., &t2, ...);
        // ----------------------------------------
        //
        // We hook GetLocalTime and change wSecond to update the clock every
        // second, which works if someFlag is set. But in case someFlag isn't
        // set, we end up changing the result of the second GetLocalTime call.
        // To handle this, we check whether the time we get here is the time we
        // set in the hook, and if so, we call GetLocalTime explicitly to pass
        // the correct date to GetDateFormatEx.
        //
        // I'm not sure what someFlag means, but it becomes false when the
        // monitor turns off.

        SYSTEMTIME sentinelSystemTime;
        memset(&sentinelSystemTime, 0, sizeof(sentinelSystemTime));
        sentinelSystemTime.wSecond = 59;
        if (memcmp(lpDate, &sentinelSystemTime, sizeof(sentinelSystemTime)) ==
            0) {
            if (GetLocalTime_Original) {
                GetLocalTime_Original(const_cast<SYSTEMTIME*>(lpDate));
            } else {
                GetLocalTime(const_cast<SYSTEMTIME*>(lpDate));
            }
        }

        if (!(dwFlags & DATE_LONGDATE)) {
            std::lock_guard<std::mutex> guard(g_formatLineMutex);

            if (!cchDate || g_winVersion >= WinVersion::Win11_22H2) {
                // First call, save date for formatting.
                g_formatTime = *lpDate;
                g_formatIndex++;
            }

            if (wcscmp(g_settings.bottomLine, L"-") != 0) {
                if (!cchDate) {
                    // Hopefully a large enough buffer size.
                    return FORMATTED_BUFFER_SIZE;
                }

                return FormatLineNoLock(lpDateStr, cchDate,
                                        g_settings.bottomLine.get()) +
                       1;
            }
        }
    }

    int ret = GetDateFormatEx_Original(lpLocaleName, dwFlags, lpDate, lpFormat,
                                       lpDateStr, cchDate, lpCalendar);

    return ret;
}

LRESULT WINAPI SendMessageW_Hook(HWND hWnd,
                                 UINT Msg,
                                 WPARAM wParam,
                                 LPARAM lParam) {
    LRESULT ret = SendMessageW_Original(hWnd, Msg, wParam, lParam);

    if (Msg != WM_POWERBROADCAST || wParam != PBT_APMQUERYSUSPEND) {
        return ret;
    }

    switch (lParam) {
        case PBT_APMRESUMECRITICAL:
        case PBT_APMRESUMESUSPEND:
        case PBT_APMRESUMEAUTOMATIC:
            break;

        default:
            return ret;
    }

    WCHAR szClassName[64];
    if (GetClassName(hWnd, szClassName, ARRAYSIZE(szClassName)) == 0) {
        return ret;
    }

    if (_wcsicmp(szClassName, L"MSTaskSwWClass") != 0) {
        return ret;
    }

    Wh_Log(L"Resumed, refreshing web contents");

    std::lock_guard<std::mutex> guard(g_webContentMutex);

    HANDLE event = g_webContentUpdateRefreshEvent;
    if (event) {
        g_webContentLoaded = false;
        SetEvent(event);
    }

    return ret;
}

#pragma endregion Win11Hooks

#pragma region Win10Hooks

thread_local bool g_inUpdateTextString;
thread_local int g_getDateFormatExCounter;
thread_local bool g_inGetTooltipText;
thread_local WCHAR* g_getTooltipTextBuffer;
thread_local int g_getTooltipTextBufferSize;

using ClockButton_UpdateTextStringsIfNecessary_t =
    unsigned int(WINAPI*)(LPVOID pThis, bool*);
ClockButton_UpdateTextStringsIfNecessary_t
    ClockButton_UpdateTextStringsIfNecessary_Original;

using ClockButton_CalculateMinimumSize_t = LPSIZE(WINAPI*)(LPVOID pThis,
                                                           LPSIZE,
                                                           SIZE);
ClockButton_CalculateMinimumSize_t ClockButton_CalculateMinimumSize_Original;

using ClockButton_GetTextSpacingForOrientation_t =
    int(WINAPI*)(LPVOID pThis, bool, DWORD, DWORD, DWORD, DWORD);
ClockButton_GetTextSpacingForOrientation_t
    ClockButton_GetTextSpacingForOrientation_Original;

using ClockButton_v_GetTooltipText_t =
    HRESULT(WINAPI*)(LPVOID pThis, LPVOID, LPVOID, LPVOID, LPVOID);
ClockButton_v_GetTooltipText_t ClockButton_v_GetTooltipText_Original;

using ClockButton_v_OnDisplayStateChange_t = void(WINAPI*)(LPVOID pThis, bool);
ClockButton_v_OnDisplayStateChange_t
    ClockButton_v_OnDisplayStateChange_Original;

HRESULT WINAPI ClockButton_v_GetTooltipText_Hook(LPVOID pThis,
                                                 LPVOID param1,
                                                 LPVOID param2,
                                                 LPVOID param3,
                                                 LPVOID param4) {
    Wh_Log(L">");

    g_inGetTooltipText = true;

    HRESULT ret = ClockButton_v_GetTooltipText_Original(pThis, param1, param2,
                                                        param3, param4);

    if (g_getTooltipTextBuffer) {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);

        if (g_settings.tooltipLineMode == TooltipLineMode::replace) {
            FormatLineNoLock(g_getTooltipTextBuffer, g_getTooltipTextBufferSize,
                             g_settings.tooltipLine.get());
        } else {
            size_t stringLen = wcslen(g_getTooltipTextBuffer);
            WCHAR* p = g_getTooltipTextBuffer + stringLen;
            size_t size = g_getTooltipTextBufferSize - stringLen;
            if (size > 4) {
                wcscpy(p, L"\r\n\r\n");
                FormatLineNoLock(p + 4, size - 4, g_settings.tooltipLine.get());
            }
        }
    }

    g_getTooltipTextBuffer = nullptr;
    g_getTooltipTextBufferSize = 0;

    g_inGetTooltipText = false;

    return ret;
}

unsigned int WINAPI
ClockButton_UpdateTextStringsIfNecessary_Hook(LPVOID pThis, bool* param1) {
    Wh_Log(L">");

    g_inUpdateTextString = true;
    g_getDateFormatExCounter = 0;

    unsigned int ret =
        ClockButton_UpdateTextStringsIfNecessary_Original(pThis, param1);

    g_inUpdateTextString = false;

    bool updateEverySecond;
    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);
        bool webContentPending =
            g_webContentUpdateThread && !g_webContentLoaded;
        updateEverySecond = g_settings.showSeconds ||
                            g_dataCollectionPatternUsed || g_mediaPatternUsed ||
                            webContentPending;
    }

    if (updateEverySecond) {
        // Return the time-out value for the time of the next update.
        SYSTEMTIME time;
        GetLocalTime(&time);
        return 1000 - time.wMilliseconds;
    }

    return ret;
}

LPSIZE WINAPI ClockButton_CalculateMinimumSize_Hook(LPVOID pThis,
                                                    LPSIZE param1,
                                                    SIZE param2) {
    Wh_Log(L">");

    LPSIZE ret =
        ClockButton_CalculateMinimumSize_Original(pThis, param1, param2);

    HWND hWnd = *((HWND*)pThis + 1);
    UINT windowDpi = pGetDpiForWindow ? pGetDpiForWindow(hWnd) : 0;

    if (g_settings.width > 0) {
        ret->cx = g_settings.width;
        if (windowDpi) {
            ret->cx = MulDiv(ret->cx, windowDpi, 96);
        }
    }

    if (g_settings.height > 0) {
        ret->cy = g_settings.height;
        if (windowDpi) {
            ret->cy = MulDiv(ret->cy, windowDpi, 96);
        }
    }

    return ret;
}

int WINAPI ClockButton_GetTextSpacingForOrientation_Hook(LPVOID pThis,
                                                         bool horizontal,
                                                         DWORD dwSiteHeight,
                                                         DWORD dwLine1Height,
                                                         DWORD dwLine2Height,
                                                         DWORD dwLine3Height) {
    Wh_Log(L">");

    int textSpacing = g_settings.textSpacing;
    if (textSpacing == 0) {
        return ClockButton_GetTextSpacingForOrientation_Original(
            pThis, horizontal, dwSiteHeight, dwLine1Height, dwLine2Height,
            dwLine3Height);
    }

    // 1 line.
    if (dwLine3Height == 0 && dwLine2Height == 0) {
        return 0;
    }

    // Since 0 is reserved, shift negative values so that any spacing value can
    // be used.
    if (textSpacing < 0) {
        textSpacing++;
    }

    HWND hWnd = *((HWND*)pThis + 1);
    UINT windowDpi = pGetDpiForWindow ? pGetDpiForWindow(hWnd) : 0;

    if (windowDpi) {
        return MulDiv(textSpacing, windowDpi, 96);
    }

    return textSpacing;
}

int WINAPI GetTimeFormatEx_Hook_Win10(LPCWSTR lpLocaleName,
                                      DWORD dwFlags,
                                      CONST SYSTEMTIME* lpTime,
                                      LPCWSTR lpFormat,
                                      LPWSTR lpTimeStr,
                                      int cchTime) {
    if (g_inUpdateTextString) {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);

        g_formatTime = *lpTime;
        g_formatIndex++;

        if (wcscmp(g_settings.topLine, L"-") != 0) {
            return FormatLineNoLock(lpTimeStr, cchTime,
                                    g_settings.topLine.get()) +
                   1;
        }
    }

    int ret = GetTimeFormatEx_Original(lpLocaleName, dwFlags, lpTime, lpFormat,
                                       lpTimeStr, cchTime);

    return ret;
}

int WINAPI GetDateFormatEx_Hook_Win10(LPCWSTR lpLocaleName,
                                      DWORD dwFlags,
                                      CONST SYSTEMTIME* lpDate,
                                      LPCWSTR lpFormat,
                                      LPWSTR lpDateStr,
                                      int cchDate,
                                      LPCWSTR lpCalendar) {
    if (g_inUpdateTextString) {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);

        g_getDateFormatExCounter++;
        PCWSTR format = g_getDateFormatExCounter > 1 ? g_settings.middleLine
                                                     : g_settings.bottomLine;
        if (wcscmp(format, L"-") != 0) {
            return FormatLineNoLock(lpDateStr, cchDate, format) + 1;
        }
    }

    int ret = GetDateFormatEx_Original(lpLocaleName, dwFlags, lpDate, lpFormat,
                                       lpDateStr, cchDate, lpCalendar);

    return ret;
}

int WINAPI GetDateFormatW_Hook_Win10(LCID Locale,
                                     DWORD dwFlags,
                                     CONST SYSTEMTIME* lpDate,
                                     LPCWSTR lpFormat,
                                     LPWSTR lpDateStr,
                                     int cchDate) {
    if (g_inGetTooltipText && !g_getTooltipTextBuffer) {
        g_getTooltipTextBuffer = lpDateStr;
        g_getTooltipTextBufferSize = cchDate;
    }

    int ret = GetDateFormatW_Original(Locale, dwFlags, lpDate, lpFormat,
                                      lpDateStr, cchDate);

    return ret;
}

#pragma endregion Win10Hooks

VS_FIXEDFILEINFO* GetModuleVersionInfo(HMODULE hModule, UINT* puPtrLen) {
    void* pFixedFileInfo = nullptr;
    UINT uPtrLen = 0;

    HRSRC hResource =
        FindResource(hModule, MAKEINTRESOURCE(VS_VERSION_INFO), RT_VERSION);
    if (hResource) {
        HGLOBAL hGlobal = LoadResource(hModule, hResource);
        if (hGlobal) {
            void* pData = LockResource(hGlobal);
            if (pData) {
                if (!VerQueryValue(pData, L"\\", &pFixedFileInfo, &uPtrLen) ||
                    uPtrLen == 0) {
                    pFixedFileInfo = nullptr;
                    uPtrLen = 0;
                }
            }
        }
    }

    if (puPtrLen) {
        *puPtrLen = uPtrLen;
    }

    return (VS_FIXEDFILEINFO*)pFixedFileInfo;
}

WinVersion GetExplorerVersion() {
    VS_FIXEDFILEINFO* fixedFileInfo = GetModuleVersionInfo(nullptr, nullptr);
    if (!fixedFileInfo) {
        return WinVersion::Unsupported;
    }

    WORD major = HIWORD(fixedFileInfo->dwFileVersionMS);
    WORD minor = LOWORD(fixedFileInfo->dwFileVersionMS);
    WORD build = HIWORD(fixedFileInfo->dwFileVersionLS);
    WORD qfe = LOWORD(fixedFileInfo->dwFileVersionLS);

    Wh_Log(L"Version: %u.%u.%u.%u", major, minor, build, qfe);

    switch (major) {
        case 10:
            if (build < 22000) {
                return WinVersion::Win10;
            } else if (build <= 22000) {
                return WinVersion::Win11;
            } else if (build < 26100) {
                return WinVersion::Win11_22H2;
            } else {
                return WinVersion::Win11_24H2;
            }
            break;
    }

    return WinVersion::Unsupported;
}

struct EXPLORER_PATCHER_HOOK {
    PCSTR symbol;
    void** pOriginalFunction;
    void* hookFunction = nullptr;
    bool optional = false;

    template <typename Prototype>
    EXPLORER_PATCHER_HOOK(
        PCSTR symbol,
        Prototype** originalFunction,
        std::type_identity_t<Prototype*> hookFunction = nullptr,
        bool optional = false)
        : symbol(symbol),
          pOriginalFunction(reinterpret_cast<void**>(originalFunction)),
          hookFunction(reinterpret_cast<void*>(hookFunction)),
          optional(optional) {}
};

bool HookExplorerPatcherSymbols(HMODULE explorerPatcherModule) {
    if (g_explorerPatcherInitialized.exchange(true)) {
        return true;
    }

    if (g_winVersion >= WinVersion::Win11) {
        g_winVersion = WinVersion::Win10;
    }

    EXPLORER_PATCHER_HOOK hooks[] = {
        {R"(?UpdateTextStringsIfNecessary@ClockButton@@AEAAIPEA_N@Z)",
         &ClockButton_UpdateTextStringsIfNecessary_Original,
         ClockButton_UpdateTextStringsIfNecessary_Hook},
        {R"(?CalculateMinimumSize@ClockButton@@QEAA?AUtagSIZE@@U2@@Z)",
         &ClockButton_CalculateMinimumSize_Original,
         ClockButton_CalculateMinimumSize_Hook},
        {R"(?GetTextSpacingForOrientation@ClockButton@@AEAAH_NHHHH@Z)",
         &ClockButton_GetTextSpacingForOrientation_Original,
         ClockButton_GetTextSpacingForOrientation_Hook},
        {R"(?v_GetTooltipText@ClockButton@@MEAAJPEAPEAUHINSTANCE__@@PEAPEAGPEAG_K@Z)",
         &ClockButton_v_GetTooltipText_Original,
         ClockButton_v_GetTooltipText_Hook, true},
        {R"(?v_OnDisplayStateChange@ClockButton@@MEAAX_N@Z)",
         &ClockButton_v_OnDisplayStateChange_Original},
    };

    bool succeeded = true;

    for (const auto& hook : hooks) {
        void* ptr = (void*)GetProcAddress(explorerPatcherModule, hook.symbol);
        if (!ptr) {
            Wh_Log(L"ExplorerPatcher symbol%s doesn't exist: %S",
                   hook.optional ? L" (optional)" : L"", hook.symbol);
            if (!hook.optional) {
                succeeded = false;
            }
            continue;
        }

        if (hook.hookFunction) {
            Wh_SetFunctionHook(ptr, hook.hookFunction, hook.pOriginalFunction);
        } else {
            *hook.pOriginalFunction = ptr;
        }
    }

    if (!succeeded) {
        Wh_Log(L"HookExplorerPatcherSymbols failed");
    } else if (g_initialized) {
        Wh_ApplyHookOperations();
    }

    return succeeded;
}

bool IsExplorerPatcherModule(HMODULE module) {
    WCHAR moduleFilePath[MAX_PATH];
    switch (
        GetModuleFileName(module, moduleFilePath, ARRAYSIZE(moduleFilePath))) {
        case 0:
        case ARRAYSIZE(moduleFilePath):
            return false;
    }

    PCWSTR moduleFileName = wcsrchr(moduleFilePath, L'\\');
    if (!moduleFileName) {
        return false;
    }

    moduleFileName++;

    if (_wcsnicmp(L"ep_taskbar.", moduleFileName, sizeof("ep_taskbar.") - 1) ==
        0) {
        Wh_Log(L"ExplorerPatcher taskbar module: %s", moduleFileName);
        return true;
    }

    return false;
}

bool HandleLoadedExplorerPatcher() {
    HMODULE hMods[1024];
    DWORD cbNeeded;
    if (EnumProcessModules(GetCurrentProcess(), hMods, sizeof(hMods),
                           &cbNeeded)) {
        for (size_t i = 0; i < cbNeeded / sizeof(HMODULE); i++) {
            if (IsExplorerPatcherModule(hMods[i])) {
                return HookExplorerPatcherSymbols(hMods[i]);
            }
        }
    }

    return true;
}

void HandleLoadedModuleIfExplorerPatcher(HMODULE module) {
    if (module && !((ULONG_PTR)module & 3) && !g_explorerPatcherInitialized) {
        if (IsExplorerPatcherModule(module)) {
            HookExplorerPatcherSymbols(module);
        }
    }
}

bool HookWin10TaskbarSymbols() {
    WindhawkUtils::SYMBOL_HOOK explorerExeHooks[] = {
        {
            {LR"(private: unsigned int __cdecl ClockButton::UpdateTextStringsIfNecessary(bool *))"},
            &ClockButton_UpdateTextStringsIfNecessary_Original,
            ClockButton_UpdateTextStringsIfNecessary_Hook,
        },
        {
            {LR"(public: struct tagSIZE __cdecl ClockButton::CalculateMinimumSize(struct tagSIZE))"},
            &ClockButton_CalculateMinimumSize_Original,
            ClockButton_CalculateMinimumSize_Hook,
        },
        {
            {LR"(private: int __cdecl ClockButton::GetTextSpacingForOrientation(bool,int,int,int,int))"},
            &ClockButton_GetTextSpacingForOrientation_Original,
            ClockButton_GetTextSpacingForOrientation_Hook,
        },
        {
            {LR"(protected: virtual long __cdecl ClockButton::v_GetTooltipText(struct HINSTANCE__ * *,unsigned short * *,unsigned short *,unsigned __int64))"},
            &ClockButton_v_GetTooltipText_Original,
            ClockButton_v_GetTooltipText_Hook,
            true,
        },
        {
            {LR"(protected: virtual void __cdecl ClockButton::v_OnDisplayStateChange(bool))"},
            &ClockButton_v_OnDisplayStateChange_Original,
        },
    };

    if (!HookSymbols(GetModuleHandle(nullptr), explorerExeHooks,
                     ARRAYSIZE(explorerExeHooks))) {
        Wh_Log(L"HookSymbols failed");
        return false;
    }

    return true;
}

bool HookSystemTraySymbols(HMODULE module) {
    // SystemTray.dll, Taskbar.View.dll, ExplorerExtensions.dll
    WindhawkUtils::SYMBOL_HOOK symbolHooks[] =  //
        {
            {
                {LR"(private: void __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel::RefreshIcon(class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel_RefreshIcon_Original,
                ClockSystemTrayIconDataModel_RefreshIcon_Hook,
            },
            {
                {LR"(private: void __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel2::RefreshIcon(class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel2_RefreshIcon_Original,
                ClockSystemTrayIconDataModel2_RefreshIcon_Hook,
                true,  // Added with feature flag 38762814
            },
            {
                {LR"(private: struct winrt::hstring __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel::GetTimeToolTipString(struct _SYSTEMTIME const &,struct _SYSTEMTIME const &,class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel_GetTimeToolTipString_Original,
                ClockSystemTrayIconDataModel_GetTimeToolTipString_Hook,
                true,
            },
            {
                {LR"(private: struct winrt::hstring __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel2::GetTimeToolTipString(struct _SYSTEMTIME const &,struct _SYSTEMTIME const &,class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel2_GetTimeToolTipString_Original,
                ClockSystemTrayIconDataModel2_GetTimeToolTipString_Hook,
                true,  // Added with feature flag 38762814
            },
            {
                {LR"(private: struct winrt::hstring __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel::GetTimeToolTipString2(struct _SYSTEMTIME const &,struct _SYSTEMTIME const &,class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel_GetTimeToolTipString2_Original,
                ClockSystemTrayIconDataModel_GetTimeToolTipString2_Hook,
                true,
            },
            {
                {LR"(private: struct winrt::hstring __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel2::GetTimeToolTipString2(struct _SYSTEMTIME const &,struct _SYSTEMTIME const &,class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel2_GetTimeToolTipString2_Original,
                ClockSystemTrayIconDataModel2_GetTimeToolTipString2_Hook,
                true,  // Added with feature flag 38762814
            },
            {
                {LR"(public: virtual int __cdecl winrt::impl::produce<struct winrt::SystemTray::implementation::DateTimeIconContent,struct winrt::Windows::UI::Xaml::IFrameworkElementOverrides>::OnApplyTemplate(void))"},
                &DateTimeIconContent_OnApplyTemplate_Original,
                DateTimeIconContent_OnApplyTemplate_Hook,
                true,
            },
            {
                {LR"(public: virtual int __cdecl winrt::impl::produce<struct winrt::SystemTray::implementation::BadgeIconContent,struct winrt::SystemTray::IBadgeIconContent>::get_ViewModel(void * *))"},
                &BadgeIconContent_get_ViewModel_Original,
                BadgeIconContent_get_ViewModel_Hook,
                true,
            },
            {
                {LR"(private: struct winrt::hstring __cdecl winrt::SystemTray::implementation::ClockSystemTrayIconDataModel::GetTimeToolTipString(struct _SYSTEMTIME *,struct _TIME_DYNAMIC_ZONE_INFORMATION *,class SystemTrayTelemetry::ClockUpdate &))"},
                &ClockSystemTrayIconDataModel_GetTimeToolTipString_2_Original,
                ClockSystemTrayIconDataModel_GetTimeToolTipString_2_Hook,
                true,  // Until Windows 11 version 21H2.
            },
            {
                {LR"(public: int __cdecl winrt::impl::consume_Windows_Globalization_ICalendar<struct winrt::Windows::Globalization::ICalendar>::Second(void)const )"},
                &ICalendar_Second_Original,
                ICalendar_Second_Hook,
                true,  // Until Windows 11 version 21H2.
            },
            {
                {
                    LR"(public: static __cdecl winrt::Windows::System::Threading::ThreadPoolTimer::CreateTimer(struct winrt::Windows::System::Threading::TimerElapsedHandler const &,class std::chrono::duration<__int64,struct std::ratio<1,10000000> > const &))",
                    // Windows 11 21H2:
                    LR"(public: struct winrt::Windows::System::Threading::ThreadPoolTimer __cdecl winrt::impl::consume_Windows_System_Threading_IThreadPoolTimerStatics<struct winrt::Windows::System::Threading::IThreadPoolTimerStatics>::CreateTimer(struct winrt::Windows::System::Threading::TimerElapsedHandler const &,class std::chrono::duration<__int64,struct std::ratio<1,10000000> > const &)const )",
                },
                &ThreadPoolTimer_CreateTimer_Original,
                ThreadPoolTimer_CreateTimer_Hook,
                true,  // Only for more precise clock, see comment in the hook.
            },
            {
                {
                    LR"(public: __cdecl <lambda_b19cf72fe9674443383aa89d5c22450b>::operator()(struct winrt::Windows::System::Threading::IThreadPoolTimerStatics const &)const )",
                    // Windows 11 21H2:
                    LR"(public: struct winrt::Windows::System::Threading::ThreadPoolTimer __cdecl <lambda_b19cf72fe9674443383aa89d5c22450b>::operator()(struct winrt::Windows::System::Threading::IThreadPoolTimerStatics const &)const )",
                },
                &ThreadPoolTimer_CreateTimer_lambda_Original,
                ThreadPoolTimer_CreateTimer_lambda_Hook,
                true,  // Only for more precise clock, see comment in the hook.
            },
    };

    if (!HookSymbols(module, symbolHooks, ARRAYSIZE(symbolHooks))) {
        Wh_Log(L"HookSymbols failed");
        return false;
    }

    return true;
}

HMODULE GetSystemTrayModuleHandle() {
    HMODULE module = GetModuleHandle(L"SystemTray.dll");
    if (!module) {
        module = GetModuleHandle(L"Taskbar.View.dll");
        if (module) {
            // Starting with Taskbar.View.dll 2604.8002.200.6000, the SystemTray
            // types moved out of Taskbar.View.dll into SystemTray.dll, so don't
            // hook Taskbar.View.dll at this version and above.
            VS_FIXEDFILEINFO* fixedFileInfo =
                GetModuleVersionInfo(module, nullptr);
            WORD moduleMajor =
                fixedFileInfo ? HIWORD(fixedFileInfo->dwFileVersionMS) : 0;
            if (!moduleMajor || moduleMajor >= 2604) {
                Wh_Log(L"Skipping Taskbar.View.dll version %d", moduleMajor);
                module = nullptr;
            }
        }
    }
    if (!module) {
        module = GetModuleHandle(L"ExplorerExtensions.dll");
    }

    return module;
}

void HandleLoadedModuleIfSystemTray(HMODULE module, LPCWSTR lpLibFileName) {
    if (g_winVersion >= WinVersion::Win11 && !g_systemTrayModuleHooked &&
        GetSystemTrayModuleHandle() == module &&
        !g_systemTrayModuleHooked.exchange(true)) {
        Wh_Log(L"Loaded %s", lpLibFileName);

        if (HookSystemTraySymbols(module)) {
            Wh_ApplyHookOperations();
        }
    }
}

using LoadLibraryExW_t = decltype(&LoadLibraryExW);
LoadLibraryExW_t LoadLibraryExW_Original;
HMODULE WINAPI LoadLibraryExW_Hook(LPCWSTR lpLibFileName,
                                   HANDLE hFile,
                                   DWORD dwFlags) {
    HMODULE module = LoadLibraryExW_Original(lpLibFileName, hFile, dwFlags);
    if (module) {
        HandleLoadedModuleIfExplorerPatcher(module);
        HandleLoadedModuleIfSystemTray(module, lpLibFileName);
    }

    return module;
}

NetworkMetricsFormat ParseNetworkMetricsFormat(PCWSTR value) {
    if (wcscmp(value, L"mbsNumberOnly") == 0) {
        return NetworkMetricsFormat::mbsNumberOnly;
    } else if (wcscmp(value, L"mbsDynamic") == 0) {
        return NetworkMetricsFormat::mbsDynamic;
    } else if (wcscmp(value, L"mbits") == 0) {
        return NetworkMetricsFormat::mbits;
    } else if (wcscmp(value, L"mbitsNumberOnly") == 0) {
        return NetworkMetricsFormat::mbitsNumberOnly;
    } else if (wcscmp(value, L"mbitsDynamic") == 0) {
        return NetworkMetricsFormat::mbitsDynamic;
    }

    return NetworkMetricsFormat::mbs;
}

void LoadSettings() {
    g_settings.showSeconds = Wh_GetIntSetting(L"ShowSeconds");
    g_settings.timeFormat = StringSetting::make(L"TimeFormat");
    g_settings.dateFormat = StringSetting::make(L"DateFormat");

    g_settings.dateLocales.clear();
    StringSetting dateLocale = StringSetting::make(L"DateLocale");
    for (const auto locale : SplitStringView(dateLocale.get(), L";")) {
        g_settings.dateLocales.emplace_back(TrimStringView(locale));
    }

    g_settings.weekdayFormat = StringSetting::make(L"WeekdayFormat");

    g_settings.weekdayFormatCustom.clear();
    if (wcscmp(g_settings.weekdayFormat, L"custom") == 0) {
        StringSetting weekdayFormatCustom =
            StringSetting::make(L"WeekdayFormatCustom");
        for (const auto weekdayName :
             SplitStringView(weekdayFormatCustom.get(), L",")) {
            g_settings.weekdayFormatCustom.emplace_back(
                TrimStringView(weekdayName));
        }
        g_settings.weekdayFormatCustom.resize(7);
    }

    g_settings.topLine = StringSetting::make(L"TopLine");
    g_settings.bottomLine = StringSetting::make(L"BottomLine");
    g_settings.middleLine = StringSetting::make(L"MiddleLine");
    g_settings.tooltipLine = StringSetting::make(L"TooltipLine");

    g_settings.tooltipLineMode = TooltipLineMode::append;
    StringSetting tooltipLineMode = StringSetting::make(L"TooltipLineMode");
    if (wcscmp(tooltipLineMode, L"replace") == 0) {
        g_settings.tooltipLineMode = TooltipLineMode::replace;
    }

    g_settings.width = Wh_GetIntSetting(L"Width");
    g_settings.height = Wh_GetIntSetting(L"Height");
    g_settings.textSpacing = Wh_GetIntSetting(L"TextSpacing");

    g_settings.dataCollection.networkMetricsFormat = ParseNetworkMetricsFormat(
        StringSetting::make(L"DataCollection.NetworkMetricsFormat"));

    g_settings.dataCollection.networkMetricsFixedDecimals =
        Wh_GetIntSetting(L"DataCollection.NetworkMetricsFixedDecimals");

    StringSetting diskMetricsFormat =
        StringSetting::make(L"DataCollection.DiskMetricsFormat");
    if (wcscmp(diskMetricsFormat, L"sameAsNetwork") == 0) {
        g_settings.dataCollection.diskMetricsFormat =
            g_settings.dataCollection.networkMetricsFormat;
        g_settings.dataCollection.diskMetricsFixedDecimals =
            g_settings.dataCollection.networkMetricsFixedDecimals;
    } else {
        g_settings.dataCollection.diskMetricsFormat =
            ParseNetworkMetricsFormat(diskMetricsFormat);
        g_settings.dataCollection.diskMetricsFixedDecimals =
            Wh_GetIntSetting(L"DataCollection.DiskMetricsFixedDecimals");
    }

    g_settings.dataCollection.percentageFormat =
        PercentageFormat::spacePaddingAndSymbol;
    StringSetting percentageFormat =
        StringSetting::make(L"DataCollection.PercentageFormat");
    if (wcscmp(percentageFormat, L"spacePadding") == 0) {
        g_settings.dataCollection.percentageFormat =
            PercentageFormat::spacePadding;
    } else if (wcscmp(percentageFormat, L"singleSpacePadding") == 0) {
        g_settings.dataCollection.percentageFormat =
            PercentageFormat::singleSpacePadding;
    } else if (wcscmp(percentageFormat, L"zeroPadding") == 0) {
        g_settings.dataCollection.percentageFormat =
            PercentageFormat::zeroPadding;
    } else if (wcscmp(percentageFormat, L"noPadding") == 0) {
        g_settings.dataCollection.percentageFormat =
            PercentageFormat::noPadding;
    }

    g_settings.dataCollection.updateInterval =
        Wh_GetIntSetting(L"DataCollection.UpdateInterval");

    g_settings.dataCollection.networkAdapterName =
        StringSetting::make(L"DataCollection.NetworkAdapterName");

    g_settings.dataCollection.gpuAdapterName =
        StringSetting::make(L"DataCollection.GpuAdapterName");

    g_settings.mediaPlayer.maxLength =
        Wh_GetIntSetting(L"MediaPlayer.MaxLength");
    g_settings.mediaPlayer.mediaInfoFormat =
        StringSetting::make(L"MediaPlayer.MediaInfoFormat");
    g_settings.mediaPlayer.noMediaText =
        StringSetting::make(L"MediaPlayer.NoMediaText");
    g_settings.mediaPlayer.removeBrackets =
        Wh_GetIntSetting(L"MediaPlayer.RemoveBrackets");

    g_settings.mediaPlayer.ignoredPlayers.clear();
    for (int i = 0;; i++) {
        StringSetting player =
            StringSetting::make(L"MediaPlayer.IgnoredPlayers[%d]", i);
        if (*player == '\0') {
            break;
        }
        g_settings.mediaPlayer.ignoredPlayers.push_back(std::move(player));
    }

    g_settings.webContentWeatherLocation =
        StringSetting::make(L"WebContentWeatherLocation");
    g_settings.webContentWeatherFormat =
        StringSetting::make(L"WebContentWeatherFormat");

    g_settings.webContentWeatherUnits = WebContentWeatherUnits::autoDetect;
    StringSetting webContentWeatherUnits =
        StringSetting::make(L"WebContentWeatherUnits");
    if (wcscmp(webContentWeatherUnits, L"uscs") == 0) {
        g_settings.webContentWeatherUnits = WebContentWeatherUnits::uscs;
    } else if (wcscmp(webContentWeatherUnits, L"metric") == 0) {
        g_settings.webContentWeatherUnits = WebContentWeatherUnits::metric;
    } else if (wcscmp(webContentWeatherUnits, L"metricMsWind") == 0) {
        g_settings.webContentWeatherUnits =
            WebContentWeatherUnits::metricMsWind;
    }

    g_settings.webContentsItems.clear();
    for (int i = 0;; i++) {
        WebContentsSettings item;
        item.url = StringSetting::make(L"WebContentsItems[%d].Url", i);
        if (*item.url == '\0') {
            break;
        }

        item.blockStart =
            StringSetting::make(L"WebContentsItems[%d].BlockStart", i);
        item.start = StringSetting::make(L"WebContentsItems[%d].Start", i);
        item.end = StringSetting::make(L"WebContentsItems[%d].End", i);

        item.contentMode = ContentMode::plainText;
        StringSetting contentMode =
            StringSetting::make(L"WebContentsItems[%d].ContentMode", i);
        if (wcscmp(contentMode, L"xml") == 0) {
            item.contentMode = ContentMode::xml;
        } else if (wcscmp(contentMode, L"html") == 0) {
            item.contentMode = ContentMode::html;
        } else if (wcscmp(contentMode, L"xmlHtml") == 0) {
            item.contentMode = ContentMode::xmlHtml;
        }

        for (int j = 0;; j++) {
            StringSetting search = StringSetting::make(
                L"WebContentsItems[%d].SearchReplace[%d].Search", i, j);
            if (*search == '\0') {
                break;
            }

            StringSetting replace = StringSetting::make(
                L"WebContentsItems[%d].SearchReplace[%d].Replace", i, j);

            try {
                item.searchReplace.push_back(
                    {std::wregex(search), std::wstring(replace)});
            } catch (const std::exception& ex) {
                Wh_Log(L"Invalid search pattern \"%s\": %hs", search.get(),
                       ex.what());
            }
        }

        item.maxLength = Wh_GetIntSetting(L"WebContentsItems[%d].MaxLength", i);

        g_settings.webContentsItems.push_back(std::move(item));
    }

    g_settings.webContentsUpdateInterval =
        Wh_GetIntSetting(L"WebContentsUpdateInterval");

    g_timeZoneInformation.clear();
    g_timeFormattedTz.clear();
    g_dateFormattedTz.clear();
    g_weekdayFormattedTz.clear();

    g_settings.timeZones.clear();
    for (int i = 0;; i++) {
        StringSetting timeZone = StringSetting::make(L"TimeZones[%d]", i);
        if (*timeZone == '\0') {
            break;
        }

        g_timeZoneInformation.emplace_back(GetTimeZoneInformation(timeZone));
        g_timeFormattedTz.emplace_back();
        g_dateFormattedTz.emplace_back();
        g_weekdayFormattedTz.emplace_back();

        g_settings.timeZones.push_back(std::move(timeZone));
    }

    ClockElementStyleSettings styleSettings;
    styleSettings.maxWidth = Wh_GetIntSetting(L"MaxWidth");
    styleSettings.textSpacing = g_settings.textSpacing;

    TextStyleSettings& timeStyle = styleSettings.timeStyle;
    timeStyle.hidden = Wh_GetIntSetting(L"TimeStyle.Hidden");
    timeStyle.textColor = StringSetting::make(L"TimeStyle.TextColor");
    timeStyle.textAlignment = StringSetting::make(L"TimeStyle.TextAlignment");
    timeStyle.fontSize = Wh_GetIntSetting(L"TimeStyle.FontSize");
    timeStyle.fontFamily = StringSetting::make(L"TimeStyle.FontFamily");
    timeStyle.fontWeight = StringSetting::make(L"TimeStyle.FontWeight");
    timeStyle.fontStyle = StringSetting::make(L"TimeStyle.FontStyle");
    timeStyle.fontStretch = StringSetting::make(L"TimeStyle.FontStretch");
    timeStyle.characterSpacing =
        Wh_GetIntSetting(L"TimeStyle.CharacterSpacing");
    timeStyle.lineHeight = Wh_GetIntSetting(L"TimeStyle.LineHeight");

    TextStyleSettings& dateStyle = styleSettings.dateStyle;
    dateStyle.hidden = Wh_GetIntSetting(L"DateStyle.Hidden");
    dateStyle.textColor = StringSetting::make(L"DateStyle.TextColor");
    dateStyle.textAlignment = StringSetting::make(L"DateStyle.TextAlignment");
    dateStyle.fontSize = Wh_GetIntSetting(L"DateStyle.FontSize");
    dateStyle.fontFamily = StringSetting::make(L"DateStyle.FontFamily");
    dateStyle.fontWeight = StringSetting::make(L"DateStyle.FontWeight");
    dateStyle.fontStyle = StringSetting::make(L"DateStyle.FontStyle");
    dateStyle.fontStretch = StringSetting::make(L"DateStyle.FontStretch");
    dateStyle.characterSpacing =
        Wh_GetIntSetting(L"DateStyle.CharacterSpacing");
    dateStyle.lineHeight = Wh_GetIntSetting(L"DateStyle.LineHeight");

    bool clockElementStyleEnabled =
        styleSettings.maxWidth || styleSettings.textSpacing ||
        timeStyle.hidden || *timeStyle.textColor || *timeStyle.textAlignment ||
        timeStyle.fontSize || *timeStyle.fontFamily || *timeStyle.fontWeight ||
        *timeStyle.fontStyle || *timeStyle.fontStretch ||
        timeStyle.characterSpacing || timeStyle.lineHeight ||
        dateStyle.hidden || *dateStyle.textColor || *dateStyle.textAlignment ||
        dateStyle.fontSize || *dateStyle.fontFamily || *dateStyle.fontWeight ||
        *dateStyle.fontStyle || *dateStyle.fontStretch ||
        dateStyle.characterSpacing || dateStyle.lineHeight;

    {
        std::lock_guard<std::mutex> guard(g_clockElementStyleMutex);
        g_clockElementStyleSettings = std::move(styleSettings);
        g_clockElementStyleEnabled = clockElementStyleEnabled;
        g_clockElementStyleIndex++;
    }

    g_settings.oldTaskbarOnWin11 = Wh_GetIntSetting(L"oldTaskbarOnWin11");

    // Kept for compatibility with old settings:
    if (IsStrInDateTimePatternSettings(L"%web%") ||
        IsStrInDateTimePatternSettings(L"%web_full%")) {
        g_settings.webContentsUrl = StringSetting::make(L"WebContentsUrl");
        g_settings.webContentsBlockStart =
            StringSetting::make(L"WebContentsBlockStart");
        g_settings.webContentsStart = StringSetting::make(L"WebContentsStart");
        g_settings.webContentsEnd = StringSetting::make(L"WebContentsEnd");
        g_settings.webContentsMaxLength =
            Wh_GetIntSetting(L"WebContentsMaxLength");
    }
}

HWND FindCurrentProcessTaskbarWnd() {
    HWND hTaskbarWnd = nullptr;

    EnumWindows(
        [](HWND hWnd, LPARAM lParam) -> BOOL {
            DWORD dwProcessId;
            WCHAR className[32];
            if (GetWindowThreadProcessId(hWnd, &dwProcessId) &&
                dwProcessId == GetCurrentProcessId() &&
                GetClassName(hWnd, className, ARRAYSIZE(className)) &&
                _wcsicmp(className, L"Shell_TrayWnd") == 0) {
                *reinterpret_cast<HWND*>(lParam) = hWnd;
                return FALSE;
            }
            return TRUE;
        },
        reinterpret_cast<LPARAM>(&hTaskbarWnd));

    return hTaskbarWnd;
}

void ApplySettingsWin11() {
    HWND hTaskbarWnd = FindCurrentProcessTaskbarWnd();
    if (!hTaskbarWnd) {
        return;
    }

    // Touch a registry value to trigger a watcher for a clock update. Do so
    // only if the current explorer.exe instance owns the taskbar.
    constexpr WCHAR kTempValueName[] =
        L"_temp_windhawk_taskbar-taskbar-clock-customization";
    HKEY hSubKey;
    LONG result = RegOpenKeyEx(HKEY_CURRENT_USER,
                               L"Control Panel\\TimeDate\\AdditionalClocks", 0,
                               KEY_WRITE, &hSubKey);
    if (result == ERROR_SUCCESS) {
        if (RegSetValueEx(hSubKey, kTempValueName, 0, REG_SZ, (const BYTE*)L"",
                          sizeof(WCHAR)) != ERROR_SUCCESS) {
            Wh_Log(L"Failed to create temp value");
        } else if (RegDeleteValue(hSubKey, kTempValueName) != ERROR_SUCCESS) {
            Wh_Log(L"Failed to remove temp value");
        }

        RegCloseKey(hSubKey);
    } else {
        Wh_Log(L"Failed to open subkey: %d", result);
    }
}

void ApplySettingsWin10() {
    HWND hTaskbarWnd = FindCurrentProcessTaskbarWnd();
    if (!hTaskbarWnd) {
        return;
    }

    // Apply size.
    RECT rc;
    if (GetClientRect(hTaskbarWnd, &rc)) {
        SendMessage(hTaskbarWnd, WM_SIZE, SIZE_RESTORED,
                    MAKELPARAM(rc.right - rc.left, rc.bottom - rc.top));
    }

    // Apply text.
    HWND hTrayNotifyWnd =
        FindWindowEx(hTaskbarWnd, nullptr, L"TrayNotifyWnd", nullptr);
    if (hTrayNotifyWnd) {
        HWND hTrayClockWWnd =
            FindWindowEx(hTrayNotifyWnd, nullptr, L"TrayClockWClass", nullptr);
        if (hTrayClockWWnd) {
            LONG_PTR lpTrayClockWClassLongPtr =
                GetWindowLongPtr(hTrayClockWWnd, 0);
            if (lpTrayClockWClassLongPtr) {
                ClockButton_v_OnDisplayStateChange_Original(
                    (LPVOID)lpTrayClockWClassLongPtr, true);
            }
        }
    }

    DWORD taskbarThreadId = GetWindowThreadProcessId(hTaskbarWnd, nullptr);
    if (!taskbarThreadId) {
        return;
    }

    auto enumWindowsProc = [](HWND hWnd) {
        WCHAR szClassName[32];
        if (!GetClassName(hWnd, szClassName, ARRAYSIZE(szClassName)) ||
            _wcsicmp(szClassName, L"Shell_SecondaryTrayWnd") != 0) {
            return;
        }

        // Apply size.
        RECT rc;
        if (GetClientRect(hWnd, &rc)) {
            WINDOWPOS windowpos;
            windowpos.hwnd = hWnd;
            windowpos.hwndInsertAfter = nullptr;
            windowpos.x = 0;
            windowpos.y = 0;
            windowpos.cx = rc.right - rc.left;
            windowpos.cy = rc.bottom - rc.top;
            windowpos.flags = SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE;

            SendMessage(hWnd, WM_WINDOWPOSCHANGED, 0, (LPARAM)&windowpos);
        }

        // Apply text.
        HWND hClockButtonWnd =
            FindWindowEx(hWnd, nullptr, L"ClockButton", nullptr);
        if (hClockButtonWnd) {
            LONG_PTR lpClockButtonLongPtr =
                GetWindowLongPtr(hClockButtonWnd, 0);
            if (lpClockButtonLongPtr) {
                ClockButton_v_OnDisplayStateChange_Original(
                    (LPVOID)lpClockButtonLongPtr, true);
            }
        }
    };

    EnumThreadWindows(
        taskbarThreadId,
        [](HWND hWnd, LPARAM lParam) -> BOOL {
            auto& proc = *reinterpret_cast<decltype(enumWindowsProc)*>(lParam);
            proc(hWnd);
            return TRUE;
        },
        reinterpret_cast<LPARAM>(&enumWindowsProc));
}

void ApplySettings() {
    if (g_winVersion >= WinVersion::Win11) {
        ApplySettingsWin11();
    } else {
        ApplySettingsWin10();
    }
}

BOOL Wh_ModInit() {
    Wh_Log(L">");

    if (HMODULE hUser32 = LoadLibraryEx(L"user32.dll", nullptr,
                                        LOAD_LIBRARY_SEARCH_SYSTEM32)) {
        pGetDpiForWindow =
            (GetDpiForWindow_t)GetProcAddress(hUser32, "GetDpiForWindow");
    }

    if (HMODULE hKernel32 = LoadLibraryEx(L"kernel32.dll", nullptr,
                                          LOAD_LIBRARY_SEARCH_SYSTEM32)) {
        pSystemTimeToTzSpecificLocalTimeEx =
            (SystemTimeToTzSpecificLocalTimeEx_t)GetProcAddress(
                hKernel32, "SystemTimeToTzSpecificLocalTimeEx");
    }

    if (HMODULE hAdvapi32 = LoadLibraryEx(L"advapi32.dll", nullptr,
                                          LOAD_LIBRARY_SEARCH_SYSTEM32)) {
        pEnumDynamicTimeZoneInformation =
            (EnumDynamicTimeZoneInformation_t)GetProcAddress(
                hAdvapi32, "EnumDynamicTimeZoneInformation");
    }

    if (HMODULE hGdi32 = LoadLibraryEx(L"gdi32.dll", nullptr,
                                       LOAD_LIBRARY_SEARCH_SYSTEM32)) {
        pD3DKMTOpenAdapterFromLuid =
            (D3DKMTOpenAdapterFromLuid_t)GetProcAddress(
                hGdi32, "D3DKMTOpenAdapterFromLuid");
        pD3DKMTQueryAdapterInfo = (D3DKMTQueryAdapterInfo_t)GetProcAddress(
            hGdi32, "D3DKMTQueryAdapterInfo");
        pD3DKMTCloseAdapter =
            (D3DKMTCloseAdapter_t)GetProcAddress(hGdi32, "D3DKMTCloseAdapter");
    }

    LoadSettings();

    g_winVersion = GetExplorerVersion();
    if (g_winVersion == WinVersion::Unsupported) {
        Wh_Log(L"Unsupported Windows version");
        return FALSE;
    }

    if (g_settings.oldTaskbarOnWin11) {
        bool hasWin10Taskbar = g_winVersion < WinVersion::Win11_24H2;

        if (g_winVersion >= WinVersion::Win11) {
            g_winVersion = WinVersion::Win10;
        }

        if (hasWin10Taskbar && !HookWin10TaskbarSymbols()) {
            return FALSE;
        }
    } else if (g_winVersion >= WinVersion::Win11) {
        if (HMODULE systemTrayModule = GetSystemTrayModuleHandle()) {
            g_systemTrayModuleHooked = true;
            if (!HookSystemTraySymbols(systemTrayModule)) {
                return FALSE;
            }
        } else {
            Wh_Log(L"System tray module not loaded yet");
        }
    } else {
        if (!HookWin10TaskbarSymbols()) {
            return FALSE;
        }
    }

    if (!HandleLoadedExplorerPatcher()) {
        Wh_Log(L"HandleLoadedExplorerPatcher failed");
        return FALSE;
    }

    HMODULE kernelBaseModule = GetModuleHandle(L"kernelbase.dll");
    auto pKernelBaseLoadLibraryExW = (decltype(&LoadLibraryExW))GetProcAddress(
        kernelBaseModule, "LoadLibraryExW");
    WindhawkUtils::SetFunctionHook(pKernelBaseLoadLibraryExW,
                                   LoadLibraryExW_Hook,
                                   &LoadLibraryExW_Original);

    // Must use GetProcAddress for the functions below, otherwise the stubs in
    // kernel32.dll are being hooked.
    auto pGetTimeFormatEx = (decltype(&GetTimeFormatEx))GetProcAddress(
        kernelBaseModule, "GetTimeFormatEx");
    if (!pGetTimeFormatEx) {
        return FALSE;
    }

    auto pGetDateFormatEx = (decltype(&GetDateFormatEx))GetProcAddress(
        kernelBaseModule, "GetDateFormatEx");
    if (!pGetDateFormatEx) {
        return FALSE;
    }

    if (g_winVersion <= WinVersion::Win10) {
        WindhawkUtils::SetFunctionHook(pGetTimeFormatEx,
                                       GetTimeFormatEx_Hook_Win10,
                                       &GetTimeFormatEx_Original);
        WindhawkUtils::SetFunctionHook(pGetDateFormatEx,
                                       GetDateFormatEx_Hook_Win10,
                                       &GetDateFormatEx_Original);

        auto pGetDateFormatW = (decltype(&GetDateFormatW))GetProcAddress(
            kernelBaseModule, "GetDateFormatW");
        if (pGetDateFormatW) {
            WindhawkUtils::SetFunctionHook(pGetDateFormatW,
                                           GetDateFormatW_Hook_Win10,
                                           &GetDateFormatW_Original);
        }
    } else {
        if (g_winVersion >= WinVersion::Win11_22H2) {
            auto pGetLocalTime = (decltype(&GetLocalTime))GetProcAddress(
                kernelBaseModule, "GetLocalTime");
            if (!pGetLocalTime) {
                return FALSE;
            }

            WindhawkUtils::SetFunctionHook(
                pGetLocalTime, GetLocalTime_Hook_Win11, &GetLocalTime_Original);
        }

        WindhawkUtils::SetFunctionHook(pGetTimeFormatEx,
                                       GetTimeFormatEx_Hook_Win11,
                                       &GetTimeFormatEx_Original);
        WindhawkUtils::SetFunctionHook(pGetDateFormatEx,
                                       GetDateFormatEx_Hook_Win11,
                                       &GetDateFormatEx_Original);
        WindhawkUtils::SetFunctionHook(SendMessageW, SendMessageW_Hook,
                                       &SendMessageW_Original);
    }

    g_initialized = true;

    return TRUE;
}

void Wh_ModAfterInit() {
    Wh_Log(L">");

    if (g_winVersion >= WinVersion::Win11 && !g_systemTrayModuleHooked) {
        if (HMODULE systemTrayModule = GetSystemTrayModuleHandle()) {
            if (!g_systemTrayModuleHooked.exchange(true)) {
                Wh_Log(L"Got system tray module");

                if (HookSystemTraySymbols(systemTrayModule)) {
                    Wh_ApplyHookOperations();
                }
            }
        }
    }

    // Try again in case there's a race between the previous attempt and the
    // LoadLibraryExW hook.
    if (!g_explorerPatcherInitialized) {
        HandleLoadedExplorerPatcher();
    }

    ApplySettings();
}

void Wh_ModBeforeUninit() {
    Wh_Log(L">");

    if (g_winVersion < WinVersion::Win11) {
        return;
    }

    DWORD styleIndex;
    {
        std::lock_guard<std::mutex> guard(g_clockElementStyleMutex);
        if (!g_clockElementStyleEnabled) {
            return;
        }

        g_clockElementStyleEnabled = false;
        styleIndex = ++g_clockElementStyleIndex;
    }

    ApplySettings();

    // Wait for styles to be restored.
    for (int i = 0; i < 20; i++) {
        bool allRestored = true;

        {
            std::lock_guard<std::mutex> guard(g_clockElementStyleMutex);
            for (const auto& data : g_clockElementStyleData) {
                if (data.styleIndex < styleIndex) {
                    allRestored = false;
                    break;
                }
            }
        }

        if (allRestored) {
            break;
        }

        Sleep(100);
    }
}

// Stops the background work that feeds the format tokens, and keeps it stopped
// until g_formattingInitialized is cleared. Must be called without
// g_formatLineMutex held: joining the web content thread waits for an in-flight
// network fetch and detaching the media handlers waits for an in-flight event,
// neither of which should hold up the clock.
void StopFormattingBackgroundWork() {
    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);
        g_formattingInitialized = true;
    }

    WebContentUpdateThreadUninit();
    MediaSessionUninit();
}

void Wh_ModUninit() {
    Wh_Log(L">");

    StopFormattingBackgroundWork();

    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);
        DataCollectionSessionUninit();
    }

    ApplySettings();
}

BOOL Wh_ModSettingsChanged(BOOL* bReload) {
    Wh_Log(L">");

    StopFormattingBackgroundWork();

    {
        std::lock_guard<std::mutex> guard(g_formatLineMutex);
        DataCollectionSessionUninit();
        g_formattingInitialized = false;

        bool prevOldTaskbarOnWin11 = g_settings.oldTaskbarOnWin11;

        LoadSettings();

        *bReload = g_settings.oldTaskbarOnWin11 != prevOldTaskbarOnWin11;
        if (*bReload) {
            return TRUE;
        }
    }

    ApplySettings();

    return TRUE;
}
